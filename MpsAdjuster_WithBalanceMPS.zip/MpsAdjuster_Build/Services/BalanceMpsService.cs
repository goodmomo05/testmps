using ClosedXML.Excel;

namespace MpsAdjuster.Services;

public static class BalanceMpsService
{
    // ── Result ────────────────────────────────────────────────────────────────
    public enum BalanceResult { Success, StoppedEfficiencyLimit }

    public class BalanceOutcome
    {
        public BalanceResult Result  { get; init; }
        public string?       Message { get; init; }
    }

    // ── Entry point ───────────────────────────────────────────────────────────
    public static BalanceOutcome Run(
        IXLWorksheet bSheet,
        int    weekCol,
        double targetEff,
        double packFactor,
        int    varRow,
        int    workHrsRow,
        int    invRow)
    {
        int lastCol        = GetLastUsedColumn(bSheet, headerRow: 12);
        int currentWeekCol = weekCol;

        while (currentWeekCol <= lastCol)
        {
            // Find the nearest Invt Qty cell that is negative
            int shortageRow = FindNearestShortage(bSheet, currentWeekCol, lastCol, invRow);

            // No shortages anywhere → done
            if (shortageRow == 0) break;

            // Skip weeks with zero clock hours
            double clockHrs = GetDouble(bSheet, workHrsRow, currentWeekCol);
            if (clockHrs == 0)
            {
                currentWeekCol++;
                continue;
            }

            double effVar = GetDouble(bSheet, varRow, currentWeekCol);

            if (effVar > targetEff)
            {
                // Plan row is 2 rows below the Invt Qty row (same offset as VBA: shortageRow+2)
                int    planRow = shortageRow + 2;
                double before  = GetDouble(bSheet, planRow, currentWeekCol);

                // Add one pack
                bSheet.Cell(planRow, currentWeekCol).Value = before + packFactor;

                double effAfter = GetDouble(bSheet, varRow, currentWeekCol);

                if (effAfter < targetEff)
                {
                    // Undo — efficiency limit crossed
                    bSheet.Cell(planRow, currentWeekCol).Value = before;

                    double remaining = GetDouble(bSheet, shortageRow, currentWeekCol);
                    if (remaining < 0)
                    {
                        return new BalanceOutcome
                        {
                            Result  = BalanceResult.StoppedEfficiencyLimit,
                            Message =
                                "STOPPED: Efficiency limit reached while shortage still exists.\n\n" +
                                $"Part:               {GetString(bSheet, shortageRow - 1, 2)}\n" +
                                $"Week column:        {currentWeekCol}\n" +
                                $"Remaining Shortage: {remaining}"
                        };
                    }

                    currentWeekCol++;
                }
                // else: pack fit fine — stay on same week and loop again
            }
            else
            {
                // Efficiency already at/below target → move to next week
                currentWeekCol++;
            }
        }

        return new BalanceOutcome { Result = BalanceResult.Success };
    }

    // ── Find nearest row where Invt Qty < 0 ──────────────────────────────────
    private static int FindNearestShortage(
        IXLWorksheet ws,
        int currentWeek,
        int lastCol,
        int invRow)
    {
        // Part numbers live in col A (1), use that to find the last part row
        int lastRow = GetLastUsedRow(ws, col: 1);

        for (int chkWeek = currentWeek; chkWeek <= lastCol; chkWeek++)
        {
            int chkRow = invRow;
            while (chkRow <= lastRow)
            {
                if (GetDouble(ws, chkRow, chkWeek) < 0)
                    return chkRow;

                chkRow += 7; // each part block is 7 rows
            }
        }
        return 0;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private static double GetDouble(IXLWorksheet ws, int row, int col)
    {
        var cell = ws.Cell(row, col);
        return cell.TryGetValue<double>(out double v) ? v : 0;
    }

    private static string GetString(IXLWorksheet ws, int row, int col)
        => ws.Cell(row, col).GetString();

    private static int GetLastUsedColumn(IXLWorksheet ws, int headerRow)
    {
        int last = 1;
        // Row 12 has week numbers (20, 21, 22...) — more reliable than row 11
        foreach (var cell in ws.Row(headerRow).CellsUsed())
            if (cell.Address.ColumnNumber > last)
                last = cell.Address.ColumnNumber;
        return last;
    }

    private static int GetLastUsedRow(IXLWorksheet ws, int col)
    {
        int last = 1;
        foreach (var cell in ws.Column(col).CellsUsed())
            if (cell.Address.RowNumber > last)
                last = cell.Address.RowNumber;
        return last;
    }
}
