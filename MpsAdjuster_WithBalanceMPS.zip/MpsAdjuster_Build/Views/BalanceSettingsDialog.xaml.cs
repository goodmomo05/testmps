using System.Windows;
using ClosedXML.Excel;

namespace MpsAdjuster.Views;

public partial class BalanceSettingsDialog : Window
{
    // ── Outputs read by the caller after DialogResult = true ─────────────────
    public int    WeekCol    { get; private set; }
    public double TargetEff  { get; private set; }
    public double PackFactor { get; private set; }

    // ── Auto-detected rows (invisible to user) ────────────────────────────────
    public int VarRow     { get; private set; }
    public int WorkHrsRow { get; private set; }
    public int InvRow     { get; private set; }

    // ── Constructor — reads settings from the sheet's own settings table ──────
    // The B-sheet has a settings table in column O (col 15), rows 3-9:
    //   O3 = Starting Week Col
    //   O4 = Var Row
    //   O5 = Working HRS Row
    //   O6 = Inv Row
    //   O7 = Pln Row  (not used here but present)
    //   O8 = Weeks to Cover (not used here)
    //   O9 = Target Eff.
    public BalanceSettingsDialog(IXLWorksheet bSheet)
    {
        InitializeComponent();

        // ── Read rows from the sheet's own settings table (col O = 15) ───────
        int sheetWeekCol    = GetInt(bSheet,    3, 15);   // O3 Starting Week Col
        int sheetVarRow     = GetInt(bSheet,    4, 15);   // O4 Var Row
        int sheetWorkHrsRow = GetInt(bSheet,    5, 15);   // O5 Working HRS Row
        int sheetInvRow     = GetInt(bSheet,    6, 15);   // O6 Inv Row
        double sheetTargEff = GetDouble(bSheet, 9, 15);   // O9 Target Eff.

        // ── Fallback: scan col A then col C if settings table values missing ──
        VarRow     = sheetVarRow     > 0 ? sheetVarRow     : FindRowByLabel(bSheet, "Efficency Var:", 3);
        WorkHrsRow = sheetWorkHrsRow > 0 ? sheetWorkHrsRow : FindRowByLabel(bSheet, "Clock Hours",    1);
        InvRow     = sheetInvRow     > 0 ? sheetInvRow     : FindRowByLabel(bSheet, "Invt Qty",       3);

        // Final fallback hardcoded defaults
        if (VarRow     <= 0) VarRow     = 10;
        if (WorkHrsRow <= 0) WorkHrsRow = 291;
        if (InvRow     <= 0) InvRow     = 14;

        // ── Pre-fill user fields from sheet values ────────────────────────────
        TxtWeekCol.Text    = (sheetWeekCol > 0 ? sheetWeekCol : 4).ToString();
        TxtTargetEff.Text  = (sheetTargEff != 0 ? sheetTargEff : -0.01)
                              .ToString("G", System.Globalization.CultureInfo.InvariantCulture);
        TxtPackFactor.Text = "40";

        TxtWeekCol.Focus();
        TxtWeekCol.SelectAll();
    }

    // ── Read an int from a cell ───────────────────────────────────────────────
    private static int GetInt(IXLWorksheet ws, int row, int col)
    {
        var cell = ws.Cell(row, col);
        return cell.TryGetValue<int>(out int v) ? v : 0;
    }

    // ── Read a double from a cell ─────────────────────────────────────────────
    private static double GetDouble(IXLWorksheet ws, int row, int col)
    {
        var cell = ws.Cell(row, col);
        return cell.TryGetValue<double>(out double v) ? v : 0;
    }

    // ── Search a specific column for a label (first match, case-insensitive) ──
    private static int FindRowByLabel(IXLWorksheet ws, string label, int col)
    {
        foreach (var row in ws.RowsUsed())
        {
            var cell = row.Cell(col);
            if (cell.TryGetValue<string>(out var txt) &&
                txt.StartsWith(label, StringComparison.OrdinalIgnoreCase))
            {
                return row.RowNumber();
            }
        }
        return 0;
    }

    // ── Validate inputs and collect values ────────────────────────────────────
    private void BtnRun_Click(object sender, RoutedEventArgs e)
    {
        int    wc = 0;
        double te = 0;
        double pf = 0;

        bool valid =
            int.TryParse(TxtWeekCol.Text.Trim(), out wc) && wc >= 1 &&
            double.TryParse(TxtTargetEff.Text.Trim(),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out te) &&
            double.TryParse(TxtPackFactor.Text.Trim(),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out pf) && pf > 0;

        if (!valid)
        {
            MessageBox.Show(
                "Please check your inputs:\n\n" +
                "  • Starting Week Column — whole number ≥ 1  (e.g. 4)\n" +
                "  • Target Eff. Variance — decimal  (e.g. -0.01)\n" +
                "  • Pack Factor — positive number  (e.g. 40)",
                "Invalid Input",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        WeekCol    = wc;
        TargetEff  = te;
        PackFactor = pf;

        DialogResult = true;
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
        => DialogResult = false;
}
