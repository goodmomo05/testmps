using System.Windows;
using ClosedXML.Excel;

namespace MpsAdjuster.Views;

public partial class BalanceSettingsDialog : Window
{
    // ── Outputs read by the caller after DialogResult = true ─────────────────
    public int    WeekCol    { get; private set; }
    public double TargetEff  { get; private set; }
    public double PackFactor { get; private set; }

    // ── Auto-detected rows (invisible to user) ────────────────────────────────
    public int VarRow     { get; private set; }
    public int WorkHrsRow { get; private set; }
    public int InvRow     { get; private set; }

    // ── Constructor — auto-detects rows from the B-sheet ─────────────────────
    public BalanceSettingsDialog(IXLWorksheet bSheet)
    {
        InitializeComponent();

        // Silently scan column C for known labels
        VarRow     = FindRowByLabel(bSheet, "Efficency Var:");  // intentional typo matches sheet
        WorkHrsRow = FindRowByLabel(bSheet, "Clock Hours");
        InvRow     = FindRowByLabel(bSheet, "Invt Qty");

        // Fallback defaults if a label is not found
        if (VarRow     <= 0) VarRow     = 10;
        if (WorkHrsRow <= 0) WorkHrsRow = 95;
        if (InvRow     <= 0) InvRow     = 14;

        // Pre-fill user-facing fields
        TxtWeekCol.Text    = "4";
        TxtTargetEff.Text  = "-0.01";
        TxtPackFactor.Text = "40";

        TxtWeekCol.Focus();
        TxtWeekCol.SelectAll();
    }

    // ── Search column C for a label (first match, case-insensitive) ───────────
    private static int FindRowByLabel(IXLWorksheet ws, string label)
    {
        foreach (var row in ws.RowsUsed())
        {
            var cell = row.Cell(3); // column C
            if (cell.TryGetValue<string>(out var txt) &&
                txt.StartsWith(label, StringComparison.OrdinalIgnoreCase))
            {
                return row.RowNumber();
            }
        }
        return 0;
    }

    // ── Validate inputs and collect values ────────────────────────────────────
    private void BtnRun_Click(object sender, RoutedEventArgs e)
    {
        int    wc = 0;
        double te = 0;
        double pf = 0;

        bool valid =
            int.TryParse(TxtWeekCol.Text.Trim(), out wc) && wc >= 1 &&
            double.TryParse(TxtTargetEff.Text.Trim(),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out te) &&
            double.TryParse(TxtPackFactor.Text.Trim(),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out pf) && pf > 0;

        if (!valid)
        {
            MessageBox.Show(
                "Please check your inputs:\n\n" +
                "  • Starting Week Column — whole number ≥ 1  (e.g. 4)\n" +
                "  • Target Eff. Variance — decimal  (e.g. -0.01)\n" +
                "  • Pack Factor — positive number  (e.g. 40)",
                "Invalid Input",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        WeekCol    = wc;
        TargetEff  = te;
        PackFactor = pf;

        DialogResult = true;
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
        => DialogResult = false;
}
