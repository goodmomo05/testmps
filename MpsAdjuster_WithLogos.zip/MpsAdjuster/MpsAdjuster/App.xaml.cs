namespace MpsAdjuster;
public partial class App : Application { }
