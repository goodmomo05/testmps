namespace MpsAdjuster.Models;

public class LogEntry
{
    public DateTime Timestamp { get; init; } = DateTime.Now;
    public string   Sheet     { get; init; } = "";
    public string   Result    { get; init; } = "";
    public string   Note      { get; init; } = "";

    public string ResultIcon => Result.ToUpperInvariant() switch
    {
        "ERROR"                            => "✖",
        var r when r.StartsWith("SKIP")   => "⚠",
        "IMPORT"                           => "✔",
        var r when r.StartsWith("LINK")   => "🔗",
        "BACKUP"                           => "💾",
        _                                  => "ℹ"
    };

    public string ResultColor => Result.ToUpperInvariant() switch
    {
        "ERROR"                            => "#FF5252",
        var r when r.StartsWith("SKIP")   => "#FFC107",
        "IMPORT"                           => "#4CAF50",
        var r when r.StartsWith("LINK")   => "#42A5F5",
        "BACKUP"                           => "#9C27B0",
        _                                  => "#607D8B"
    };
}
