
namespace MpsAdjuster.Converters;

/// <summary>Returns TrueValue/FalseValue based on a bool binding.</summary>
[ValueConversion(typeof(bool), typeof(object))]
public class BoolToValueConverter : IValueConverter
{
    public object? TrueValue  { get; set; }
    public object? FalseValue { get; set; }

    public object? Convert(object value, Type t, object p, CultureInfo c)
        => value is true ? TrueValue : FalseValue;

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>Maps a bool to Opacity (1.0 / 0.35).</summary>
[ValueConversion(typeof(bool), typeof(double))]
public class BoolToOpacityConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true ? 1.0 : 0.35;

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>Maps a hex color string like "#4CAF50" to a SolidColorBrush.</summary>
[ValueConversion(typeof(string), typeof(SolidColorBrush))]
public class HexToBrushConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
    {
        try
        {
            var clr = (Color)ColorConverter.ConvertFromString(value?.ToString() ?? "#607D8B");
            return new SolidColorBrush(clr);
        }
        catch { return new SolidColorBrush(Colors.Gray); }
    }

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>tab-name string == parameter string → Visible, else Collapsed.</summary>
public class TabEqualConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => string.Equals(value?.ToString(), p?.ToString(), StringComparison.OrdinalIgnoreCase)
           ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>Maps a bool step-done flag to a fill color brush.</summary>
public class StepDoneBrushConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true
           ? new SolidColorBrush(Color.FromRgb(76, 175, 80))
           : new SolidColorBrush(Color.FromRgb(42, 46, 69));

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>bool done → "✓" or "○" for sidebar nav icons.</summary>
public class BoolToIconConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true ? "✓" : "○";

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>bool done → green brush or muted blue-gray for sidebar dot/icon.</summary>
public class BoolToDotColorConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true
           ? new SolidColorBrush(Color.FromRgb(34, 197, 94))   // #22C55E green
           : new SolidColorBrush(Color.FromRgb(147, 197, 253)); // #93C5FD muted blue

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>bool done → green badge bg or yellow pending bg.</summary>
public class BoolToBadgeBgConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true
           ? new SolidColorBrush(Color.FromRgb(220, 252, 231))  // #DCFCE7 light green
           : new SolidColorBrush(Color.FromRgb(254, 249, 195)); // #FEF9C3 light yellow

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>bool done → "Done" or "Pending" badge text.</summary>
public class BoolToBadgeTextConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true ? "Done" : "Pending";

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>bool done → green text or amber text for badge label.</summary>
public class BoolToBadgeTextColorConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => value is true
           ? new SolidColorBrush(Color.FromRgb(21, 128, 61))   // #15803D dark green
           : new SolidColorBrush(Color.FromRgb(146, 64, 14));  // #92400E dark amber

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>non-empty string → green dot color, empty → muted.</summary>
public class PathToDotColorConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => !string.IsNullOrEmpty(value?.ToString())
           ? new SolidColorBrush(Color.FromRgb(34, 197, 94))
           : new SolidColorBrush(Color.FromRgb(147, 197, 253));

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>non-empty string → "✓" or "○".</summary>
public class PathToIconConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => !string.IsNullOrEmpty(value?.ToString()) ? "✓" : "○";

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}

/// <summary>
/// Dark mode color switcher — parameter = "LightColor|DarkColor" (hex strings).
/// Returns a SolidColorBrush matching the current mode.
/// Example: Converter={StaticResource DarkModeColor}, ConverterParameter="#FFFFFF|#1E293B"
/// </summary>
public class DarkModeColorConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
    {
        bool isDark = value is true;
        var param = p?.ToString() ?? "#000000|#FFFFFF";
        var parts = param.Split('|');
        string hex = isDark && parts.Length > 1 ? parts[1] : parts[0];
        try
        {
            var clr = (Color)ColorConverter.ConvertFromString(hex);
            return new SolidColorBrush(clr);
        }
        catch { return new SolidColorBrush(Colors.Transparent); }
    }

    public object ConvertBack(object value, Type t, object p, CultureInfo c)
        => throw new NotSupportedException();
}
