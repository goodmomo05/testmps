
namespace MpsAdjuster.Services;

/// <summary>
/// Mirrors modOSImport.bas
/// Source file → "OS" sheet in NEW MPS:
///   Col A = PRODUCT NO (text)
///   Col B = TOTAL QTY  (number)
/// </summary>
public class OsImportService(ExcelService xl)
{
    private const string DestSheet  = "OS";
    private const string HdrProduct = "Product No";
    private const string HdrTotal   = "Total";

    public Task<int> ImportAsync(string srcPath, string newMpsPath, IProgress<string>? p = null)
        => Task.Run(() => Import(srcPath, newMpsPath, p));

    private int Import(string srcPath, string newMpsPath, IProgress<string>? p)
    {
        using var tmp = XlsConverter.Prepare(srcPath);
        using var wbSrc = new XLWorkbook(tmp.Path);
        var wsSrc = wbSrc.Worksheet(1);

        int hdrRow = xl.FindHeaderRow(wsSrc, HdrProduct);
        if (hdrRow == 0)
            throw new InvalidOperationException($"Column '{HdrProduct}' not found in OS file.");

        var map     = xl.BuildHeaderMap(wsSrc, hdrRow);
        int colPart = xl.GetColumnByAnyHeader(map, HdrProduct);
        int colTot  = xl.GetColumnByAnyHeader(map, HdrTotal);

        if (colPart == 0) throw new InvalidOperationException($"Column '{HdrProduct}' not found.");
        if (colTot  == 0) throw new InvalidOperationException($"Column '{HdrTotal}' not found.");

        int lastRow = wsSrc.LastRowUsed()?.RowNumber() ?? 0;
        var rows    = new List<(string part, double total)>();

        for (int r = hdrRow + 1; r <= lastRow; r++)
        {
            var pStr = xl.CleanStr(wsSrc.Cell(r, colPart).Value);
            if (string.IsNullOrEmpty(pStr)) continue;
            var tVal = wsSrc.Cell(r, colTot).Value;
            rows.Add((pStr, tVal.IsNumber ? (double)tVal : 0));
        }

        p?.Report($"OS: {rows.Count} parts read. Writing…");

        using var wbNew  = new XLWorkbook(newMpsPath);
        var       wsDest = xl.GetOrCreateSheet(wbNew, DestSheet);

        wsDest.Cell(1, 1).Value        = "PRODUCT NO";
        wsDest.Cell(1, 2).Value        = "TOTAL QTY";
        wsDest.Row(1).Style.Font.Bold  = true;

        for (int i = 0; i < rows.Count; i++)
        {
            var c = wsDest.Cell(i + 2, 1);
            c.SetValue(rows[i].part);
            c.Style.NumberFormat.Format = "@";          // keep as text
            wsDest.Cell(i + 2, 2).Value = rows[i].total;
        }

        wsDest.Column(1).AdjustToContents();
        wsDest.Column(2).AdjustToContents();

        xl.LogLine(DestSheet, "IMPORT", $"{rows.Count} parts from: {srcPath}");
        wbNew.Save();
        return rows.Count;
    }
}
