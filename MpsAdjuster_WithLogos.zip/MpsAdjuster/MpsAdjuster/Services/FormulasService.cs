namespace MpsAdjuster.Services;

/// <summary>
/// Inserts formulas into every B- sheet.
///
/// HELPER ROWS (written first):
///   Row 2, cols D onwards: 2, 3, 4 … (salesCols+1)  — Sales VLOOKUP column index
///   Row 4, cols D onwards: 2, 3, 4 … (planCols+1)   — Plan  VLOOKUP column index
///
/// FOR EACH PART BLOCK (col A = bold numeric part number):
///   Row N+0 (Invt Qty) — COL D ONLY:
///     =IFERROR(VLOOKUP(A{N},OS!$A:$B,2,0),0)
///
///   Row N+1 (WIP) — COL D ONLY:
///     =IFERROR(VLOOKUP(A{N},WIP!$A:$B,2,0),0)
///
///   Row N+2 (Plan) — cols D to D+planCols-1:
///     =IFERROR(VLOOKUP($A{N},Plan!$A:B,D$4,0),0)   ← D uses index from row 4
///     =IFERROR(VLOOKUP($A{N},Plan!$A:C,E$4,0),0)   ← E  "
///     … expanding range and index per column
///
///   Row N+3 (Sales) — cols D to D+salesCols-1:
///     =IFERROR(VLOOKUP($A{N},Sales!$A:B,D$2,0),0)
///     =IFERROR(VLOOKUP($A{N},Sales!$A:C,E$2,0),0)
///     … expanding range and index per column
/// </summary>
public class FormulasService(ExcelService xl)
{
    private const string OsSheet    = "OS";
    private const string PlanSheet  = "Plan";
    private const string SalesSheet = "Sales";
    private const string WipSheet   = "WIP";
    private const int    D          = 4;   // First data column = col D = index 4

    public Task<int> InsertAsync(string newMpsPath, IProgress<string>? p = null)
        => Task.Run(() => Insert(newMpsPath, p));

    private int Insert(string newMpsPath, IProgress<string>? p)
    {
        using var wbNew = new XLWorkbook(newMpsPath);

        // Verify sheets exist
        foreach (var need in new[] { WipSheet, OsSheet, PlanSheet, SalesSheet })
            if (!wbNew.TryGetWorksheet(need, out _))
                throw new InvalidOperationException(
                    $"Sheet '{need}' not found. Run its import first.");

        // Count data columns in Plan and Sales (col A = part no, B+ = weeks)
        wbNew.TryGetWorksheet(PlanSheet,  out var wsPlan);
        wbNew.TryGetWorksheet(SalesSheet, out var wsSales);
        int planCols  = Math.Max(1, (wsPlan! .LastColumnUsed()?.ColumnNumber() ?? 1) - 1);
        int salesCols = Math.Max(1, (wsSales!.LastColumnUsed()?.ColumnNumber() ?? 1) - 1);

        int totalParts = 0;

        foreach (var ws in wbNew.Worksheets.ToList())
        {
            if (!ws.Name.StartsWith("B-", StringComparison.OrdinalIgnoreCase)) continue;
            p?.Report($"Inserting formulas into '{ws.Name}'…");

            try
            {
                // ── Write helper index rows ───────────────────────────────────
                // Row 2: Sales column indices  D2=2, E2=3, F2=4 …
                for (int c = 1; c <= salesCols; c++)
                    ws.Cell(2, D + c - 1).Value = c + 1;

                // Row 4: Plan column indices   D4=2, E4=3, F4=4 …
                for (int c = 1; c <= planCols; c++)
                    ws.Cell(4, D + c - 1).Value = c + 1;

                // ── Find part-number rows (col A, bold, all-digit value) ───────
                int lastRow      = ws.LastRowUsed()?.RowNumber() ?? 0;
                int partsInSheet = 0;

                for (int r = 12; r <= lastRow; r++)
                {
                    if (!IsPartRow(ws.Cell(r, 1))) continue;

                    // Use relative A reference (not $A) so VLOOKUP matches correctly
                    string partRef = $"A{r}";

                    // ── Invt Qty — col D only ─────────────────────────────────
                    var invt = ws.Cell(r, D);
                    invt.FormulaA1 =
                        $"=IFERROR(VLOOKUP({partRef},{OsSheet}!$A:$B,2,0),0)";
                    invt.Style.Fill.BackgroundColor = XLColor.LightGray;

                    // ── WIP — col D only ──────────────────────────────────────
                    var wip = ws.Cell(r + 1, D);
                    wip.FormulaA1 =
                        $"=IFERROR(VLOOKUP({partRef},{WipSheet}!$A:$B,2,0),0)";
                    wip.Style.Fill.BackgroundColor = XLColor.LightBlue;

                    // ── Plan — cols D to D+planCols-1 ────────────────────────
                    // Each column expands range: D→Plan!$A:B, E→Plan!$A:C …
                    // Helper ref: D$4=2, E$4=3 … used as column index in VLOOKUP
                    for (int c = 1; c <= planCols; c++)
                    {
                        string colLetter  = ExcelService.ColLetter(D + c - 1); // D, E, F…
                        string rangeLast  = ExcelService.ColLetter(c + 1);     // B, C, D…
                        string helperCell = colLetter + "$4";                  // D$4, E$4…
                        var planCell = ws.Cell(r + 2, D + c - 1);
                        planCell.FormulaA1 =
                            $"=IFERROR(VLOOKUP(${partRef}," +
                            $"{PlanSheet}!$A:{rangeLast},{helperCell},0),0)";
                        planCell.Style.Fill.BackgroundColor = XLColor.FromArgb(198, 239, 206);
                    }

                    // ── Sales — cols D to D+salesCols-1 ──────────────────────
                    // Helper ref: D$2=2, E$2=3 …
                    for (int c = 1; c <= salesCols; c++)
                    {
                        string colLetter  = ExcelService.ColLetter(D + c - 1);
                        string rangeLast  = ExcelService.ColLetter(c + 1);
                        string helperCell = colLetter + "$2";
                        var salesCell = ws.Cell(r + 3, D + c - 1);
                        salesCell.FormulaA1 =
                            $"=IFERROR(VLOOKUP(${partRef}," +
                            $"{SalesSheet}!$A:{rangeLast},{helperCell},0),0)";
                        salesCell.Style.Fill.BackgroundColor = XLColor.FromArgb(255, 213, 170);
                    }

                    partsInSheet++;
                    totalParts++;
                }

                xl.LogLine(ws.Name, "IMPORT", $"{partsInSheet} part(s) — formulas inserted");
            }
            catch (Exception ex)
            {
                xl.LogLine(ws.Name, "ERROR", $"Formulas: {ex.Message}");
            }
        }

        wbNew.Save();
        xl.LogLine("Formulas", "IMPORT",
            $"Done — {totalParts} part(s) across all B- sheets " +
            $"({planCols} plan weeks, {salesCols} sales weeks)");
        return totalParts;
    }

    /// <summary>True if cell is in col A, bold, and value is an all-digit string > 3 chars.</summary>
    private static bool IsPartRow(IXLCell cell)
    {
        if (!cell.Style.Font.Bold) return false;
        var v = cell.Value;
        if (v.IsBlank || v.IsError) return false;
        string txt = v.IsText   ? v.GetText()
                   : v.IsNumber ? ((long)v.GetNumber()).ToString()
                   : "";
        return txt.Length > 3 && txt.All(char.IsDigit);
    }
}
