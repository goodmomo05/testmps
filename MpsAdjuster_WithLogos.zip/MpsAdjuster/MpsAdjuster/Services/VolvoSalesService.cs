namespace MpsAdjuster.Services;

/// <summary>
/// Standalone Volvo (Ghent/Belgium) DELFOR processor.
///
/// CSV: comma-delimited, 5 metadata lines, line 6 = header.
/// Part numbers are plain integers (e.g. 32248170) — no lookup needed.
/// Multiple daily rows per ISO week are summed; the first date seen per ISO week
/// becomes the column header date (matching the VBA pivot behaviour).
/// Duplicate ISO week columns are merged (quantities summed, earliest date kept).
///
/// Output layout (matches Sheet2 of target):
///   Row 1 : "Sum of Quantity" | 15 | 16 | 17 | ... | "Grand Total"
///   Row 2 : "Row Labels"      | 07/04/2026 | 13/04/2026 | ...
///   Row 3+: Part No           | qty | ...
///   (no Grand Total row — last col IS Grand Total per the target)
///
/// Actually the target has Grand Total as the LAST COLUMN not last row.
/// Let's re-check: Row1 last col = "Grand Total", Row2 last col = no date.
/// So Grand Total is a column that sums across all week columns per part.
/// AND there's also a Grand Total ROW at the bottom.
/// </summary>
public class VolvoSalesService(ExcelService xl)
{
    private const string SheetName = "Volvo_Sales";
    private const string ColPart   = "Part No";
    private const string ColQty    = "Quantity";
    private const string ColDate   = "Start Date";

    public Task<(int parts, int weeks)> ImportAndExportAsync(
        string srcPath, string destPath, IProgress<string>? p = null)
        => Task.Run(() => Run(srcPath, destPath, p));

    private (int parts, int weeks) Run(string srcPath, string destPath, IProgress<string>? p)
    {
        p?.Report("Volvo: reading DELFOR file...");
        var rows = LoadCsv(srcPath);
        if (rows.Count == 0)
            throw new InvalidDataException("No data rows found in the DELFOR file.");

        p?.Report("Volvo: aggregating by part and ISO week...");
        // weekData[isoWeek] = (firstDate, dict[part] = totalQty)
        var weekData  = BuildWeekData(rows);
        var sortedWks = weekData.Keys.OrderBy(w => w).ToList();
        var allParts  = rows.Select(r => r.Part).Distinct().OrderBy(x => x).ToList();

        p?.Report($"Volvo: {allParts.Count} parts x {sortedWks.Count} weeks - exporting...");
        Export(allParts, weekData, sortedWks, destPath);
        return (allParts.Count, sortedWks.Count);
    }

    // ── Records ───────────────────────────────────────────────────────────
    private record Row(string Part, double Qty, DateTime Date, int IsoWeek);

    private record WeekInfo(DateTime FirstDate, Dictionary<string, double> PartQty);

    // ── Load CSV ──────────────────────────────────────────────────────────
    private List<Row> LoadCsv(string path)
    {
        var rows  = new List<Row>();
        var lines = File.ReadAllLines(path);

        // Find header line (contains "Part No")
        int headerIdx = -1;
        for (int i = 0; i < Math.Min(lines.Length, 15); i++)
        {
            if (lines[i].Contains("Part No", StringComparison.OrdinalIgnoreCase))
            { headerIdx = i; break; }
        }
        if (headerIdx < 0)
            throw new InvalidDataException("Cannot find header row with 'Part No' in CSV.");

        var hdr   = lines[headerIdx];
        char delim = hdr.Contains(';') && !hdr.Contains(',') ? ';' : ',';
        var hdrs  = hdr.Split(delim);

        int cPart = -1, cQty = -1, cDate = -1;
        for (int i = 0; i < hdrs.Length; i++)
        {
            var h = hdrs[i].Trim().Trim('"');
            if (h.Equals(ColPart, StringComparison.OrdinalIgnoreCase)) cPart = i;
            if (h.Equals(ColQty,  StringComparison.OrdinalIgnoreCase)) cQty  = i;
            if (h.Equals(ColDate, StringComparison.OrdinalIgnoreCase)) cDate = i;
        }
        if (cPart < 0 || cQty < 0 || cDate < 0)
            throw new InvalidDataException($"Required columns not found in CSV.");

        for (int i = headerIdx + 1; i < lines.Length; i++)
        {
            var line = lines[i];
            if (string.IsNullOrWhiteSpace(line)) continue;
            var f = line.Split(delim);
            if (f.Length <= Math.Max(cPart, Math.Max(cQty, cDate))) continue;

            var part = f[cPart].Trim().Trim('"');
            if (string.IsNullOrEmpty(part)) continue;

            if (!double.TryParse(f[cQty].Trim().Trim('"'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double qty)) continue;

            if (!TryParseDmy(f[cDate].Trim().Trim('"'), out DateTime dt)) continue;

            int isoWk = IsoWeekNumber(dt);
            rows.Add(new Row(part, qty, dt, isoWk));
        }
        return rows;
    }

    // ── Build week data: aggregate daily rows into weekly buckets ─────────
    private static Dictionary<int, WeekInfo> BuildWeekData(List<Row> rows)
    {
        var weekData = new Dictionary<int, WeekInfo>();

        foreach (var row in rows)
        {
            if (!weekData.TryGetValue(row.IsoWeek, out var info))
            {
                weekData[row.IsoWeek] = info = new WeekInfo(row.Date, new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase));
            }
            else if (row.Date < info.FirstDate)
            {
                // Keep the earliest date seen for this ISO week as the header
                weekData[row.IsoWeek] = info = new WeekInfo(row.Date, info.PartQty);
            }

            info.PartQty.TryGetValue(row.Part, out double ex);
            info.PartQty[row.Part] = ex + row.Qty;
        }

        return weekData;
    }

    // ── Export ────────────────────────────────────────────────────────────
    private void Export(
        List<string> parts,
        Dictionary<int, WeekInfo> weekData,
        List<int> sortedWks,
        string destPath)
    {
        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet(SheetName);
        int nW = sortedWks.Count;

        // Row 1 — "Sum of Quantity" + ISO week numbers + "Grand Total" column
        ws.Cell(1, 1).Value = "Sum of Quantity";
        for (int w = 0; w < nW; w++)
            ws.Cell(1, w + 2).Value = sortedWks[w];
        ws.Cell(1, nW + 2).Value = "Grand Total";
        ws.Row(1).Style.Font.Bold = true;

        // Row 2 — "Row Labels" + first date per week
        ws.Cell(2, 1).Value = "Row Labels";
        for (int w = 0; w < nW; w++)
        {
            var c = ws.Cell(2, w + 2);
            c.Value = weekData[sortedWks[w]].FirstDate;
            c.Style.NumberFormat.Format = "dd/mm/yyyy";
        }
        ws.Row(2).Style.Font.Bold = true;

        // Rows 3+ — part data
        int dataR = 3;
        foreach (var part in parts)
        {
            // Col A — part number (as text to preserve leading zeros if any)
            var partCell = ws.Cell(dataR, 1);
            if (long.TryParse(part, out long partNum))
                partCell.Value = partNum;
            else
                partCell.Value = part;

            double rowTotal = 0;
            for (int w = 0; w < nW; w++)
            {
                double qty = weekData[sortedWks[w]].PartQty.TryGetValue(part, out var q) ? q : 0;
                var cell = ws.Cell(dataR, w + 2);
                cell.Value = qty;
                cell.Style.NumberFormat.Format = "#,##0";
                rowTotal += qty;
            }

            // Grand Total column
            var gtCell = ws.Cell(dataR, nW + 2);
            gtCell.Value = rowTotal;
            gtCell.Style.NumberFormat.Format = "#,##0";

            dataR++;
        }

        // Grand Total row at the bottom
        ws.Cell(dataR, 1).Value = "Grand Total";
        ws.Row(dataR).Style.Font.Bold = true;
        for (int w = 0; w < nW; w++)
        {
            double total = parts.Sum(p => weekData[sortedWks[w]].PartQty.TryGetValue(p, out var q) ? q : 0);
            var cell = ws.Cell(dataR, w + 2);
            cell.Value = total;
            cell.Style.NumberFormat.Format = "#,##0";
        }
        double grandGrand = parts.Sum(p =>
            sortedWks.Sum(wk => weekData[wk].PartQty.TryGetValue(p, out var q) ? q : 0));
        var ggCell = ws.Cell(dataR, nW + 2);
        ggCell.Value = grandGrand;
        ggCell.Style.NumberFormat.Format = "#,##0";

        ws.Column(1).AdjustToContents();
        wb.SaveAs(destPath);

        xl.LogLine(SheetName, "EXPORT",
            $"{parts.Count} parts x {nW} weeks -> {Path.GetFileName(destPath)}");
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private static int IsoWeekNumber(DateTime dt)
    {
        var cal = System.Globalization.CultureInfo.InvariantCulture.Calendar;
        return cal.GetWeekOfYear(dt,
            System.Globalization.CalendarWeekRule.FirstFourDayWeek,
            DayOfWeek.Monday);
    }

    private static bool TryParseDmy(string s, out DateTime result)
    {
        if (DateTime.TryParseExact(s,
            new[] { "dd/MM/yyyy", "dd-MM-yyyy", "d/M/yyyy", "yyyy-MM-dd" },
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out result))
            return true;
        return DateTime.TryParse(s, out result);
    }
}
