
namespace MpsAdjuster.Services;

/// <summary>
/// Mirrors modSalesImport.bas
/// Reads "Sales" sheet → "Sales" sheet in NEW MPS:
///   Col A = PRODUCT NO  |  Col B+ = WK XX values
/// </summary>
public class SalesImportService(ExcelService xl)
{
    private const string SrcSheet  = "Sales";
    private const string HdrSews   = "SEWS-E Part Number";
    private const string DestSheet = "Sales";
    private const string WkPrefix  = "WK";

    public Task<(int parts, int weeks)> ImportAsync(
        string srcPath, string newMpsPath, IProgress<string>? p = null)
        => Task.Run(() => Import(srcPath, newMpsPath, p));

    private (int parts, int weeks) Import(
        string srcPath, string newMpsPath, IProgress<string>? p)
    {
        using var tmp = XlsConverter.Prepare(srcPath);
        using var wbSrc = new XLWorkbook(tmp.Path);

        if (!wbSrc.TryGetWorksheet(SrcSheet, out var wsSrc) || wsSrc is null)
            throw new InvalidOperationException($"Sheet '{SrcSheet}' not found.");

        int hdrRow = xl.FindHeaderRow(wsSrc, HdrSews);
        if (hdrRow == 0) throw new InvalidOperationException($"Header '{HdrSews}' not found.");

        var map     = xl.BuildHeaderMap(wsSrc, hdrRow);
        int colSews = map.TryGetValue(HdrSews, out var cs) ? cs : 0;
        if (colSews == 0) throw new InvalidOperationException($"Column '{HdrSews}' not found.");

        int lastHdrCol = wsSrc.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 0;
        var wkCols     = new List<int>();
        var wkNames    = new List<string>();
        for (int c = 1; c <= lastHdrCol; c++)
        {
            var h = xl.CleanStr(wsSrc.Cell(hdrRow, c).Value);
            if (h.StartsWith(WkPrefix, StringComparison.OrdinalIgnoreCase))
            { wkCols.Add(c); wkNames.Add(h); }
        }
        if (wkCols.Count == 0) throw new InvalidOperationException("No 'WK XX' columns found.");

        int lastRow   = wsSrc.LastRowUsed()?.RowNumber() ?? 0;
        var validRows = new List<int>();
        for (int r = hdrRow + 1; r <= lastRow; r++)
            if (!string.IsNullOrEmpty(xl.CleanStr(wsSrc.Cell(r, colSews).Value)))
                validRows.Add(r);

        if (validRows.Count == 0) throw new InvalidOperationException("No part numbers found.");

        p?.Report($"Sales: {validRows.Count} parts × {wkCols.Count} weeks. Writing…");

        using var wbNew  = new XLWorkbook(newMpsPath);
        var       wsDest = xl.GetOrCreateSheet(wbNew, DestSheet);

        wsDest.Cell(1, 1).Value       = "PRODUCT NO";
        for (int i = 0; i < wkNames.Count; i++)
            wsDest.Cell(1, i + 2).Value = wkNames[i];
        wsDest.Row(1).Style.Font.Bold = true;

        for (int i = 0; i < validRows.Count; i++)
        {
            int r     = validRows[i];
            int destR = i + 2;
            var c     = wsDest.Cell(destR, 1);
            c.SetValue(xl.CleanStr(wsSrc.Cell(r, colSews).Value));
            c.Style.NumberFormat.Format = "@";
            for (int w = 0; w < wkCols.Count; w++)
            {
                var v = wsSrc.Cell(r, wkCols[w]).Value;
                wsDest.Cell(destR, w + 2).Value = v.IsNumber ? (double)v : 0;
            }
        }

        wsDest.Column(1).AdjustToContents();
        for (int w = 2; w <= wkCols.Count + 1; w++)
            wsDest.Column(w).Width = 8;

        xl.LogLine(DestSheet, "IMPORT",
            $"{validRows.Count} parts × {wkCols.Count} weeks imported");
        wbNew.Save();
        return (validRows.Count, wkCols.Count);
    }
}
