
namespace MpsAdjuster.Services;

/// <summary>
/// Mirrors modEOSImport.bas
/// Finds sheet "End of Stock Week*", reads PART NUMBER + TOTAL QTY
/// → "WIP" sheet in NEW MPS.
/// </summary>
public class EosImportService(ExcelService xl)
{
    private const string EosPrefix    = "End of Stock Week";
    private const string HdrPart      = "PART NUMBER";
    private const string HdrQty       = "TOTAL QTY";
    private const string DestSheet    = "WIP";

    public Task<int> ImportAsync(string srcPath, string newMpsPath, IProgress<string>? p = null)
        => Task.Run(() => Import(srcPath, newMpsPath, p));

    private int Import(string srcPath, string newMpsPath, IProgress<string>? p)
    {
        using var tmp = XlsConverter.Prepare(srcPath);
        using var wbSrc = new XLWorkbook(tmp.Path);

        var wsSrc = wbSrc.Worksheets
            .FirstOrDefault(w => w.Name.StartsWith(EosPrefix, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"No sheet starting with '{EosPrefix}' found.");

        xl.LogLine(DestSheet, "INFO", $"Source sheet: '{wsSrc.Name}'");

        int hdrRow = xl.FindHeaderRow(wsSrc, HdrPart);
        if (hdrRow == 0) hdrRow = xl.FindHeaderRow(wsSrc, HdrQty);
        if (hdrRow == 0) throw new InvalidOperationException("Header row not found in EOS file.");

        var map     = xl.BuildHeaderMap(wsSrc, hdrRow);
        int colPart = map.TryGetValue(HdrPart, out var cp) ? cp : 0;
        int colQty  = map.TryGetValue(HdrQty,  out var cq) ? cq : 0;

        if (colPart == 0) throw new InvalidOperationException($"Column '{HdrPart}' not found.");
        if (colQty  == 0) throw new InvalidOperationException($"Column '{HdrQty}' not found.");

        int lastRow = wsSrc.LastRowUsed()?.RowNumber() ?? 0;
        var rows    = new List<(string part, double qty)>();

        for (int r = hdrRow + 1; r <= lastRow; r++)
        {
            var pStr = xl.CleanStr(wsSrc.Cell(r, colPart).Value);
            if (string.IsNullOrEmpty(pStr)) continue;
            var qVal = wsSrc.Cell(r, colQty).Value;
            rows.Add((pStr, qVal.IsNumber ? (double)qVal : 0));
        }

        p?.Report($"EOS/WIP: {rows.Count} rows read. Writing…");

        using var wbNew  = new XLWorkbook(newMpsPath);
        var       wsDest = xl.GetOrCreateSheet(wbNew, DestSheet);

        wsDest.Cell(1, 1).Value       = "PRODUCT NO";
        wsDest.Cell(1, 2).Value       = "TOTAL QTY";
        wsDest.Row(1).Style.Font.Bold = true;

        for (int i = 0; i < rows.Count; i++)
        {
            var c = wsDest.Cell(i + 2, 1);
            c.SetValue(rows[i].part);
            c.Style.NumberFormat.Format = "@";
            wsDest.Cell(i + 2, 2).Value = rows[i].qty;
        }

        wsDest.Column(1).AdjustToContents();
        wsDest.Column(2).AdjustToContents();

        xl.LogLine(DestSheet, "IMPORT", $"{rows.Count} rows from '{wsSrc.Name}'");
        wbNew.Save();
        return rows.Count;
    }
}
