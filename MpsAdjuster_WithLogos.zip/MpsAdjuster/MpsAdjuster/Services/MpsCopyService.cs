namespace MpsAdjuster.Services;

/// <summary>
/// MPS Copy — T- sheets only. Two operations:
///
/// 1. COPY from OLD MPS (matched by Week No + Plan Date):
///      Col 5  = SEWS-E WD
///      Col 6  = Cust WD
///      Cols 19-30 = Heads / Eff% / Week/Hrs / Team Qty (all 3 shifts)
///    Formulas are row-adjusted. Values are copied directly.
///    Cell background + font colours are also copied.
///
/// 2. LINK from matching B- sheet (formula strings only):
///      Col 7  = Invt Qty   → ='B-xxx'!D{invtRow}   (first data row only)
///      Col 8  = WIP        → ='B-xxx'!D{wipRow}    (first data row only)
///      Col 9  = Sales Qty  → ='B-xxx'!{weekCell}   (one per week row)
///      Col 13 = Assy Std.Hr→ ='B-xxx'!$D$avgRow    (all data rows)
///
/// Nothing else is touched in any sheet.
/// </summary>
public class MpsCopyService(ExcelService xl)
{
    private static readonly string[] AssyStdAliases =
    [
        "Avegare sales Std", "Average sales Std", "Average Sales Std",
        "Average sales Std.", "Avg Sales Std", "Average Std Hr", "Average Std.Hr"
    ];

    // T- column indices (from header row inspection)
    private const int ColSewsWD    = 5;   // SEWS-E WD
    private const int ColCustWD    = 6;   // Cust WD
    private const int ColInvt      = 7;   // Invt Qty
    private const int ColWip       = 8;   // WIP
    private const int ColSales     = 9;   // Sales Qty
    private const int ColAssyStdHr = 13;  // Assy Std.Hr.

    // Shift-block header names in the order they appear (Heads, Eff%, Week/Hrs, Team Qty × 3 shifts)
    // Used for name-based column matching to survive layout differences between OLD and NEW MPS
    private static readonly string[] ShiftHeaders =
    [
        "Heads", "Eff %", "Week/Hrs", "Team Qty",   // Shift 1
        "Heads", "Eff %", "Week/Hrs", "Team Qty",   // Shift 2
        "Heads", "Eff %", "Week/Hrs", "Team Qty"    // Shift 3
    ];

    public Task<int> RunAsync(string oldPath, string newPath, IProgress<string>? p = null)
        => Task.Run(() => Run(oldPath, newPath, p));

    private int Run(string oldPath, string newPath, IProgress<string>? p)
    {
        using var tmpOld = XlsConverter.Prepare(oldPath);
        using var wbOld  = new XLWorkbook(tmpOld.Path);
        using var wbNew  = new XLWorkbook(newPath);

        int copied = 0;

        // ── 1. COPY WD + shift cols from OLD → NEW T- sheets ─────────────────
        p?.Report("Copying SEWS-E WD, Cust WD and shift data from OLD MPS…");
        foreach (var wsN in wbNew.Worksheets.ToList())
        {
            if (!wsN.Name.StartsWith("T-", StringComparison.OrdinalIgnoreCase)) continue;

            if (!wbOld.TryGetWorksheet(wsN.Name, out var wsO) || wsO is null)
            { xl.LogLine(wsN.Name, "SKIP", "Not found in OLD MPS"); continue; }

            try { if (CopyFromOld(wsO!, wsN)) copied++; }
            catch (Exception ex) { xl.LogLine(wsN.Name, "ERROR", $"Copy: {ex.Message}"); }
        }

        // ── 2. LINK from B- sheets ────────────────────────────────────────────
        p?.Report("Linking Invt Qty, WIP, Sales Qty, Assy Std.Hr from B- sheets…");
        foreach (var wsT in wbNew.Worksheets.ToList())
        {
            if (!wsT.Name.StartsWith("T-", StringComparison.OrdinalIgnoreCase)) continue;
            try { LinkFromB(wsT, wbNew); }
            catch (Exception ex) { xl.LogLine(wsT.Name, "ERROR", $"Link: {ex.Message}"); }
        }

        // ── FORCE FULL RECALCULATION (Equivalent to Ctrl + Alt + F9) ──
        wbNew.CalculateMode = XLCalculateMode.Auto;
        wbNew.ForceFullCalculation = true;
        wbNew.FullCalculationOnLoad = true;

        wbNew.Save();
        return copied;
    }

    // ── COPY from OLD ─────────────────────────────────────────────────────────

    private bool CopyFromOld(IXLWorksheet wsOld, IXLWorksheet wsNew)
    {
        // Find header rows (row containing "Week No")
        int hdrO = xl.FindHeaderRow(wsOld, "Week No");
        int hdrN = xl.FindHeaderRow(wsNew,  "Week No");
        if (hdrO == 0 || hdrN == 0)
        { xl.LogLine(wsNew.Name, "SKIP", "Header 'Week No' not found"); return false; }

        // Find Plan Date / Week No columns
        int cPDO = FindColByName(wsOld, hdrO, "Plan Date", 3);
        int cPDN = FindColByName(wsNew,  hdrN, "Plan Date", 3);
        int cWkO = FindColByName(wsOld, hdrO, "Week No",   4);
        int cWkN = FindColByName(wsNew,  hdrN, "Week No",  4);

        // Build OLD lookup: "WK|yyyy-MM-dd" → row number
        var oldLookup = BuildLookup(wsOld, hdrO, cWkO, cPDO);

        // ── Build shift-column map by NAME ──
        var oldShiftCols = BuildShiftColMap(wsOld, hdrO);
        var newShiftCols = BuildShiftColMap(wsNew,  hdrN);
        int shiftPairs   = Math.Min(oldShiftCols.Count, newShiftCols.Count);

        if (shiftPairs == 0)
            xl.LogLine(wsNew.Name, "WARN", "No shift columns (Heads/Eff%/Week Hrs/Team Qty) found — skipped");

        int lastNewRow = wsNew.LastRowUsed()?.RowNumber() ?? hdrN;
        int rowsCopied = 0;

        for (int rN = hdrN + 1; rN <= lastNewRow; rN++)
        {
            string key = MakeKey(wsNew, rN, cWkN, cPDN);
            if (string.IsNullOrEmpty(key)) continue;
            if (!oldLookup.TryGetValue(key, out int rO)) continue;

            int offset = rN - rO;

            // SEWS-E WD (col 5)
            TransferCell(wsOld, rO, ColSewsWD, wsNew, rN, ColSewsWD, offset);

            // Cust WD (col 6)
            TransferCell(wsOld, rO, ColCustWD, wsNew, rN, ColCustWD, offset);

            // Shift columns — matched by name-order position, NOT by fixed index
            for (int i = 0; i < shiftPairs; i++)
                TransferCell(wsOld, rO, oldShiftCols[i], wsNew, rN, newShiftCols[i], offset);

            rowsCopied++;
        }

        xl.LogLine(wsNew.Name, "COPY",
            $"{rowsCopied} rows copied — {shiftPairs} shift col(s) matched by name (incl. cell colours)");
        return rowsCopied > 0;
    }

    /// <summary>
    /// Scan the header row and collect column numbers for shift headers
    /// (Heads, Eff %, Week/Hrs, Team Qty) in left-to-right appearance order.
    /// </summary>
    private List<int> BuildShiftColMap(IXLWorksheet ws, int hdrRow)
    {
        var result  = new List<int>();
        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 0;

        for (int c = 1; c <= lastCol; c++)
        {
            var h = xl.CleanStr(ws.Cell(hdrRow, c).Value);
            if (IsShiftHeader(h))
                result.Add(c);
        }
        return result;
    }

    private static bool IsShiftHeader(string h) =>
        h.Equals("Heads",    StringComparison.OrdinalIgnoreCase) ||
        h.Equals("Eff %",    StringComparison.OrdinalIgnoreCase) ||
        h.Equals("Week/Hrs", StringComparison.OrdinalIgnoreCase) ||
        h.Equals("Team Qty", StringComparison.OrdinalIgnoreCase);

    // ── LINK from B- ──────────────────────────────────────────────────────────

    private void LinkFromB(IXLWorksheet wsT, XLWorkbook wb)
    {
        string bName = "B-" + wsT.Name[2..];
        if (!wb.TryGetWorksheet(bName, out var wsB) || wsB is null)
        { xl.LogLine(wsT.Name, "SKIP-LINK", $"B- sheet not found: {bName}"); return; }

        int hdrT     = xl.FindHeaderRow(wsT, "Week No");
        if (hdrT == 0) return;
        int firstRow = hdrT + 1;
        int lastRow  = wsT.LastRowUsed()?.RowNumber() ?? hdrT;
        int rowCount = Math.Max(0, lastRow - firstRow + 1);

        // ── Invt Qty → first data row only ───────────────────────────────────
        string invtAddr = xl.FindBoldRedLabelNeighbor(wsB!, "Invt");
        if (!string.IsNullOrEmpty(invtAddr))
        {
            wsT.Cell(firstRow, ColInvt).FormulaA1 = $"='{bName}'!{invtAddr}";
            xl.LogLine(wsT.Name, "LINK", $"Invt Qty → '{bName}'!{invtAddr}");
        }

        // ── WIP → first data row only ─────────────────────────────────────────
        string wipAddr = xl.FindBoldRedLabelNeighbor(wsB!, "WIP");
        if (!string.IsNullOrEmpty(wipAddr))
        {
            wsT.Cell(firstRow, ColWip).FormulaA1 = $"='{bName}'!{wipAddr}";
            xl.LogLine(wsT.Name, "LINK", $"WIP → '{bName}'!{wipAddr}");
        }

        // ── Sales Qty → one formula per week row, borders preserved ──────────
        if (rowCount > 0)
        {
            int rSales = xl.FindBoldRedLabelRow(wsB!, "Sales");
            if (rSales > 0 && GetWeekSpanCols(wsB!, out int firstWk, out int lastWk))
            {
                int fill = Math.Min(lastWk - firstWk + 1, rowCount);
                for (int i = 0; i < fill; i++)
                {
                    string addr = wsB!.Cell(rSales, firstWk + i).Address.ToString() ?? "";
                    if (string.IsNullOrEmpty(addr)) continue;
                    var cell = wsT.Cell(firstRow + i, ColSales);
                    var existingBorder = cell.Style.Border;
                    cell.FormulaA1 = $"='{bName}'!{addr}";
                    cell.Style.Border.TopBorder         = existingBorder.TopBorder;
                    cell.Style.Border.TopBorderColor    = existingBorder.TopBorderColor;
                    cell.Style.Border.BottomBorder      = existingBorder.BottomBorder;
                    cell.Style.Border.BottomBorderColor = existingBorder.BottomBorderColor;
                    cell.Style.Border.LeftBorder        = existingBorder.LeftBorder;
                    cell.Style.Border.LeftBorderColor   = existingBorder.LeftBorderColor;
                    cell.Style.Border.RightBorder       = existingBorder.RightBorder;
                    cell.Style.Border.RightBorderColor  = existingBorder.RightBorderColor;
                }
                xl.LogLine(wsT.Name, "LINK-Sales",
                    $"Sales Qty <- '{bName}' row {rSales}, {fill} week(s), borders preserved");
            }
        }

        // ── Assy Std.Hr. → all data rows (same absolute cell) ────────────────
        int rLabel = xl.FindRowByAnyLabelInColumn(wsB!, AssyStdAliases, 1);
        if (rLabel > 0)
        {
            string absAddr = $"$D${rLabel}";
            for (int r = firstRow; r <= lastRow; r++)
                wsT.Cell(r, ColAssyStdHr).FormulaA1 = $"='{bName}'!{absAddr}";
            xl.LogLine(wsT.Name, "LINK-AssyStdHr", $"All rows → '{bName}'!{absAddr}");
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Dictionary<string, int> BuildLookup(
        IXLWorksheet ws, int hdrRow, int colWk, int colDate)
    {
        var d    = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        int last = ws.LastRowUsed()?.RowNumber() ?? hdrRow;
        for (int r = hdrRow + 1; r <= last; r++)
        {
            string k = MakeKey(ws, r, colWk, colDate);
            if (!string.IsNullOrEmpty(k) && !d.ContainsKey(k))
                d[k] = r;
        }
        return d;
    }

    private string MakeKey(IXLWorksheet ws, int row, int colWk, int colDate)
    {
        try
        {
            var wkVal = ws.Cell(row, colWk).Value;
            if (wkVal.IsBlank) return "";
            string wk = wkVal.IsNumber
                ? ((int)wkVal.GetNumber()).ToString()
                : xl.CleanStr(wkVal);
            if (string.IsNullOrEmpty(wk)) return "";

            var dtVal   = ws.Cell(row, colDate).Value;
            string date = "";
            if      (dtVal.IsDateTime) date = dtVal.GetDateTime().ToString("yyyy-MM-dd");
            else if (dtVal.IsNumber)   date = DateTime.FromOADate(dtVal.GetNumber()).ToString("yyyy-MM-dd");
            else if (dtVal.IsText)     date = dtVal.GetText().Trim();

            return string.IsNullOrEmpty(date) ? wk : $"{wk}|{date}";
        }
        catch { return ""; }
    }

    private int FindColByName(IXLWorksheet ws, int hdrRow, string name, int fallback)
    {
        int last = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 0;
        for (int c = 1; c <= last; c++)
            if (xl.CleanStr(ws.Cell(hdrRow, c).Value)
                  .Equals(name, StringComparison.OrdinalIgnoreCase))
                return c;
        return fallback;
    }

    /// <summary>
    /// Copy one cell: value/formula + background fill colour + font colour.
    /// Formulas are row-adjusted by offset. Borders in the destination are preserved.
    /// </summary>
    private static void TransferCell(
        IXLWorksheet src, int sR, int sC,
        IXLWorksheet dst, int dR, int dC,
        int rowOffset)
    {
        try
        {
            var s = src.Cell(sR, sC);
            var d = dst.Cell(dR, dC);

            // ── 1. Value / formula ────────────────────────────────────────────
            if (s.HasFormula)
            {
                d.FormulaA1 = rowOffset == 0
                    ? s.FormulaA1
                    : AdjustRows(s.FormulaA1, rowOffset);
            }
            else
            {
                var v = s.Value;
                if      (v.IsBlank)    { }
                else if (v.IsBoolean)  d.Value = v.GetBoolean();
                else if (v.IsNumber)   d.Value = v.GetNumber();
                else if (v.IsDateTime) d.Value = v.GetDateTime();
                else if (v.IsTimeSpan) d.Value = v.GetTimeSpan();
                else if (v.IsText)     d.Value = v.GetText();
            }

            // ── 2. Background fill colour ─────────────────────────────────────
            // Only copy when the source has an actual fill (not the default "None" pattern).
            var srcFill = s.Style.Fill;
            if (srcFill.PatternType != XLFillPatternValues.None)
            {
                d.Style.Fill.PatternType     = srcFill.PatternType;
                d.Style.Fill.BackgroundColor = srcFill.BackgroundColor;
                d.Style.Fill.PatternColor    = srcFill.PatternColor;
            }

            // ── 3. Font colour ────────────────────────────────────────────────
            d.Style.Font.FontColor = s.Style.Font.FontColor;
        }
        catch { }
    }

    /// <summary>
    /// Shift all unlocked row numbers in a formula string by offset.
    /// $A$12 → unchanged (both locked). A12 or $A12 → row shifts.
    /// </summary>
    private static string AdjustRows(string f, int offset) =>
        Regex.Replace(f,
            @"(\$?[A-Za-z]{1,3})(\$?)(\d+)",
            m =>
            {
                if (m.Groups[2].Value == "$") return m.Value; // row locked
                if (!int.TryParse(m.Groups[3].Value, out int row)) return m.Value;
                return m.Groups[1].Value + Math.Max(1, row + offset);
            });

    /// <summary>Find week date columns in B- row 11 (strings like "30/03").</summary>
    private bool GetWeekSpanCols(IXLWorksheet ws, out int first, out int last)
    {
        first = 0; last = 0;
        int lc = ws.LastColumnUsed()?.ColumnNumber() ?? 0;
        for (int c = 4; c <= lc; c++)
        {
            try
            {
                var v = ws.Cell(11, c).Value;
                bool hit = v.IsDateTime ||
                           (v.IsText && Regex.IsMatch(v.GetText().Trim(), @"^\d{1,2}/\d{1,2}$"));
                if (!hit) continue;
                if (first == 0) first = c;
                last = c;
            }
            catch { }
        }
        return first > 0 && last >= first;
    }
}
