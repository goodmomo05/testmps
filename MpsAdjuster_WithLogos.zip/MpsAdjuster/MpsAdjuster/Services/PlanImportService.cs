
namespace MpsAdjuster.Services;

/// <summary>
/// Mirrors modPlanImport.bas
/// Merges multiple "Planning System" files → "Plan" sheet:
///   Col A = PRODUCT NO  |  Col B+ = one column per week
/// </summary>
public class PlanImportService(ExcelService xl)
{
    private const string SrcSheet   = "Planning System";
    private const string HdrProduct = "Product No";
    private const string HdrPlanned = "Planned Output";
    private const int    ProductCol = 4;   // col D
    private const int    FromDateRow= 4;
    private const int    FromDateCol= 6;   // col F
    private const string SkipLabel  = "Total";
    private const int    SkipCol    = 3;   // col C
    private const string DestSheet  = "Plan";

    public Task<(int parts, int weeks)> ImportAsync(
        IEnumerable<string> srcPaths, string newMpsPath, IProgress<string>? p = null)
        => Task.Run(() => Import([.. srcPaths], newMpsPath, p));

    private (int parts, int weeks) Import(
        List<string> files, string newMpsPath, IProgress<string>? p)
    {
        var partOrder = new List<string>();
        var partText  = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var weekOrder = new List<string>();
        var weekSet   = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var data      = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        foreach (var file in files)
        {
            p?.Report($"Plan: reading {Path.GetFileName(file)}…");
            CollectOne(file, partOrder, partText, weekOrder, weekSet, data);
        }

        p?.Report($"Plan: {partOrder.Count} parts × {weekOrder.Count} weeks. Writing…");

        using var wbNew  = new XLWorkbook(newMpsPath);
        var       wsDest = xl.GetOrCreateSheet(wbNew, DestSheet);

        wsDest.Cell(1, 1).Value       = "PRODUCT NO";
        for (int w = 0; w < weekOrder.Count; w++)
            wsDest.Cell(1, w + 2).Value = weekOrder[w];
        wsDest.Row(1).Style.Font.Bold = true;

        for (int i = 0; i < partOrder.Count; i++)
        {
            string pKey  = partOrder[i];
            int    destR = i + 2;
            var    cell  = wsDest.Cell(destR, 1);
            cell.SetValue(partText[pKey]);
            cell.Style.NumberFormat.Format = "@";

            for (int w = 0; w < weekOrder.Count; w++)
                wsDest.Cell(destR, w + 2).Value =
                    data.TryGetValue($"{pKey}|{weekOrder[w]}", out var qty) ? qty : 0;
        }

        wsDest.Column(1).AdjustToContents();

        xl.LogLine(DestSheet, "IMPORT",
            $"{partOrder.Count} parts × {weekOrder.Count} weeks written");
        wbNew.Save();
        return (partOrder.Count, weekOrder.Count);
    }

    private void CollectOne(
        string planPath,
        List<string> partOrder, Dictionary<string, string> partText,
        List<string> weekOrder, HashSet<string> weekSet,
        Dictionary<string, double> data)
    {
        try
        {
            using var tmp = XlsConverter.Prepare(planPath);
            using var wbSrc = new XLWorkbook(tmp.Path);
            if (!wbSrc.TryGetWorksheet(SrcSheet, out var wsSrc) || wsSrc is null)
            {
                xl.LogLine("Plan", "SKIP", $"Sheet '{SrcSheet}' not found: {planPath}");
                return;
            }

            int    weekNum  = DetectWeekNumber(wsSrc);
            string weekName = weekNum > 0 ? $"WK{weekNum}" : "WK?";
            if (!weekSet.Contains(weekName)) { weekOrder.Add(weekName); weekSet.Add(weekName); }

            int hdrRow = xl.FindHeaderRow(wsSrc, HdrProduct);
            if (hdrRow == 0)
            {
                xl.LogLine("Plan", "SKIP", $"Header '{HdrProduct}' not found: {planPath}");
                return;
            }

            // Scan ALL header cells for "Planned Output" — BuildHeaderMap deduplicates
            // by key so only returns the FIRST match. This file has 19 repeated
            // "Planned Output" columns (one per shift per day), so we must scan manually.
            int lastHdrCol = wsSrc.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 0;
            var plannedCols = Enumerable.Range(1, lastHdrCol)
                .Where(c => xl.CleanStr(wsSrc.Cell(hdrRow, c).Value)
                               .Replace("\n", " ")
                               .Contains(HdrPlanned, StringComparison.OrdinalIgnoreCase))
                .ToList();

            int lastRow = wsSrc.LastRowUsed()?.RowNumber() ?? 0;
            for (int r = hdrRow + 1; r <= lastRow; r++)
            {
                if (xl.CleanStr(wsSrc.Cell(r, SkipCol).Value)
                      .Equals(SkipLabel, StringComparison.OrdinalIgnoreCase)) continue;

                var rawPart = wsSrc.Cell(r, ProductCol).Value;
                string pKey = xl.CleanStr(rawPart);
                if (string.IsNullOrEmpty(pKey)) continue;

                if (!partText.ContainsKey(pKey))
                {
                    partOrder.Add(pKey);
                    partText[pKey] = rawPart.ToString() ?? pKey;
                }

                double total = plannedCols
                    .Select(c => wsSrc.Cell(r, c).Value)
                    .Where(v => v.IsNumber)
                    .Sum(v => (double)v);

                string dKey = $"{pKey}|{weekName}";
                data[dKey]  = data.TryGetValue(dKey, out var ex) ? ex + total : total;
            }

            xl.LogLine("Plan", "INFO", $"{weekName} collected from: {planPath}");
        }
        catch (Exception ex)
        {
            xl.LogLine("Plan", "ERROR", $"{ex.Message} | {planPath}");
        }
    }

    private static int DetectWeekNumber(IXLWorksheet ws)
    {
        try
        {
            var v = ws.Cell(FromDateRow, FromDateCol).Value;
            DateTime dt;
            if      (v.IsDateTime)                          dt = v.GetDateTime();
            else if (DateTime.TryParse(v.ToString(), out dt)) { }
            else return 0;

            var cal = System.Globalization.CultureInfo.InvariantCulture.Calendar;
            return cal.GetWeekOfYear(dt,
                System.Globalization.CalendarWeekRule.FirstDay,
                DayOfWeek.Monday) + 1;
        }
        catch { return 0; }
    }
}
