namespace MpsAdjuster.Services;

/// <summary>Shared Excel helpers — mirrors modShared.bas</summary>
public class ExcelService
{
    public ObservableCollection<LogEntry> Log { get; } = [];

    // ── Logging ───────────────────────────────────────────────────────────────
    public void LogLine(string sheet, string result, string note)
    {
        Application.Current.Dispatcher.Invoke(() =>
            Log.Add(new LogEntry { Sheet = sheet, Result = result, Note = note }));
    }

    // ── Backup ────────────────────────────────────────────────────────────────
    public string BackupSmart(string srcPath)
    {
        if (string.IsNullOrEmpty(srcPath)) return "";
        var dir  = Path.GetDirectoryName(srcPath)!;
        var name = Path.GetFileNameWithoutExtension(srcPath);
        var ext  = Path.GetExtension(srcPath);
        var ts   = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        try
        {
            var dst = Path.Combine(dir, $"{name}_BACKUP_{ts}{ext}");
            File.Copy(srcPath, dst, overwrite: true);
            LogLine("SYSTEM", "BACKUP", $"Saved: {dst}");
            return dst;
        }
        catch { }
        try
        {
            var bkDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups");
            Directory.CreateDirectory(bkDir);
            var dst = Path.Combine(bkDir, $"{name}_BACKUP_{ts}{ext}");
            File.Copy(srcPath, dst, overwrite: true);
            LogLine("SYSTEM", "BACKUP", $"Saved (Backups folder): {dst}");
            return dst;
        }
        catch (Exception ex)
        {
            LogLine("SYSTEM", "ERROR", $"Backup failed: {ex.Message}");
            return "";
        }
    }

    // ── Header scanning ───────────────────────────────────────────────────────
    public int FindHeaderRow(IXLWorksheet ws, string mustContain)
    {
        int scanRows = Math.Min(50, ws.LastRowUsed()?.RowNumber() ?? 1);
        for (int r = 1; r <= scanRows; r++)
        {
            int lastCol = ws.Row(r).LastCellUsed()?.Address.ColumnNumber ?? 0;
            for (int c = 1; c <= lastCol; c++)
                if (string.Equals(CleanStr(ws.Cell(r, c).Value), mustContain,
                                  StringComparison.OrdinalIgnoreCase))
                    return r;
        }
        return 0;
    }

    public Dictionary<string, int> BuildHeaderMap(IXLWorksheet ws, int hdrRow)
    {
        var map     = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 0;
        for (int c = 1; c <= lastCol; c++)
        {
            var h = CleanStr(ws.Cell(hdrRow, c).Value);
            if (!string.IsNullOrEmpty(h) && !map.ContainsKey(h))
                map[h] = c;
        }
        return map;
    }

    public int GetColumnByAnyHeader(Dictionary<string, int> map, params string[] aliases)
    {
        foreach (var a in aliases)
            if (map.TryGetValue(a, out int col)) return col;
        return 0;
    }

    // ── Value helpers ─────────────────────────────────────────────────────────
    public string CleanStr(XLCellValue v)
    {
        if (v.IsBlank || v.IsError) return "";
        try
        {
            if (v.IsText)     return v.GetText().Trim();
            if (v.IsNumber)   return v.GetNumber().ToString().Trim();
            if (v.IsBoolean)  return v.GetBoolean().ToString().Trim();
            if (v.IsDateTime) return v.GetDateTime().ToString().Trim();
            return "";
        }
        catch { return ""; }
    }

    public string CleanStr(string? s) => s?.Trim() ?? "";

    public int FindContiguousLastRow(IXLWorksheet ws, int col, int startRow)
    {
        if (string.IsNullOrEmpty(CleanStr(ws.Cell(startRow, col).Value)))
            return startRow - 1;
        int r = startRow;
        while (!string.IsNullOrEmpty(CleanStr(ws.Cell(r, col).Value)))
            r++;
        return r - 1;
    }

    public int FindRowByKey(IXLWorksheet ws, int keyCol, int startRow, string key)
    {
        int lastR = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = startRow; r <= lastR; r++)
            if (string.Equals(CleanStr(ws.Cell(r, keyCol).Value), key,
                               StringComparison.OrdinalIgnoreCase))
                return r;
        return 0;
    }

    // ── Formula cleaners ──────────────────────────────────────────────────────
    public string RemoveWorkbookQualifier(string f)
        => Regex.Replace(f, @"'[^']*\[[^\]]+\]", "'");

    public string RemoveExternalAddSubTerms(string f)
    {
        f = Regex.Replace(f, @"[+\-]\s*'[^']*\[[^\]]+\][^']+'![A-Za-z]{1,3}\d+", "");
        f = Regex.Replace(f, @"[+\-]\s*\[[^\]]+\][^!]+![A-Za-z]{1,3}\d+", "");
        f = Regex.Replace(f, @"=\s*[+\-]?\s*'[^']*\[[^\]]+\][^']+'![A-Za-z]{1,3}\d+(\s*[+\-]\s*)?", "=");
        f = Regex.Replace(f, @"=\s*[+\-]?\s*\[[^\]]+\][^!]+![A-Za-z]{1,3}\d+(\s*[+\-]\s*)?", "=");
        return f;
    }

    public string NormalizeFormulaSigns(string f)
    {
        f = Regex.Replace(f, @"([+\-])\s+", "$1");
        f = Regex.Replace(f, @"(=\s*)\+", "$1");
        f = f.Replace("++", "+").Replace("+-", "-").Replace("-+", "-");
        if (f == "=()") f = "=";
        return f;
    }

    // ── Sheet helpers ─────────────────────────────────────────────────────────
    public IXLWorksheet GetOrCreateSheet(XLWorkbook wb, string name)
    {
        if (wb.TryGetWorksheet(name, out var ws) && ws is not null)
        {
            ws.Clear();
            LogLine(name, "INFO", $"Sheet '{name}' exists – cleared");
            return ws;
        }
        var newWs = wb.AddWorksheet(name);
        LogLine(name, "INFO", $"Sheet '{name}' created");
        return newWs;
    }

    // ── Bold + Red detection ──────────────────────────────────────────────────
    // In the actual MPS file, red font uses indexed color 10 (HSSF/XSSF red index).
    // We check BOTH RGB (r>=180,g<=100,b<=100) AND indexed color 10.

    public bool IsBoldAndRed(IXLCell cell)
    {
        if (!cell.Style.Font.Bold) return false;
        var clr = cell.Style.Font.FontColor;
        try
        {
            // Check indexed color — index 10 = red in Excel's built-in palette
            if (clr.ColorType == XLColorType.Indexed && clr.Indexed == 10)
                return true;
            // Check RGB
            if (clr.ColorType == XLColorType.Color)
            {
                var c = clr.Color;
                return c.R >= 180 && c.G <= 100 && c.B <= 100;
            }
        }
        catch { }
        return false;
    }

    /// <summary>
    /// Scan col C for a cell containing keyword that is Bold AND red-colored.
    /// Returns the address of col D on the same row, or "".
    /// </summary>
    public string FindBoldRedLabelNeighbor(IXLWorksheet ws, string keyword)
    {
        int lastR = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = 1; r <= lastR; r++)
        {
            var cell = ws.Cell(r, 3);
            var txt  = CleanStr(cell.Value);
            if (txt.Contains(keyword, StringComparison.OrdinalIgnoreCase) && IsBoldAndRed(cell))
                return ws.Cell(r, 4).Address.ToString() ?? "";
        }
        return "";
    }

    /// <summary>Scan col C for keyword in Bold+Red; return row number.</summary>
    public int FindBoldRedLabelRow(IXLWorksheet ws, string keyword)
    {
        int lastR = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = 1; r <= lastR; r++)
        {
            var cell = ws.Cell(r, 3);
            var txt  = CleanStr(cell.Value);
            if (txt.Contains(keyword, StringComparison.OrdinalIgnoreCase) && IsBoldAndRed(cell))
                return r;
        }
        return 0;
    }

    /// <summary>Find first row in labelCol whose text contains any alias.</summary>
    public int FindRowByAnyLabelInColumn(IXLWorksheet ws, string[] aliases, int labelCol)
    {
        int lastR = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = 1; r <= lastR; r++)
        {
            var txt = CleanStr(ws.Cell(r, labelCol).Value);
            if (string.IsNullOrEmpty(txt)) continue;
            foreach (var a in aliases)
                if (txt.Contains(a, StringComparison.OrdinalIgnoreCase)) return r;
        }
        return 0;
    }

    // ── Column letter ↔ number ────────────────────────────────────────────────
    public static string ColLetter(int col)
    {
        var s = "";
        while (col > 0) { int rem = (col-1)%26; s = (char)('A'+rem)+s; col=(col-1)/26; }
        return s;
    }

    public static int ColNumber(string letters)
    {
        int n = 0;
        foreach (char ch in letters.ToUpperInvariant())
            n = n * 26 + (ch - 'A' + 1);
        return n;
    }
}
