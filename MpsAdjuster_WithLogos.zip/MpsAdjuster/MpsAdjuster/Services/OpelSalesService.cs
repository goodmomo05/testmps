namespace MpsAdjuster.Services;

/// <summary>
/// Standalone Opel DELFOR processor.
///
/// CSV format: comma-delimited, first 5 lines are metadata, line 6 is the header.
/// Part No is in Adient format (e.g. "4898611-0-1"); a lookup file maps this
/// to the SEWS-E internal part number (e.g. "4898611").
///
/// Output layout (matches target PivotValues (2)):
///   Row 1 : "Sum of Quantity" | "Lookup" (SEWS-E Part No) | ...
///   Row 2 : "ISO Week"        | ""       | 14 | 15 | ...
///   Row 3 : "Row Labels"      | ""       | 30/03/2026 | ...
///   Row 4+: Adient Part No    | SEWS-E   | qty | ...
///   Last  : "Grand Total"     | ""       | sum | ...
/// </summary>
public class OpelSalesService(ExcelService xl)
{
    private const string SheetName  = "Opel_Sales";
    private const string ColPart    = "Part No";
    private const string ColQty     = "Quantity";
    private const string ColDate    = "Start Date";
    private const int    MetaLines  = 5;   // CSV header rows to skip

    public Task<(int parts, int weeks)> ImportAndExportAsync(
        string srcPath, string lookupPath, string destPath, IProgress<string>? p = null)
        => Task.Run(() => Run(srcPath, lookupPath, destPath, p));

    // ── Orchestrator ──────────────────────────────────────────────────────
    private (int parts, int weeks) Run(
        string srcPath, string lookupPath, string destPath, IProgress<string>? p)
    {
        p?.Report("Opel: loading lookup table...");
        var lookup = LoadLookup(lookupPath);

        p?.Report("Opel: reading DELFOR file...");
        var rows = LoadCsv(srcPath);
        if (rows.Count == 0)
            throw new InvalidDataException("No data rows found in the DELFOR file.");

        p?.Report("Opel: aggregating by part and week...");
        var agg   = Aggregate(rows);
        var weeks = BuildWeekList(agg);

        p?.Report($"Opel: {agg.Count} parts x {weeks.Count} weeks - exporting...");
        Export(agg, weeks, lookup, destPath);
        return (agg.Count, weeks.Count);
    }

    // ── Lookup: Adient Part No -> SEWS-E Part No ─────────────────────────
    private Dictionary<string, string> LoadLookup(string path)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using var tmp = XlsConverter.Prepare(path);
        using var wb  = new XLWorkbook(tmp.Path);
        var ws = wb.Worksheets.FirstOrDefault()
            ?? throw new InvalidDataException("Lookup file has no worksheets.");

        int lastRow = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = 2; r <= lastRow; r++)   // skip header row 1
        {
            var adient = xl.CleanStr(ws.Cell(r, 1).Value);
            var sewsE  = xl.CleanStr(ws.Cell(r, 2).Value);
            if (!string.IsNullOrEmpty(adient) && !string.IsNullOrEmpty(sewsE))
                map[adient] = sewsE;
        }
        return map;
    }

    // ── Load CSV ──────────────────────────────────────────────────────────
    private record Row(string Part, double Qty, DateTime Date);

    private List<Row> LoadCsv(string path)
    {
        var rows  = new List<Row>();
        var lines = File.ReadAllLines(path);

        // Find the real header line (contains "Part No")
        int headerIdx = -1;
        for (int i = 0; i < Math.Min(lines.Length, 15); i++)
        {
            if (lines[i].Contains("Part No", StringComparison.OrdinalIgnoreCase))
            { headerIdx = i; break; }
        }
        if (headerIdx < 0)
            throw new InvalidDataException("Could not find header row with 'Part No' in CSV.");

        // Detect delimiter from header line
        var headerLine = lines[headerIdx];
        char delim = headerLine.Contains(';') && !headerLine.Contains(',') ? ';' : ',';

        // Parse header
        var headers = headerLine.Split(delim);
        int cPart = -1, cQty = -1, cDate = -1;
        for (int i = 0; i < headers.Length; i++)
        {
            var h = headers[i].Trim().Trim('"');
            if (h.Equals(ColPart, StringComparison.OrdinalIgnoreCase)) cPart = i;
            if (h.Equals(ColQty,  StringComparison.OrdinalIgnoreCase)) cQty  = i;
            if (h.Equals(ColDate, StringComparison.OrdinalIgnoreCase)) cDate = i;
        }
        if (cPart < 0 || cQty < 0 || cDate < 0)
            throw new InvalidDataException($"Required columns ({ColPart}, {ColQty}, {ColDate}) not found in CSV.");

        // Parse data rows
        for (int i = headerIdx + 1; i < lines.Length; i++)
        {
            var line = lines[i];
            if (string.IsNullOrWhiteSpace(line)) continue;
            var f = line.Split(delim);
            if (f.Length <= Math.Max(cPart, Math.Max(cQty, cDate))) continue;

            var part = f[cPart].Trim().Trim('"');
            if (string.IsNullOrEmpty(part)) continue;

            if (!double.TryParse(f[cQty].Trim().Trim('"'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double qty)) continue;

            if (!TryParseDmy(f[cDate].Trim().Trim('"'), out DateTime dt)) continue;

            rows.Add(new Row(part, qty, dt));
        }
        return rows;
    }

    // ── Aggregate: part -> (ISO Monday -> total qty) ──────────────────────
    private static Dictionary<string, Dictionary<DateTime, double>> Aggregate(List<Row> rows)
    {
        var agg = new Dictionary<string, Dictionary<DateTime, double>>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in rows)
        {
            var mon = IsoMonday(row.Date);
            if (!agg.TryGetValue(row.Part, out var wkMap))
                agg[row.Part] = wkMap = [];
            wkMap.TryGetValue(mon, out double ex);
            wkMap[mon] = ex + row.Qty;
        }
        return agg;
    }

    // ── Build continuous week list (fill gaps) ────────────────────────────
    private static List<DateTime> BuildWeekList(
        Dictionary<string, Dictionary<DateTime, double>> agg)
    {
        var all  = agg.Values.SelectMany(d => d.Keys).Distinct().OrderBy(d => d).ToList();
        if (all.Count == 0) return [];
        var list = new List<DateTime>();
        var cur  = all[0];
        while (cur <= all[^1]) { list.Add(cur); cur = cur.AddDays(7); }
        return list;
    }

    // ── Export to new xlsx ────────────────────────────────────────────────
    private void Export(
        Dictionary<string, Dictionary<DateTime, double>> agg,
        List<DateTime> weeks,
        Dictionary<string, string> lookup,
        string destPath)
    {
        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet(SheetName);
        int nW = weeks.Count;

        // Row 1 — title
        ws.Cell(1, 1).Value = "Sum of Quantity";
        ws.Cell(1, 2).Value = "Lookup";
        ws.Row(1).Style.Font.Bold = true;

        // Row 2 — ISO week numbers (start from col C = 3)
        ws.Cell(2, 1).Value = "ISO Week";
        for (int w = 0; w < nW; w++)
            ws.Cell(2, w + 3).Value = IsoWeekNumber(weeks[w]);
        ws.Row(2).Style.Font.Bold = true;

        // Row 3 — labels + Monday dates from col C
        ws.Cell(3, 1).Value = "Row Labels";
        for (int w = 0; w < nW; w++)
        {
            var c = ws.Cell(3, w + 3);
            c.Value = weeks[w];
            c.Style.NumberFormat.Format = "dd/mm/yyyy";
        }
        ws.Row(3).Style.Font.Bold = true;

        // Rows 4+ — data
        var parts = agg.Keys.OrderBy(k => k).ToList();
        int dataR = 4;
        foreach (var part in parts)
        {
            // Col A = Adient Part No
            ws.Cell(dataR, 1).Value = part;
            ws.Cell(dataR, 1).Style.NumberFormat.Format = "@";

            // Col B = SEWS-E Part No (lookup)
            if (lookup.TryGetValue(part, out var sewsE) && !string.IsNullOrEmpty(sewsE))
            {
                ws.Cell(dataR, 2).Value = sewsE;
                ws.Cell(dataR, 2).Style.NumberFormat.Format = "@";
            }

            // Col C+ = weekly quantities
            var wkMap = agg[part];
            for (int w = 0; w < nW; w++)
            {
                double qty = wkMap.TryGetValue(weeks[w], out var q) ? q : 0;
                var cell = ws.Cell(dataR, w + 3);
                cell.Value = qty;
                cell.Style.NumberFormat.Format = "#,##0";
            }
            dataR++;
        }

        // Grand Total row
        ws.Cell(dataR, 1).Value = "Grand Total";
        ws.Row(dataR).Style.Font.Bold = true;
        for (int w = 0; w < nW; w++)
        {
            double total = parts.Sum(p => agg[p].TryGetValue(weeks[w], out var q) ? q : 0);
            var cell = ws.Cell(dataR, w + 3);
            cell.Value = total;
            cell.Style.NumberFormat.Format = "#,##0";
        }

        ws.Column(1).AdjustToContents();
        ws.Column(2).AdjustToContents();
        wb.SaveAs(destPath);

        xl.LogLine(SheetName, "EXPORT",
            $"{parts.Count} parts x {nW} weeks -> {Path.GetFileName(destPath)}");
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private static DateTime IsoMonday(DateTime dt)
    {
        int dow = (int)dt.DayOfWeek;
        return dt.Date.AddDays(dow == 0 ? -6 : -(dow - 1));
    }

    private static int IsoWeekNumber(DateTime dt)
    {
        var cal = System.Globalization.CultureInfo.InvariantCulture.Calendar;
        return cal.GetWeekOfYear(dt,
            System.Globalization.CalendarWeekRule.FirstFourDayWeek,
            DayOfWeek.Monday);
    }

    private static bool TryParseDmy(string s, out DateTime result)
    {
        if (DateTime.TryParseExact(s,
            new[] { "dd/MM/yyyy", "dd-MM-yyyy", "d/M/yyyy", "yyyy-MM-dd" },
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out result))
            return true;
        return DateTime.TryParse(s, out result);
    }
}
