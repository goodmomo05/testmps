using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace MpsAdjuster.Services;

/// <summary>
/// Converts a legacy .xls file to a temporary .xlsx using NPOI,
/// so ClosedXML can open it. The caller is responsible for deleting
/// the temp file when done (use the returned TempXlsx wrapper).
/// </summary>
public static class XlsConverter
{
    /// <summary>
    /// If path ends with .xls, converts it to a temp .xlsx and returns
    /// a wrapper holding the new path. Otherwise returns the original path.
    /// Always call .Dispose() (or use in a using block) to clean up temp files.
    /// </summary>
    public static TempXlsx Prepare(string path)
    {
        if (!path.EndsWith(".xls", StringComparison.OrdinalIgnoreCase))
            return new TempXlsx(path, isTemp: false);

        var tempPath = Path.Combine(Path.GetTempPath(),
            $"mpsadj_{Guid.NewGuid():N}.xlsx");

        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
        IWorkbook xlsWb = new HSSFWorkbook(fs);
        IWorkbook xlsxWb = new XSSFWorkbook();

        for (int si = 0; si < xlsWb.NumberOfSheets; si++)
        {
            var srcSheet = xlsWb.GetSheetAt(si);
            var dstSheet = xlsxWb.CreateSheet(srcSheet.SheetName);

            for (int ri = srcSheet.FirstRowNum; ri <= srcSheet.LastRowNum; ri++)
            {
                var srcRow = srcSheet.GetRow(ri);
                if (srcRow == null) continue;
                var dstRow = dstSheet.CreateRow(ri);

                for (int ci = srcRow.FirstCellNum; ci < srcRow.LastCellNum; ci++)
                {
                    var srcCell = srcRow.GetCell(ci);
                    if (srcCell == null) continue;
                    var dstCell = dstRow.CreateCell(ci);

                    switch (srcCell.CellType)
                    {
                        case CellType.Numeric:
                            dstCell.SetCellValue(srcCell.NumericCellValue);
                            // Preserve date formatting
                            if (DateUtil.IsCellDateFormatted(srcCell))
                            {
                                var style = xlsxWb.CreateCellStyle();
                                style.DataFormat = xlsxWb.CreateDataFormat()
                                    .GetFormat("yyyy-mm-dd");
                                dstCell.CellStyle = style;
                            }
                            break;
                        case CellType.String:
                            dstCell.SetCellValue(srcCell.StringCellValue);
                            break;
                        case CellType.Boolean:
                            dstCell.SetCellValue(srcCell.BooleanCellValue);
                            break;
                        case CellType.Formula:
                            // Copy as the cached string/numeric value (safe for import)
                            try { dstCell.SetCellValue(srcCell.NumericCellValue); }
                            catch { dstCell.SetCellValue(srcCell.ToString()); }
                            break;
                        default:
                            dstCell.SetCellValue(srcCell.ToString());
                            break;
                    }

                    // Copy font bold + colour for bold-red detection
                    CopyFontStyle(xlsWb, xlsxWb, srcCell, dstCell);
                }
            }
        }

        using var outFs = new FileStream(tempPath, FileMode.Create, FileAccess.Write);
        xlsxWb.Write(outFs);

        return new TempXlsx(tempPath, isTemp: true);
    }

    private static void CopyFontStyle(
        IWorkbook srcWb, IWorkbook dstWb,
        ICell srcCell, ICell dstCell)
    {
        try
        {
            var srcFont = srcWb.GetFontAt(srcCell.CellStyle.FontIndex);
            if (!srcFont.IsBold && srcFont.Color == 0) return;

            var dstFont = dstWb.CreateFont();
            dstFont.IsBold = srcFont.IsBold;

            // NPOI colour index 10 = red (HSSF indexed palette)
            if (srcFont.Color == 10 || srcFont.Color == 2)  // red variants
                dstFont.Color = NPOI.HSSF.Util.HSSFColor.Red.Index;
            else
                dstFont.Color = srcFont.Color;

            var dstStyle = dstWb.CreateCellStyle();
            dstStyle.CloneStyleFrom(dstCell.CellStyle);
            dstStyle.SetFont(dstFont);
            dstCell.CellStyle = dstStyle;
        }
        catch { /* style copy is best-effort */ }
    }
}

/// <summary>Wraps a (possibly temporary) xlsx path and deletes it on Dispose.</summary>
public sealed class TempXlsx : IDisposable
{
    public string Path    { get; }
    private bool  _isTemp;
    private bool  _disposed;

    public TempXlsx(string path, bool isTemp) { Path = path; _isTemp = isTemp; }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_isTemp && File.Exists(Path))
            try { File.Delete(Path); } catch { /* ignore */ }
    }
}
