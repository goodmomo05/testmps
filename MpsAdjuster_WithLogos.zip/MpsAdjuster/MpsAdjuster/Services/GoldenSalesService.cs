namespace MpsAdjuster.Services;

/// <summary>
/// Standalone Golde (Slovakia) DELFOR processor.
/// Reads a CSV or Excel DELFOR file, builds a pivot-style result, and exports
/// it to a brand-new .xlsx file — no MPS file required.
///
/// Output sheet layout:
///   Row 1 : "Sum of Quantity" | "Start Date" | ...
///   Row 2 : "ISO Week"        | 17 | 18 | ...
///   Row 3 : "Part No"         | 20/04/2026 | ...
///   Row 4+: part              | qty | ...
///   Last  : "Grand Total"     | sum | ...
/// </summary>
public class GoldenSalesService(ExcelService xl)
{
    private const string SheetName = "Golde_Sales";
    private const string ColPart   = "Part No";
    private const string ColQty    = "Quantity";
    private const string ColDate   = "Start Date";

    public Task<(int parts, int weeks)> ImportAndExportAsync(
        string srcPath, string destPath, IProgress<string>? p = null)
        => Task.Run(() => Run(srcPath, destPath, p));

    private (int parts, int weeks) Run(string srcPath, string destPath, IProgress<string>? p)
    {
        p?.Report("Golde Sales: reading source file...");
        var rows = LoadRows(srcPath);
        if (rows.Count == 0)
            throw new InvalidDataException("No data rows found in the source file.");

        p?.Report("Golde Sales: aggregating by part and week...");
        var agg   = Aggregate(rows);
        var weeks = BuildWeekList(agg);

        p?.Report($"Golde Sales: {agg.Count} parts x {weeks.Count} weeks - exporting...");
        Export(agg, weeks, destPath);
        return (agg.Count, weeks.Count);
    }

    // ── Load ─────────────────────────────────────────────────────────────
    private record Row(string Part, double Qty, DateTime Date);

    private List<Row> LoadRows(string path)
    {
        var ext = Path.GetExtension(path).TrimStart('.').ToLowerInvariant();
        return ext == "csv" ? LoadCsv(path) : LoadExcel(path);
    }

    private static List<Row> LoadCsv(string path)
    {
        var rows  = new List<Row>();
        char delim = ',';

        using (var sr = new StreamReader(path))
            while (!sr.EndOfStream)
            {
                var first = sr.ReadLine();
                if (string.IsNullOrWhiteSpace(first)) continue;
                if (first.Contains(';') && !first.Contains(',')) delim = ';';
                break;
            }

        using var reader = new StreamReader(path);
        bool headerDone = false;
        int cPart = -1, cQty = -1, cDate = -1;

        while (!reader.EndOfStream)
        {
            var line = reader.ReadLine();
            if (string.IsNullOrWhiteSpace(line)) continue;
            var f = line.Split(delim);

            if (!headerDone)
            {
                for (int i = 0; i < f.Length; i++)
                {
                    var h = f[i].Trim().Trim('"');
                    if (h.Equals(ColPart, StringComparison.OrdinalIgnoreCase)) cPart = i;
                    if (h.Equals(ColQty,  StringComparison.OrdinalIgnoreCase)) cQty  = i;
                    if (h.Equals(ColDate, StringComparison.OrdinalIgnoreCase)) cDate = i;
                }
                headerDone = true;
                continue;
            }

            if (cPart < 0 || cQty < 0 || cDate < 0) continue;
            if (f.Length <= Math.Max(cPart, Math.Max(cQty, cDate))) continue;

            var part = f[cPart].Trim().Trim('"');
            if (string.IsNullOrEmpty(part)) continue;

            if (!double.TryParse(f[cQty].Trim().Trim('"'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double qty)) continue;

            if (!TryParseDmy(f[cDate].Trim().Trim('"'), out DateTime dt)) continue;

            rows.Add(new Row(part, qty, dt));
        }
        return rows;
    }

    private List<Row> LoadExcel(string path)
    {
        var rows = new List<Row>();
        using var tmp = XlsConverter.Prepare(path);
        using var wb  = new XLWorkbook(tmp.Path);
        var ws = wb.Worksheets.FirstOrDefault()
            ?? throw new InvalidDataException("Excel file has no worksheets.");

        int hdrRow = xl.FindHeaderRow(ws, ColPart);
        if (hdrRow == 0) throw new InvalidDataException($"Header '{ColPart}' not found.");

        var map   = xl.BuildHeaderMap(ws, hdrRow);
        int cPart = map.TryGetValue(ColPart, out var cp) ? cp : 0;
        int cQty  = map.TryGetValue(ColQty,  out var cq) ? cq : 0;
        int cDate = map.TryGetValue(ColDate, out var cd) ? cd : 0;

        if (cPart == 0 || cQty == 0 || cDate == 0)
            throw new InvalidDataException("Required columns (Part No, Quantity, Start Date) not found.");

        int last = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (int r = hdrRow + 1; r <= last; r++)
        {
            var part = xl.CleanStr(ws.Cell(r, cPart).Value);
            if (string.IsNullOrEmpty(part)) continue;
            var qv = ws.Cell(r, cQty).Value;
            if (!qv.IsNumber) continue;
            var dv = ws.Cell(r, cDate).Value;
            DateTime dt;
            if (dv.IsDateTime) dt = dv.GetDateTime();
            else if (!TryParseDmy(xl.CleanStr(dv), out dt)) continue;
            rows.Add(new Row(part, (double)qv, dt));
        }
        return rows;
    }

    // ── Aggregate ─────────────────────────────────────────────────────────
    private static Dictionary<string, Dictionary<DateTime, double>> Aggregate(List<Row> rows)
    {
        var agg = new Dictionary<string, Dictionary<DateTime, double>>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in rows)
        {
            var mon = IsoMonday(row.Date);
            if (!agg.TryGetValue(row.Part, out var wkMap))
                agg[row.Part] = wkMap = [];
            wkMap.TryGetValue(mon, out double ex);
            wkMap[mon] = ex + row.Qty;
        }
        return agg;
    }

    // ── Build continuous week list ────────────────────────────────────────
    private static List<DateTime> BuildWeekList(
        Dictionary<string, Dictionary<DateTime, double>> agg)
    {
        var all = agg.Values.SelectMany(d => d.Keys).Distinct().OrderBy(d => d).ToList();
        if (all.Count == 0) return [];
        var list = new List<DateTime>();
        var cur  = all[0];
        while (cur <= all[^1]) { list.Add(cur); cur = cur.AddDays(7); }
        return list;
    }

    // ── Export to new xlsx ────────────────────────────────────────────────
    private void Export(
        Dictionary<string, Dictionary<DateTime, double>> agg,
        List<DateTime> weeks,
        string destPath)
    {
        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet(SheetName);
        int nW = weeks.Count;

        // Row 1 — title
        ws.Cell(1, 1).Value = "Sum of Quantity";
        ws.Cell(1, 2).Value = "Start Date";
        ws.Row(1).Style.Font.Bold = true;

        // Row 2 — ISO week numbers
        ws.Cell(2, 1).Value = "ISO Week";
        for (int w = 0; w < nW; w++)
            ws.Cell(2, w + 2).Value = IsoWeekNumber(weeks[w]);
        ws.Row(2).Style.Font.Bold = true;

        // Row 3 — Part No + Monday dates as headers
        ws.Cell(3, 1).Value = "Part No";
        for (int w = 0; w < nW; w++)
        {
            var c = ws.Cell(3, w + 2);
            c.Value = weeks[w];
            c.Style.NumberFormat.Format = "dd/mm/yyyy";
        }
        ws.Row(3).Style.Font.Bold = true;

        // Rows 4+ — data
        var parts = agg.Keys.OrderBy(k => k).ToList();
        int dataR = 4;
        foreach (var part in parts)
        {
            ws.Cell(dataR, 1).Value = part;
            var wkMap = agg[part];
            for (int w = 0; w < nW; w++)
            {
                double qty = wkMap.TryGetValue(weeks[w], out var q) ? q : 0;
                var c = ws.Cell(dataR, w + 2);
                c.Value = qty;
                c.Style.NumberFormat.Format = "#,##0";
            }
            dataR++;
        }

        // Grand Total row
        ws.Cell(dataR, 1).Value = "Grand Total";
        ws.Row(dataR).Style.Font.Bold = true;
        for (int w = 0; w < nW; w++)
        {
            double total = parts.Sum(p => agg[p].TryGetValue(weeks[w], out var q) ? q : 0);
            var c = ws.Cell(dataR, w + 2);
            c.Value = total;
            c.Style.NumberFormat.Format = "#,##0";
        }

        ws.Column(1).AdjustToContents();
        wb.SaveAs(destPath);
        xl.LogLine(SheetName, "EXPORT",
            $"{parts.Count} parts x {nW} weeks -> {Path.GetFileName(destPath)}");
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private static DateTime IsoMonday(DateTime dt)
    {
        int dow = (int)dt.DayOfWeek;
        return dt.Date.AddDays(dow == 0 ? -6 : -(dow - 1));
    }

    private static int IsoWeekNumber(DateTime dt)
    {
        var cal = System.Globalization.CultureInfo.InvariantCulture.Calendar;
        return cal.GetWeekOfYear(dt,
            System.Globalization.CalendarWeekRule.FirstFourDayWeek,
            DayOfWeek.Monday);
    }

    private static bool TryParseDmy(string s, out DateTime result)
    {
        if (DateTime.TryParseExact(s,
            new[] { "dd/MM/yyyy", "dd-MM-yyyy", "d/M/yyyy", "yyyy-MM-dd" },
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out result))
            return true;
        return DateTime.TryParse(s, out result);
    }
}
