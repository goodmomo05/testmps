using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MpsAdjuster.Views;

/// <summary>
/// Modal dialog asking the user to choose between 1 Package or 2 Packages.
/// Shows a clear description of what each mode calculates.
/// </summary>
public partial class PackageSelectDialog : Window
{
    public PackageMode SelectedMode { get; private set; } = PackageMode.OnePackage;

    public PackageSelectDialog()
    {
        InitializeComponent();
        Owner = Application.Current.MainWindow;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
    }

    private void Pkg1_Click(object sender, RoutedEventArgs e)
    {
        SelectedMode = PackageMode.OnePackage;
        DialogResult = true;
    }

    private void Pkg2_Click(object sender, RoutedEventArgs e)
    {
        SelectedMode = PackageMode.TwoPackages;
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }
}
