# Daily Upload Feature — Integration Guide

## Overview
This feature adds a **Daily Upload (CZ)** button to MpsAdjuster that:
1. Accepts one or more raw `DailyBuild_Report_DENSO_CZ.xlsx`-style files
2. Asks the user to choose **1 Package** or **2 Packages**
3. Asks for an MPS template (dates-only header row)
4. Writes the aggregated output into the template and saves it

---

## Files Added

| File | Purpose |
|------|---------|
| `Services/DailyUploadService.cs` | All processing logic — load, merge, aggregate, write |
| `Views/PackageSelectDialog.xaml` | WPF dialog for package mode selection |
| `Views/PackageSelectDialog.xaml.cs` | Code-behind for the dialog |
| `ViewModels/MainViewModel_DailyUpload.cs` | Partial class — ViewModel additions |
| `Views/MainWindow_DailyUpload_snippet.xaml` | XAML snippet for the sidebar nav button |

---

## Step-by-Step Integration

### 1. Add `DailyUploadService.cs`
Copy `Services/DailyUploadService.cs` into:
```
MpsAdjuster/MpsAdjuster/Services/DailyUploadService.cs
```
No changes needed — it uses the same `ExcelService` and `XlsConverter` already in the project.

---

### 2. Add the Dialog
Copy both dialog files into:
```
MpsAdjuster/MpsAdjuster/Views/PackageSelectDialog.xaml
MpsAdjuster/MpsAdjuster/Views/PackageSelectDialog.xaml.cs
```

In `PackageSelectDialog.xaml`, make sure the `x:Class` attribute matches your namespace:
```xml
x:Class="MpsAdjuster.Views.PackageSelectDialog"
```

---

### 3. Wire up MainViewModel.cs

Open `ViewModels/MainViewModel.cs` and make **four** small additions:

**A — Field** (with the other private service fields, ~line 10):
```csharp
private DailyUploadService _dailyUpload;
```

**B — Command declaration** (with the other `IAsyncRelayCommand` properties, ~line 30):
```csharp
public IAsyncRelayCommand DailyUploadCommand { get; }
```

**C — Constructor wiring** (inside `MainViewModel()`, after the other service `new()` lines):
```csharp
_dailyUpload       = new DailyUploadService(Xl);
DailyUploadCommand = new AsyncRelayCommand(DailyUploadAsync);
```

**D — Async method + save dialog** (paste the full content from
`ViewModels/MainViewModel_DailyUpload.cs` as new methods at the bottom of the class,
just before the closing `}`).

---

### 4. Add the Sidebar Button to MainWindow.xaml

Open `MainWindow.xaml` and find the `VolvoSalesCommand` button block (~line 392).
Paste the content of `Views/MainWindow_DailyUpload_snippet.xaml` **after** that button,
still inside the same `StackPanel`.

---

### 5. Register the Dialog in XAML (if using resource dictionaries)

If your project uses a `Views` folder that requires explicit inclusion, add the dialog
to the project in Visual Studio — right-click `Views` → Add → Existing Item → select both files.
Visual Studio will auto-set the Build Action to `Page` for the `.xaml` and `Compile` for `.cs`.

---

## Raw File Format Expected

The service auto-detects the header row by looking for Excel date values in row columns B+.
The layout of `DailyBuild_Report_DENSO_CZ.xlsx` is:

| Col A       | Col B (Sat) | Col C (Sun) | Col D (Mon) | Col E (Tue) | Col F (Wed) | Col G (Thu) | Col H (Fri) |
|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|
| Part Number | qty         | qty         | qty         | qty         | qty         | qty         | qty         |

- Header row: Part label in A, date serial/DateTime values in B–H.
- Dates are sorted by value and assigned Sat→Fri order (0–6).
- Multiple files are merged and grouped by part number (case-insensitive).
- Blank / missing quantities are treated as 0.
- Duplicate part numbers across files are summed.

## Template Format Expected

The template (`templete.xlsx`) must have:
- A header row containing at least one **Saturday** date value (for 1 Package or Pkg1 of 2 Packages)
- A **Monday** date value (required only for 2 Packages / Pkg2)
- Column A reserved for part numbers (left empty in template)

The service clears any existing data rows below the header before writing results.

---

## Package Logic Summary

| Mode       | Pkg1 days     | Written under | Pkg2 days          | Written under |
|------------|---------------|---------------|--------------------|---------------|
| 1 Package  | Sat+Sun+Mon+Tue+Wed+Thu+Fri | Saturday col | — | — |
| 2 Packages | Sat+Sun+Mon   | Saturday col  | Tue+Wed+Thu+Fri    | Monday col    |
