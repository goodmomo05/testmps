namespace MpsAdjuster.Services;

/// <summary>
/// Daily Upload feature.
///
/// RAW FILE LAYOUT (DailyBuild_Report_DENSO_CZ.xlsx style):
///   Row 1 : header row — col A = part number label, cols B+ = date values (Excel serial or DateTime).
///   Row 2+: data — col A = part number string, cols B+ = qty doubles.
///
/// Week columns are always Saturday → Friday (7 days, indices 0-6):
///   Sat=0, Sun=1, Mon=2, Tue=3, Wed=4, Thu=5, Fri=6
///
/// Package modes:
///   1 Package  → sum all 7 days  → place under Saturday date in template
///   2 Packages → pkg1 = Sat+Sun+Mon (indices 0-2)  → place under Saturday date
///                pkg2 = Tue+Wed+Thu+Fri (indices 3-6) → place under Monday date
/// </summary>
public class DailyUploadService(ExcelService xl)
{
    // ── Public entry point ────────────────────────────────────────────────────

    public Task<int> RunAsync(
        string[]        rawPaths,
        string          templatePath,
        string          outputPath,
        PackageMode     mode,
        IProgress<string>? p = null)
        => Task.Run(() => Run(rawPaths, templatePath, outputPath, mode, p));

    // ── Core pipeline ─────────────────────────────────────────────────────────

    private int Run(
        string[]        rawPaths,
        string          templatePath,
        string          outputPath,
        PackageMode     mode,
        IProgress<string>? p)
    {
        p?.Report("Daily Upload: reading raw file(s)…");

        // 1. Load and merge all raw files
        var merged = LoadAndMerge(rawPaths);
        if (merged.Count == 0)
            throw new InvalidDataException("No data rows found in the selected raw file(s).");

        // 2. Aggregate by part number
        p?.Report($"Daily Upload: aggregating {merged.Count} record(s)…");
        var aggregated = Aggregate(merged, mode);

        // 3. Load template and discover date columns
        p?.Report("Daily Upload: reading template…");
        using var wbTpl = new XLWorkbook(templatePath);
        var wsTpl = wbTpl.Worksheets.First();
        var (satCol, monCol) = FindTemplateDateColumns(wsTpl);

        if (satCol == 0)
            throw new InvalidDataException(
                "Could not find a Saturday date column in the template. " +
                "Ensure the template's header row contains date values.");

        if (mode == PackageMode.TwoPackages && monCol == 0)
            throw new InvalidDataException(
                "2-Package mode requires a Monday date column in the template. " +
                "Ensure the template's header row contains a Monday date.");

        // 4. Write results into a copy of the template
        p?.Report("Daily Upload: writing output…");
        File.Copy(templatePath, outputPath, overwrite: true);

        using var wbOut = new XLWorkbook(outputPath);
        var wsOut = wbOut.Worksheets.First();

        int firstDataRow = WriteResults(wsOut, aggregated, satCol, monCol, mode);

        wbOut.Save();

        xl.LogLine("DailyUpload", "OK",
            $"{aggregated.Count} part(s) written — mode={mode} — {outputPath}");

        return aggregated.Count;
    }

    // ── Step 1 : Load & Merge ─────────────────────────────────────────────────

    private record RawRow(string Part, double[] DayQtys);  // DayQtys[0]=Sat … [6]=Fri

    private List<RawRow> LoadAndMerge(string[] paths)
    {
        var all = new List<RawRow>();
        foreach (var path in paths)
        {
            using var tmpFile = XlsConverter.Prepare(path);
            using var wb = new XLWorkbook(tmpFile.Path);
            var ws = wb.Worksheets.First();
            all.AddRange(ReadRawSheet(ws));
            xl.LogLine("DailyUpload", "INFO", $"Loaded {Path.GetFileName(path)}");
        }
        return all;
    }

    private List<RawRow> ReadRawSheet(IXLWorksheet ws)
    {
        var rows = new List<RawRow>();

        // Detect header row (first row containing at least one date value in cols B+)
        int hdrRow = DetectHeaderRow(ws);
        if (hdrRow == 0) return rows;

        // Build column map: colIndex → day-of-week (0=Sat, 6=Fri)
        // We read up to 7 date columns starting from the first date found
        var dayColMap = BuildDayColumnMap(ws, hdrRow);   // col# → dayIndex (0-6)
        if (dayColMap.Count == 0) return rows;

        int lastRow = ws.LastRowUsed()?.RowNumber() ?? hdrRow;

        for (int r = hdrRow + 1; r <= lastRow; r++)
        {
            var partCell = ws.Cell(r, 1);
            var part = xl.CleanStr(partCell.Value);
            if (string.IsNullOrWhiteSpace(part)) continue;

            var qtys = new double[7];
            foreach (var (col, dayIdx) in dayColMap)
            {
                var cell = ws.Cell(r, col);
                if (cell.Value.IsNumber)
                    qtys[dayIdx] += cell.Value.GetNumber();
                else if (double.TryParse(xl.CleanStr(cell.Value), out double d))
                    qtys[dayIdx] += d;
            }

            rows.Add(new RawRow(part, qtys));
        }

        return rows;
    }

    /// <summary>Find the first row where at least one col B+ cell is a date.</summary>
    private static int DetectHeaderRow(IXLWorksheet ws)
    {
        int lastRow = Math.Min(ws.LastRowUsed()?.RowNumber() ?? 1, 20);
        for (int r = 1; r <= lastRow; r++)
        {
            int lastCol = ws.Row(r).LastCellUsed()?.Address.ColumnNumber ?? 1;
            for (int c = 2; c <= lastCol; c++)
            {
                if (CellIsDate(ws.Cell(r, c))) return r;
            }
        }
        return 0;
    }

    /// <summary>
    /// Returns a mapping from column number → day index (0=Sat,…,6=Fri).
    /// Reads up to 7 consecutive date columns starting from the first date found.
    /// </summary>
    private static Dictionary<int, int> BuildDayColumnMap(IXLWorksheet ws, int hdrRow)
    {
        var map = new Dictionary<int, int>();
        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 1;
        var dates = new List<(int col, DateTime date)>();

        for (int c = 2; c <= lastCol; c++)
        {
            var cell = ws.Cell(hdrRow, c);
            if (TryGetDate(cell, out DateTime dt))
                dates.Add((c, dt));
        }

        if (dates.Count == 0) return map;

        // Sort by date and assign day indices 0-6 (Sat=0)
        dates.Sort((a, b) => a.date.CompareTo(b.date));
        int count = Math.Min(dates.Count, 7);
        for (int i = 0; i < count; i++)
            map[dates[i].col] = i;

        return map;
    }

    // ── Step 2 : Aggregate ────────────────────────────────────────────────────

    public record AggRow(string Part, double Pkg1, double Pkg2);

    private List<AggRow> Aggregate(List<RawRow> rows, PackageMode mode)
    {
        // Group by part number, sum qtys
        var grouped = rows
            .GroupBy(r => r.Part, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var summed = new double[7];
                foreach (var row in g)
                    for (int i = 0; i < 7; i++)
                        summed[i] += row.DayQtys[i];

                double pkg1, pkg2;
                if (mode == PackageMode.OnePackage)
                {
                    pkg1 = summed.Sum();
                    pkg2 = 0;
                }
                else
                {
                    pkg1 = summed[0] + summed[1] + summed[2]; // Sat+Sun+Mon
                    pkg2 = summed[3] + summed[4] + summed[5] + summed[6]; // Tue+Wed+Thu+Fri
                }

                return new AggRow(g.Key, pkg1, pkg2);
            })
            .OrderBy(r => r.Part)
            .ToList();

        return grouped;
    }

    // ── Step 3 : Find template date columns ───────────────────────────────────

    /// <summary>
    /// Returns (satColNumber, monColNumber) in the template's first header row.
    /// Saturday = DayOfWeek.Saturday, Monday = DayOfWeek.Monday.
    /// </summary>
    private static (int satCol, int monCol) FindTemplateDateColumns(IXLWorksheet ws)
    {
        int hdrRow = DetectHeaderRow(ws);
        if (hdrRow == 0) return (0, 0);

        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 1;
        int satCol = 0, monCol = 0;

        for (int c = 2; c <= lastCol; c++)
        {
            if (!TryGetDate(ws.Cell(hdrRow, c), out DateTime dt)) continue;

            if (dt.DayOfWeek == DayOfWeek.Saturday && satCol == 0) satCol = c;
            if (dt.DayOfWeek == DayOfWeek.Monday   && monCol == 0) monCol = c;

            if (satCol != 0 && monCol != 0) break;
        }

        return (satCol, monCol);
    }

    // ── Step 4 : Write results ────────────────────────────────────────────────

    private int WriteResults(
        IXLWorksheet ws,
        List<AggRow> rows,
        int satCol,
        int monCol,
        PackageMode mode)
    {
        // Find next empty row after the header
        int hdrRow = DetectHeaderRow(ws);
        int dataStart = hdrRow > 0 ? hdrRow + 1 : 2;

        // Clear existing data rows (preserve header)
        int lastExisting = ws.LastRowUsed()?.RowNumber() ?? dataStart;
        if (lastExisting >= dataStart)
            ws.Rows(dataStart, lastExisting).Delete();

        int row = dataStart;
        foreach (var agg in rows)
        {
            ws.Cell(row, 1).Value = agg.Part;

            if (agg.Pkg1 != 0)
                ws.Cell(row, satCol).Value = agg.Pkg1;

            if (mode == PackageMode.TwoPackages && agg.Pkg2 != 0 && monCol != 0)
                ws.Cell(row, monCol).Value = agg.Pkg2;

            row++;
        }

        return dataStart;
    }

    // ── Date helpers ──────────────────────────────────────────────────────────

    private static bool CellIsDate(IXLCell cell)
        => TryGetDate(cell, out _);

    private static bool TryGetDate(IXLCell cell, out DateTime dt)
    {
        dt = default;
        var v = cell.Value;

        if (v.IsDateTime) { dt = v.GetDateTime(); return true; }

        // Excel serial numbers (e.g. 46151) stored as numbers
        if (v.IsNumber)
        {
            double serial = v.GetNumber();
            if (serial >= 1 && serial <= 2958465) // valid Excel date range
            {
                try { dt = DateTime.FromOADate(serial); return true; }
                catch { }
            }
        }

        // Text dates
        if (v.IsText)
        {
            var s = v.GetText().Trim();
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture,
                                  DateTimeStyles.None, out dt)) return true;
            // yyyy/MM/dd
            if (DateTime.TryParseExact(s, "yyyy/MM/dd", CultureInfo.InvariantCulture,
                                       DateTimeStyles.None, out dt)) return true;
        }

        return false;
    }
}

/// <summary>Package calculation mode.</summary>
public enum PackageMode
{
    OnePackage  = 1,
    TwoPackages = 2
}
