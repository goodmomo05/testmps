// ============================================================
// ADD to MainViewModel.cs
// ============================================================
// This file shows the exact additions required. Copy each
// section into the corresponding location in MainViewModel.cs.
// ============================================================

// ── 1. FIELD (alongside other private service fields) ────────────────────────
//
//     private DailyUploadService _dailyUpload;
//
// ── 2. COMMAND DECLARATION (alongside other IAsyncRelayCommand declarations) ─
//
//     public IAsyncRelayCommand DailyUploadCommand { get; }
//
// ── 3. CONSTRUCTOR WIRING (inside the MainViewModel() constructor body) ───────
//
//     _dailyUpload      = new DailyUploadService(Xl);
//     DailyUploadCommand = new AsyncRelayCommand(DailyUploadAsync);
//
// ── 4. COMMAND IMPLEMENTATION (add as a new method in the async section) ──────

namespace MpsAdjuster.ViewModels;

// Partial class extension — paste into MainViewModel.cs or keep as a separate
// partial class file (requires `public partial class MainViewModel` declaration).
public partial class MainViewModel
{
    // Service
    private DailyUploadService _dailyUpload = null!;  // initialised in ctor

    // Command (declare alongside other public IAsyncRelayCommand properties)
    public IAsyncRelayCommand DailyUploadCommand { get; private set; } = null!;

    // Call this inside MainViewModel() after the other service initialisations:
    //   _dailyUpload      = new DailyUploadService(Xl);
    //   DailyUploadCommand = new AsyncRelayCommand(DailyUploadAsync);

    // ── Implementation ────────────────────────────────────────────────────────

    private async Task DailyUploadAsync()
    {
        // Step 1 — pick one or more raw source files
        var rawFiles = PickMultiExcel(
            "Daily Upload — Step 1/3: Select raw file(s)  [hold Ctrl for multiple]");
        if (rawFiles is null || rawFiles.Length == 0) return;

        // Step 2 — ask the user to choose 1 Package or 2 Packages
        var dlg = new MpsAdjuster.Views.PackageSelectDialog();
        if (dlg.ShowDialog() != true) return;
        var mode = dlg.SelectedMode;

        // Step 3 — pick the MPS template file
        var templatePath = PickExcel(
            "Daily Upload — Step 3/3: Select MPS template file (dates-only header)");
        if (templatePath is null) return;

        // Step 4 — choose where to save the output
        var savePath = SaveDailyUploadOutput();
        if (savePath is null) return;

        // Step 5 — process
        IsBusy      = true;
        ProgressVal = 5;
        StatusText  = "Daily Upload: processing…";

        try
        {
            var prog = new Progress<string>(msg => StatusText = msg);
            int parts = await _dailyUpload.RunAsync(rawFiles, templatePath, savePath, mode, prog);

            StatusText  = $"Daily Upload complete — {parts} part(s) exported.";
            ProgressVal = 100;
            Xl.LogLine("DailyUpload", "DONE", $"{parts} parts → {savePath}");

            Show(
                $"Done!\n\n" +
                $"Mode    : {(mode == PackageMode.OnePackage ? "1 Package (full week)" : "2 Packages (Sat-Mon / Tue-Fri)")}\n" +
                $"Files   : {rawFiles.Length} raw file(s) merged\n" +
                $"Parts   : {parts}\n\n" +
                $"Saved to:\n{savePath}",
                "Daily Upload",
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Daily Upload error: {ex.Message}";
            Xl.LogLine("DailyUpload", "ERROR", ex.Message);
            Show(ex.Message, "Daily Upload Error", MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    // ── Save dialog for Daily Upload output ───────────────────────────────────

    private static string? SaveDailyUploadOutput()
    {
        var d = new Microsoft.Win32.SaveFileDialog
        {
            Title           = "Daily Upload — Save output as",
            Filter          = "Excel Workbook|*.xlsx",
            DefaultExt      = ".xlsx",
            FileName        = $"DailyUpload_{DateTime.Now:yyyyMMdd_HHmm}.xlsx",
            OverwritePrompt = true
        };
        return d.ShowDialog() == true ? d.FileName : null;
    }
}
