using System.Drawing;
using System.Drawing.Drawing2D;

namespace MpsBalancer;

public class MainForm : Form
{
    // ── UI Controls ──────────────────────────────────────────────────────────
    private Panel _topPanel = null!;
    private Label _titleLabel = null!;
    private Label _subtitleLabel = null!;

    private GroupBox _fileGroup = null!;
    private TextBox _filePathBox = null!;
    private Button _browseBtn = null!;

    private GroupBox _sheetGroup = null!;
    private ListBox _sheetList = null!;
    private Label _sheetHint = null!;

    private GroupBox _settingsGroup = null!;
    private Label _lblWeekCol = null!, _lblInvRow = null!, _lblPlnRow = null!;
    private Label _lblCoverWk = null!, _lblWorkHrs = null!, _lblTargetEff = null!;
    private Label _lblVarRow = null!, _lblLastCol = null!;
    private TextBox _valWeekCol = null!, _valInvRow = null!, _valPlnRow = null!;
    private TextBox _valCoverWk = null!, _valWorkHrs = null!, _valTargetEff = null!;
    private TextBox _valVarRow = null!, _valLastCol = null!;

    private GroupBox _outputGroup = null!;
    private RadioButton _rbOverwrite = null!, _rbNewFile = null!;
    private TextBox _outputPathBox = null!;
    private Button _outputBrowseBtn = null!;

    private Button _runBtn = null!;
    private ProgressBar _progressBar = null!;
    private Label _progressLabel = null!;

    private GroupBox _logGroup = null!;
    private RichTextBox _logBox = null!;

    private StatusStrip _status = null!;
    private ToolStripStatusLabel _statusLabel = null!;

    // ── State ────────────────────────────────────────────────────────────────
    private MpsFile? _mpsFile;
    private string? _selectedSheet;
    private SheetSettings? _currentSettings;
    private bool _isRunning;

    // ── Colors ───────────────────────────────────────────────────────────────
    private static readonly Color PrimaryBlue = Color.FromArgb(0, 82, 136);
    private static readonly Color AccentGreen = Color.FromArgb(0, 153, 102);
    private static readonly Color LightBg = Color.FromArgb(245, 248, 252);
    private static readonly Color CardBg = Color.White;
    private static readonly Color BorderColor = Color.FromArgb(210, 220, 235);
    private static readonly Color TextDark = Color.FromArgb(30, 40, 55);
    private static readonly Color TextMuted = Color.FromArgb(110, 120, 140);

    public MainForm()
    {
        InitializeUI();
        SetStatus("Ready — open an MPS Excel file to begin.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UI CONSTRUCTION
    // ─────────────────────────────────────────────────────────────────────────

    private void InitializeUI()
    {
        Text = "MPS Balancer";
        Size = new Size(920, 780);
        MinimumSize = new Size(800, 680);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = LightBg;
        Font = new Font("Segoe UI", 9.5f);

        BuildTopPanel();
        BuildStatusBar();

        // Main content panel (scrollable)
        var scroll = new Panel { AutoScroll = true, Dock = DockStyle.Fill, Padding = new Padding(16) };
        Controls.Add(scroll);
        Controls.Add(_topPanel);
        Controls.Add(_status);

        BuildFileGroup(scroll);
        BuildSheetGroup(scroll);
        BuildSettingsGroup(scroll);
        BuildOutputGroup(scroll);
        BuildRunArea(scroll);
        BuildLogGroup(scroll);

        LayoutContent(scroll);
    }

    private void BuildTopPanel()
    {
        _topPanel = new Panel { Height = 72, Dock = DockStyle.Top, BackColor = PrimaryBlue };

        _titleLabel = new Label
        {
            Text = "⚙  MPS Balancer",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 16f, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(20, 10)
        };

        _subtitleLabel = new Label
        {
            Text = "Automates FastBalance macro — select your MPS Excel file and B-sheet to begin",
            ForeColor = Color.FromArgb(180, 210, 235),
            Font = new Font("Segoe UI", 9f),
            AutoSize = true,
            Location = new Point(22, 44)
        };

        _topPanel.Controls.AddRange(new Control[] { _titleLabel, _subtitleLabel });
    }

    private void BuildStatusBar()
    {
        _status = new StatusStrip { BackColor = Color.FromArgb(235, 240, 248) };
        _statusLabel = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _status.Items.Add(_statusLabel);
    }

    private void BuildFileGroup(Panel parent)
    {
        _fileGroup = MakeGroup("📂  Step 1 — Open MPS Excel File");

        _filePathBox = new TextBox
        {
            ReadOnly = true,
            PlaceholderText = "Click Browse to select your MPS .xlsx file...",
            Width = 500,
            BackColor = Color.FromArgb(250, 252, 255),
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Segoe UI", 9.5f)
        };

        _browseBtn = MakeButton("Browse…", PrimaryBlue);
        _browseBtn.Click += BrowseFile;

        var row = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true, WrapContents = false };
        row.Controls.Add(_filePathBox);
        row.Controls.Add(Spacer(8));
        row.Controls.Add(_browseBtn);
        _fileGroup.Controls.Add(row);
        row.Location = new Point(12, 24);

        parent.Controls.Add(_fileGroup);
    }

    private void BuildSheetGroup(Panel parent)
    {
        _sheetGroup = MakeGroup("📋  Step 2 — Select B-Sheet to Balance");

        _sheetHint = new Label
        {
            Text = "Only B-sheets (starting with \"B-\") are listed. Select the one to balance.",
            ForeColor = TextMuted,
            AutoSize = true,
            Location = new Point(12, 22)
        };

        _sheetList = new ListBox
        {
            Height = 90,
            Width = 580,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Segoe UI", 9.5f),
            Location = new Point(12, 44)
        };
        _sheetList.SelectedIndexChanged += SheetSelected;

        _sheetGroup.Controls.AddRange(new Control[] { _sheetHint, _sheetList });
        parent.Controls.Add(_sheetGroup);
    }

    private void BuildSettingsGroup(Panel parent)
    {
        _settingsGroup = MakeGroup("⚙  Step 3 — Review Settings (auto-read from sheet, editable)");

        int lx = 12, lw = 130, vw = 80, row1 = 28, row2 = 62;

        (Label l, TextBox t) Make(string name, int x, int y, string tip)
        {
            var lbl = new Label { Text = name, AutoSize = false, Width = lw, Height = 22, Location = new Point(x, y), ForeColor = TextMuted, TextAlign = ContentAlignment.MiddleRight };
            var tb = new TextBox { Width = vw, Location = new Point(x + lw + 4, y - 2), BorderStyle = BorderStyle.FixedSingle };
            tb.Tag = tip;
            tb.Enter += (_, __) => SetStatus(tip);
            return (lbl, tb);
        }

        var (l1, v1) = Make("Start Week Col:", lx, row1, "Column index (1-based) of the first week to process");
        var (l2, v2) = Make("Inv Row:", lx + 250, row1, "Row of inventory quantities (InvRow). Parts repeat every 7 rows.");
        var (l3, v3) = Make("Pln Row:", lx + 500, row1, "Row of plan quantities (PlnRow). Must equal InvRow + 2.");
        var (l4, v4) = Make("Cover Weeks:", lx, row2, "Lookahead weeks — shortages within this window are highlighted red.");
        var (l5, v5) = Make("Work HRS Row:", lx + 250, row2, "Row containing weekly working hours. Weeks with 0 are skipped.");
        var (l6, v6) = Make("Target Eff:", lx + 500, row2, "Efficiency threshold. If current eff > this, more production is added.");
        var (l7, v7) = Make("Var Row:", lx, row2 + 34, "Row containing efficiency variance values (row 10 in standard MPS).");
        var (l8, v8) = Make("Last Col:", lx + 250, row2 + 34, "Last column index with data (auto-detected).");

        _lblWeekCol = l1; _valWeekCol = v1;
        _lblInvRow  = l2; _valInvRow  = v2;
        _lblPlnRow  = l3; _valPlnRow  = v3;
        _lblCoverWk = l4; _valCoverWk = v4;
        _lblWorkHrs = l5; _valWorkHrs = v5;
        _lblTargetEff= l6;_valTargetEff= v6;
        _lblVarRow  = l7; _valVarRow  = v7;
        _lblLastCol = l8; _valLastCol = v8;

        _settingsGroup.Controls.AddRange(new Control[]
        {
            l1,v1, l2,v2, l3,v3,
            l4,v4, l5,v5, l6,v6,
            l7,v7, l8,v8
        });
        _settingsGroup.Height = 120;
        parent.Controls.Add(_settingsGroup);
    }

    private void BuildOutputGroup(Panel parent)
    {
        _outputGroup = MakeGroup("💾  Step 4 — Output");

        _rbOverwrite = new RadioButton { Text = "Overwrite original file", Checked = true, AutoSize = true, Location = new Point(12, 26), ForeColor = TextDark };
        _rbNewFile   = new RadioButton { Text = "Save as new file:", AutoSize = true, Location = new Point(12, 52), ForeColor = TextDark };
        _rbNewFile.CheckedChanged += (_, __) => { _outputPathBox.Enabled = _rbNewFile.Checked; _outputBrowseBtn.Enabled = _rbNewFile.Checked; };

        _outputPathBox = new TextBox
        {
            Width = 440,
            PlaceholderText = "Select output file path…",
            Enabled = false,
            Location = new Point(160, 50),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.FromArgb(250, 252, 255)
        };

        _outputBrowseBtn = MakeButton("Browse…", TextMuted);
        _outputBrowseBtn.Location = new Point(610, 48);
        _outputBrowseBtn.Enabled = false;
        _outputBrowseBtn.Click += BrowseOutput;

        _outputGroup.Controls.AddRange(new Control[] { _rbOverwrite, _rbNewFile, _outputPathBox, _outputBrowseBtn });
        _outputGroup.Height = 86;
        parent.Controls.Add(_outputGroup);
    }

    private void BuildRunArea(Panel parent)
    {
        var panel = new Panel { Height = 60, Width = 680 };

        _runBtn = new Button
        {
            Text = "▶  Run Balance",
            Width = 180,
            Height = 42,
            Location = new Point(0, 8),
            BackColor = AccentGreen,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 11f, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Enabled = false
        };
        _runBtn.FlatAppearance.BorderSize = 0;
        _runBtn.Click += RunBalance;

        _progressBar = new ProgressBar { Width = 380, Height = 22, Location = new Point(196, 10), Style = ProgressBarStyle.Continuous };
        _progressLabel = new Label { Width = 200, Height = 22, Location = new Point(196, 34), ForeColor = TextMuted, Text = "" };

        panel.Controls.AddRange(new Control[] { _runBtn, _progressBar, _progressLabel });
        parent.Controls.Add(panel);
        panel.Tag = "run";
    }

    private void BuildLogGroup(Panel parent)
    {
        _logGroup = MakeGroup("📄  Balance Log");

        _logBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BackColor = Color.FromArgb(22, 27, 38),
            ForeColor = Color.FromArgb(200, 215, 235),
            Font = new Font("Consolas", 9f),
            BorderStyle = BorderStyle.None,
            ScrollBars = RichTextBoxScrollBars.Vertical
        };

        _logGroup.Controls.Add(_logBox);
        _logGroup.Height = 200;
        parent.Controls.Add(_logGroup);
    }

    private void LayoutContent(Panel scroll)
    {
        int y = 12, gap = 12;
        foreach (Control c in scroll.Controls)
        {
            c.Location = new Point(16, y);
            c.Width = scroll.ClientSize.Width - 48;
            y += c.Height + gap;
        }
        scroll.Resize += (_, __) =>
        {
            int yy = 12;
            foreach (Control c in scroll.Controls)
            {
                c.Location = new Point(16, yy);
                c.Width = scroll.ClientSize.Width - 48;
                yy += c.Height + gap;
            }
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EVENT HANDLERS
    // ─────────────────────────────────────────────────────────────────────────

    private void BrowseFile(object? sender, EventArgs e)
    {
        using var dlg = new OpenFileDialog
        {
            Title = "Open MPS Excel File",
            Filter = "Excel Files|*.xlsx;*.xlsm|All Files|*.*",
            CheckFileExists = true
        };
        if (dlg.ShowDialog() != DialogResult.OK) return;

        try
        {
            _mpsFile?.Dispose();
            _mpsFile = MpsFile.Open(dlg.FileName);
            _filePathBox.Text = dlg.FileName;

            _sheetList.Items.Clear();
            foreach (var s in _mpsFile.BSheets)
                _sheetList.Items.Add(s);

            if (_sheetList.Items.Count == 0)
            {
                // No B- sheets, show all
                foreach (var s in _mpsFile.AllSheets)
                    _sheetList.Items.Add(s);
                _sheetHint.Text = "No \"B-\" sheets found — all sheets shown. Select the balance sheet.";
            }
            else
            {
                _sheetHint.Text = "Only B-sheets (starting with \"B-\") are listed. Select the one to balance.";
            }

            if (_sheetList.Items.Count == 1)
                _sheetList.SelectedIndex = 0;

            SetStatus($"Opened: {Path.GetFileName(dlg.FileName)} — {_mpsFile.AllSheets.Count} sheets found.");
            Log($"File loaded: {dlg.FileName}", Color.FromArgb(100, 200, 150));
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error opening file:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SheetSelected(object? sender, EventArgs e)
    {
        if (_sheetList.SelectedItem == null || _mpsFile == null) return;
        _selectedSheet = _sheetList.SelectedItem.ToString()!;

        try
        {
            _currentSettings = _mpsFile.ReadSettings(_selectedSheet);
            PopulateSettings(_currentSettings);
            _runBtn.Enabled = true;
            SetStatus($"Sheet \"{_selectedSheet}\" selected. Settings loaded. Click Run Balance to start.");
            Log($"Sheet selected: {_selectedSheet}", Color.FromArgb(100, 200, 150));
            Log($"  WeekCol={_currentSettings.WeekCol}, InvRow={_currentSettings.InvRow}, PlnRow={_currentSettings.PlnRow}", Color.FromArgb(160, 185, 220));
            Log($"  CoverWk={_currentSettings.CoverWk}, WorkHrsRow={_currentSettings.WorkHrsRow}, VarRow={_currentSettings.VarRow}", Color.FromArgb(160, 185, 220));
            Log($"  Row81(StdHrs)={_currentSettings.Row81} Row69(PlanEff)={_currentSettings.Row69} Row90(EffTarget)={_currentSettings.Row90}", Color.FromArgb(160, 185, 220));
            Log($"  TargetEff={_currentSettings.TargetEff}, LastCol={_currentSettings.LastCol}", Color.FromArgb(160, 185, 220));
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error reading sheet settings:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void BrowseOutput(object? sender, EventArgs e)
    {
        using var dlg = new SaveFileDialog
        {
            Title = "Save Balanced File As",
            Filter = "Excel Files|*.xlsx|All Files|*.*",
            DefaultExt = "xlsx",
            FileName = _mpsFile != null ? Path.GetFileNameWithoutExtension(_mpsFile.FilePath) + "_balanced.xlsx" : "balanced.xlsx"
        };
        if (dlg.ShowDialog() == DialogResult.OK)
            _outputPathBox.Text = dlg.FileName;
    }

    private async void RunBalance(object? sender, EventArgs e)
    {
        if (_isRunning || _mpsFile == null || _selectedSheet == null) return;
        if (_currentSettings == null) { MessageBox.Show("Please select a sheet first."); return; }

        // Read potentially edited settings
        if (!TryReadSettingsFromUI(out var settings)) return;

        string? outputPath = null;
        if (_rbNewFile.Checked)
        {
            outputPath = _outputPathBox.Text.Trim();
            if (string.IsNullOrEmpty(outputPath))
            { MessageBox.Show("Please specify an output file path."); return; }
        }

        _isRunning = true;
        _runBtn.Enabled = false;
        _progressBar.Value = 0;
        _progressLabel.Text = "Starting…";
        SetStatus("Balance running…");
        Log("", Color.Transparent);
        Log("══════════════ BALANCE STARTED ══════════════", Color.FromArgb(255, 210, 80));

        var progress = new Progress<(int current, int total, string status)>(p =>
        {
            if (p.total > 0)
                _progressBar.Value = Math.Min(100, (int)(100.0 * p.current / p.total));
            _progressLabel.Text = p.status;
        });

        BalanceResult result;
        try
        {
            result = await Task.Run(() =>
            {
                var ws = _mpsFile.GetSheet(_selectedSheet);
                var engine = new BalanceEngine(ws, settings, msg => Invoke(() => Log(msg, Color.FromArgb(160, 185, 220))));
                return engine.Run(progress);
            });
        }
        catch (Exception ex)
        {
            Log($"ERROR: {ex.Message}", Color.FromArgb(255, 100, 80));
            _isRunning = false;
            _runBtn.Enabled = true;
            _progressLabel.Text = "Error";
            SetStatus("Balance failed with an error.");
            return;
        }

        // Save file
        try
        {
            string savePath = outputPath ?? _mpsFile.FilePath;
            _mpsFile.Save(savePath);
            Log($"File saved: {savePath}", Color.FromArgb(100, 220, 140));
        }
        catch (Exception ex)
        {
            Log($"SAVE ERROR: {ex.Message}", Color.FromArgb(255, 100, 80));
        }

        _progressBar.Value = 100;
        _progressLabel.Text = result.Success ? "Complete ✔" : "Stopped ⚠";

        if (result.Success)
        {
            Log("══════════════ BALANCE COMPLETE ══════════════", Color.FromArgb(100, 220, 140));
            Log($"  Total plan additions: {result.TotalAdditions} units", Color.FromArgb(180, 240, 180));
            SetStatus($"Balance finished successfully. {result.TotalAdditions} units added.");
            MessageBox.Show($"Balance Finished Successfully!\n\nTotal units added: {result.TotalAdditions}\nWeeks processed: {result.WeeksProcessed}",
                "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {
            Log("══════════════ BALANCE STOPPED ══════════════", Color.FromArgb(255, 140, 60));
            Log(result.Message, Color.FromArgb(255, 140, 60));
            SetStatus("Balance stopped — efficiency limit reached with outstanding shortage.");
            MessageBox.Show(result.Message, "Planning Stopped", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        _isRunning = false;
        _runBtn.Enabled = true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private void PopulateSettings(SheetSettings s)
    {
        _valWeekCol.Text  = s.WeekCol.ToString();
        _valInvRow.Text   = s.InvRow.ToString();
        _valPlnRow.Text   = s.PlnRow.ToString();
        _valCoverWk.Text  = s.CoverWk.ToString();
        _valWorkHrs.Text  = s.WorkHrsRow.ToString();
        _valTargetEff.Text= s.TargetEff.ToString("G");
        _valVarRow.Text   = s.VarRow.ToString();
        _valLastCol.Text  = s.LastCol.ToString();
        // Inform user of discovered formula rows in log
    }

    private bool TryReadSettingsFromUI(out SheetSettings s)
    {
        s = new SheetSettings();
        try
        {
            s.WeekCol    = int.Parse(_valWeekCol.Text);
            s.InvRow     = int.Parse(_valInvRow.Text);
            s.PlnRow     = int.Parse(_valPlnRow.Text);
            s.CoverWk    = int.Parse(_valCoverWk.Text);
            s.WorkHrsRow = int.Parse(_valWorkHrs.Text);
            s.TargetEff  = double.Parse(_valTargetEff.Text);
            s.VarRow     = int.Parse(_valVarRow.Text);
            s.LastCol    = int.Parse(_valLastCol.Text);
            s.LastRow    = _currentSettings!.LastRow;
            // Re-derive formula rows from auto-detect; fall back to workHrsRow offsets
            // if auto-detect returned valid values they carry over; if they were 0 or
            // negative (empty config-cell sheet) we recompute from the UI-entered workHrsRow.
            int r81 = _currentSettings!.Row81;
            int r69 = _currentSettings!.Row69;
            int r90 = _currentSettings!.Row90;
            if (r81 <= 0) r81 = s.WorkHrsRow - 14;
            if (r69 <= 0) r69 = s.WorkHrsRow - 26;
            if (r90 <= 0) r90 = s.WorkHrsRow - 5;
            s.Row81 = r81;
            s.Row69 = r69;
            s.Row90 = r90;
            return true;
        }
        catch
        {
            MessageBox.Show("Invalid value in settings — please check all fields are numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }

    private void Log(string msg, Color color)
    {
        if (InvokeRequired) { Invoke(() => Log(msg, color)); return; }
        _logBox.SelectionStart = _logBox.TextLength;
        _logBox.SelectionLength = 0;
        _logBox.SelectionColor = color == Color.Transparent ? _logBox.ForeColor : color;
        _logBox.AppendText(msg + "\n");
        _logBox.ScrollToCaret();
    }

    private void SetStatus(string msg)
    {
        if (InvokeRequired) { Invoke(() => SetStatus(msg)); return; }
        _statusLabel.Text = "  " + msg;
    }

    private static GroupBox MakeGroup(string title)
    {
        return new GroupBox
        {
            Text = title,
            Height = 100,
            ForeColor = PrimaryBlue,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Padding = new Padding(10)
        };
    }

    private static Button MakeButton(string text, Color bg)
    {
        return new Button
        {
            Text = text,
            Height = 30,
            Width = 100,
            BackColor = bg,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
    }

    private static Panel Spacer(int w) => new Panel { Width = w, Height = 1 };

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _mpsFile?.Dispose();
        base.OnFormClosed(e);
    }
}
