namespace MpsBalancer;

/// <summary>
/// Popup that asks the user for the box/batch size for each part before running the balance.
/// </summary>
public class BoxSizeDialog : Form
{
    private readonly List<PartGroup>  _parts;
    private readonly List<NumericUpDown> _inputs = new();

    public BoxSizeDialog(List<PartGroup> parts)
    {
        _parts = parts;

        Text            = "Box Sizes — Enter Qty Per Box for Each Part";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox     = false;
        MinimizeBox     = false;
        BackColor       = Color.FromArgb(245, 248, 252);
        Font            = new Font("Segoe UI", 10f);

        int rowH  = 40;
        int padY  = 16;
        int padX  = 20;
        int labelW= 220;
        int inputW= 110;
        int formW = padX + labelW + 16 + inputW + padX + 20;

        // Header label
        var header = new Label
        {
            Text      = "Enter the box (batch) size for each part.\nThe balancer will add one box at a time.",
            AutoSize  = false,
            Width     = formW - 2 * padX,
            Height    = 44,
            Location  = new Point(padX, padY),
            ForeColor = Color.FromArgb(60, 80, 110)
        };
        Controls.Add(header);

        int y = padY + header.Height + 8;

        for (int i = 0; i < parts.Count; i++)
        {
            var p = parts[i];

            var lbl = new Label
            {
                Text      = p.PartNo,
                AutoSize  = false,
                Width     = labelW,
                Height    = 28,
                Location  = new Point(padX, y + 6),
                ForeColor = Color.FromArgb(30, 40, 55),
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold)
            };

            var nud = new NumericUpDown
            {
                Minimum   = 1,
                Maximum   = 100_000,
                Value     = p.BoxSize > 0 ? p.BoxSize : 1,
                Width     = inputW,
                Height    = 28,
                Location  = new Point(padX + labelW + 16, y + 2),
                Font      = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                TextAlign = HorizontalAlignment.Right
            };

            Controls.Add(lbl);
            Controls.Add(nud);
            _inputs.Add(nud);
            y += rowH;
        }

        y += 8;

        var okBtn = new Button
        {
            Text      = "OK — Run Balance",
            Width     = 160,
            Height    = 34,
            Location  = new Point(padX, y),
            BackColor = Color.FromArgb(0, 153, 102),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            DialogResult = DialogResult.OK,
            Cursor    = Cursors.Hand,
            Font      = new Font("Segoe UI", 10f, FontStyle.Bold)
        };
        okBtn.FlatAppearance.BorderSize = 0;

        var cancelBtn = new Button
        {
            Text         = "Cancel",
            Width        = 90,
            Height       = 34,
            Location     = new Point(padX + 168, y),
            FlatStyle    = FlatStyle.Flat,
            DialogResult = DialogResult.Cancel,
            Cursor       = Cursors.Hand
        };

        Controls.Add(okBtn);
        Controls.Add(cancelBtn);
        AcceptButton = okBtn;
        CancelButton = cancelBtn;

        ClientSize = new Size(formW, y + 34 + padY);
    }

    /// <summary>Call after DialogResult.OK to apply chosen box sizes back to the parts.</summary>
    public void ApplyToparts()
    {
        for (int i = 0; i < _parts.Count; i++)
            _parts[i].BoxSize = (int)_inputs[i].Value;
    }
}
