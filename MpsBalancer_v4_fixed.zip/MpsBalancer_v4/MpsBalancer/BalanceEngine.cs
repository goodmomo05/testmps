using OfficeOpenXml;

namespace MpsBalancer;

public class BalanceResult
{
    public bool   Success        { get; set; }
    public string Message        { get; set; } = "";
    public int    TotalAdditions { get; set; }
    public int    WeeksProcessed { get; set; }
}

public class PartGroup
{
    public int    InvRow  { get; init; }
    public int    PlnRow  { get; init; }
    public int    SalRow  { get; init; }
    public double ST      { get; init; }   // std hours per unit (col B of PlnRow)
    public string PartNo  { get; init; } = "";
    public int    BoxSize { get; set;  }   // user-supplied batch qty
}

public class BalanceEngine
{
    private readonly ExcelWorksheet  _ws;       // B-sheet
    private readonly ExcelWorksheet  _wsT;      // T-sheet (schedule)
    private readonly ExcelWorksheet  _wsSales;  // Sales sheet
    private readonly ExcelWorksheet  _wsPlan;   // Plan sheet
    private readonly SheetSettings   _s;
    private readonly Action<string>  _log;
    private readonly List<PartGroup> _parts = new();

    // Per-part data loaded from source sheets
    // plan[partNo][bCol] = plan qty we control (write here)
    private readonly Dictionary<string, double[]> _plan    = new();
    // sales[partNo][bCol] = sales demand (read-only)
    private readonly Dictionary<string, double[]> _sales   = new();
    // inv[partNo][bCol]  = computed inventory (we maintain in memory)
    private readonly Dictionary<string, double[]> _inv     = new();
    // opening stock per part
    private readonly Dictionary<string, double>   _opening = new();
    // clock hours per B-col
    private double[] _clockHrs = Array.Empty<double>();
    // eff target per B-col
    private double[] _effTarget = Array.Empty<double>();

    public IReadOnlyList<PartGroup> Parts => _parts;

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings, Action<string> log)
        : this(ws, null!, null!, null!, settings, new Dictionary<string, int>(), log) { }

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings,
                         Dictionary<string, int> boxSizes, Action<string> log)
        : this(ws, null!, null!, null!, settings, boxSizes, log) { }

    public BalanceEngine(ExcelWorksheet ws,
                         ExcelWorksheet wsT,
                         ExcelWorksheet wsSales,
                         ExcelWorksheet wsPlan,
                         SheetSettings settings,
                         Dictionary<string, int> boxSizes,
                         Action<string> log)
    {
        _ws      = ws;
        _wsT     = wsT;
        _wsSales = wsSales;
        _wsPlan  = wsPlan;
        _s       = settings;
        _log     = log;

        int totalCols = settings.LastCol + 1; // 1-based index, allocate up to LastCol

        // ── Discover parts from B-sheet ───────────────────────────────────────
        int r = settings.InvRow;
        while (r + 3 <= settings.LastRow)
        {
            string label  = ws.Cells[r, 3].Value?.ToString()?.Trim() ?? "";
            string partNo = ws.Cells[r, 1].Value?.ToString()?.Trim() ?? "";

            bool isRealPart = partNo.Length > 0
                           && !partNo.StartsWith("Sub", StringComparison.OrdinalIgnoreCase);

            if (isRealPart && label.IndexOf("Invt", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                _parts.Add(new PartGroup
                {
                    InvRow  = r,
                    PlnRow  = r + 2,
                    SalRow  = r + 3,
                    ST      = GetNum(ws, r + 2, 2),   // col B = std hours/unit
                    PartNo  = partNo,
                    BoxSize = boxSizes.TryGetValue(partNo, out int bs) && bs > 0 ? bs : 1
                });

                _plan[partNo]  = new double[totalCols];
                _sales[partNo] = new double[totalCols];
                _inv[partNo]   = new double[totalCols];
            }
            r += 7;
        }

        // ── Load source data ───────────────────────────────────────────────────
        _clockHrs  = new double[totalCols];
        _effTarget = new double[totalCols];
        LoadSourceData();
    }

    // ── Array formula clearing ───────────────────────────────────────────────
    // EPPlus throws "Cannot overwrite a part of an array-formula" if we try to
    // write to any cell in an array-formula range without clearing it first.
    // We clear the entire range and replace with plain values.

    private void ClearArrayFormulas()
    {
        // Rows in B-sheet that contain TRANSPOSE array formulas we need to write to
        // Row 55 = EffTarget (D55:CC55), Row 60 = ClockHrs (D60:CC60)
        // Also rows 37, 53, 59 have array formulas but we don't write to them — leave.
        int[] arrayRows = { _s.Row90, _s.WorkHrsRow };

        foreach (int row in arrayRows)
        {
            for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            {
                var cell = _ws.Cells[row, c];
                cell.Value = null;  // clears formula and value, freeing the cell
            }
        }

        // Also clear regular formula rows we will overwrite (Row81, Row69, VarRow)
        // These are standard formulas (not array), EPPlus allows overwriting them directly
        // but clearing avoids any stale formula interference.
        int[] formulaRows = { _s.Row81, _s.Row69, _s.VarRow };
        foreach (int row in formulaRows)
            for (int c = _s.WeekCol; c <= _s.LastCol; c++)
                _ws.Cells[row, c].Value = null;
    }

    // ── Source data loading ───────────────────────────────────────────────────

    private void LoadSourceData()
    {
        // Note: ClearArrayFormulas() is called from Run(), not here.
        // This keeps the constructor safe for read-only use (e.g. box-size popup).
        // B-sheet row 2 maps B-col → Sales sheet col index
        // B-sheet row 4 maps B-col → Plan sheet col index (only a few weeks)
        // T-sheet row offset: T-row = B-col + 8  (B-col 4 = T-row 12)
        const int tRowOffset = 8;

        // Build OS lookup (opening stock)
        var ws_os = _ws.Workbook.Worksheets["OS"];
        var osLookup = new Dictionary<string, double>();
        if (ws_os != null)
        {
            for (int row = 2; row <= 10000; row++)
            {
                var pn = ws_os.Cells[row, 1].Value?.ToString()?.Trim();
                if (string.IsNullOrEmpty(pn)) break;
                osLookup[pn] = Convert.ToDouble(ws_os.Cells[row, 2].Value ?? 0d);
            }
        }

        // Build Sales lookup: (partNo, salesCol) → qty
        var ws_sales = _ws.Workbook.Worksheets["Sales"] ?? _wsSales;
        var salesLookup = new Dictionary<(string, int), double>();
        if (ws_sales != null)
        {
            for (int row = 2; row <= 10000; row++)
            {
                var pn = ws_sales.Cells[row, 1].Value?.ToString()?.Trim();
                if (string.IsNullOrEmpty(pn)) break;
                for (int c = 2; c <= _s.LastCol + 10; c++)
                {
                    var v = ws_sales.Cells[row, c].Value;
                    if (v != null) salesLookup[(pn, c)] = Convert.ToDouble(v);
                }
            }
        }

        // Build Plan lookup: (partNo, planCol) → qty
        var ws_plan = _ws.Workbook.Worksheets["Plan"] ?? _wsPlan;
        var planLookup = new Dictionary<(string, int), double>();
        if (ws_plan != null)
        {
            for (int row = 2; row <= 10000; row++)
            {
                var pn = ws_plan.Cells[row, 1].Value?.ToString()?.Trim();
                if (string.IsNullOrEmpty(pn)) break;
                for (int c = 2; c <= 1000; c++)
                {
                    var v = ws_plan.Cells[row, c].Value;
                    if (v == null && c > 3) break;
                    if (v != null) planLookup[(pn, c)] = Convert.ToDouble(v);
                }
            }
        }

        // Get T-sheet
        var ws_t = _ws.Workbook.Worksheets.FirstOrDefault(s =>
            s.Name.StartsWith("T-", StringComparison.OrdinalIgnoreCase)) ?? _wsT;

        // Populate per-part arrays and clock hrs / eff target per B-col
        foreach (var part in _parts)
        {
            _opening[part.PartNo] = osLookup.TryGetValue(part.PartNo, out double os) ? os : 0;
        }

        for (int bCol = _s.WeekCol; bCol <= _s.LastCol; bCol++)
        {
            // Sales col mapping from B-sheet row 2
            int salesCol = Convert.ToInt32(_ws.Cells[2, bCol].Value ?? 0);
            // Plan col mapping from B-sheet row 4
            var planColVal = _ws.Cells[4, bCol].Value;
            int planCol = planColVal != null ? Convert.ToInt32(planColVal) : 0;

            foreach (var part in _parts)
            {
                // Sales
                _sales[part.PartNo][bCol] = salesCol > 0 && salesLookup.TryGetValue((part.PartNo, salesCol), out double sq)
                    ? sq : 0;

                // Existing plan (from Plan sheet for past/current weeks)
                _plan[part.PartNo][bCol] = planCol > 0 && planLookup.TryGetValue((part.PartNo, planCol), out double pq)
                    ? pq : 0;
            }

            // Clock hours and eff target from T-sheet
            if (ws_t != null)
            {
                int tRow = bCol + tRowOffset;
                double heads    = Convert.ToDouble(ws_t.Cells[tRow, 19].Value ?? 0d); // col S
                double sewsWd   = Convert.ToDouble(ws_t.Cells[tRow,  5].Value ?? 0d); // col E
                double effPct   = Convert.ToDouble(ws_t.Cells[tRow, 20].Value ?? _s.TargetEff + 1); // col T
                _clockHrs[bCol]  = heads * sewsWd * 7.0;  // Heads × WorkingDays × 7hrs
                _effTarget[bCol] = effPct;                 // e.g. 0.93
            }
            else
            {
                _clockHrs[bCol]  = 0;
                _effTarget[bCol] = 0.93;
            }
        }

        // Seed inventory from opening stock + chain formula
        foreach (var part in _parts)
            RecalcInventory(part, _s.WeekCol);

        _log($"Source data loaded: {_parts.Count} parts, {_s.LastCol - _s.WeekCol + 1} weeks");
        foreach (var part in _parts)
            _log($"  {part.PartNo}: Opening={_opening[part.PartNo]:N0}  ST={part.ST}  Box={part.BoxSize}");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static double GetNum(ExcelWorksheet ws, int row, int col)
    {
        var v = ws.Cells[row, col].Value;
        return v == null ? 0d : Convert.ToDouble(v);
    }

    // Write a computed value to the B-sheet cell
    private void WriteCell(int row, int col, double value) =>
        _ws.Cells[row, col].Value = value;

    // ── Efficiency recalc (in-memory) ─────────────────────────────────────────
    //
    //  StdHrs[col]   = ROUND( SUM( Plan[part][col] * ST[part] ), 0 )
    //  PlanEff[col]  = ROUND( StdHrs / ClockHrs * 100, 1 ) / 100
    //  EffVar[col]   = EffTarget[col] - PlanEff[col]

    private (double stdHrs, double planEff, double effVar) CalcEfficiency(int bCol)
    {
        double stdHrs = 0;
        foreach (var p in _parts)
            stdHrs += _plan[p.PartNo][bCol] * p.ST;
        stdHrs = Math.Round(stdHrs, 0);

        double clock  = _clockHrs[bCol];
        double planEff = clock == 0 ? 0d
            : Math.Round(Math.Round(stdHrs / clock * 100d, 1) / 100d, 10);

        double effVar = _effTarget[bCol] - planEff;
        return (stdHrs, planEff, effVar);
    }

    // Write efficiency rows to B-sheet so formulas in VarRow see the right values
    private void WriteEfficiency(int bCol)
    {
        var (stdHrs, planEff, effVar) = CalcEfficiency(bCol);
        WriteCell(_s.Row81,  bCol, stdHrs);   // StdHrs
        WriteCell(_s.Row69,  bCol, planEff);  // PlanEff
        WriteCell(_s.Row90,  bCol, _effTarget[bCol]); // EffTarget (fixed)
        // VarRow (row 10) is a formula cell — we write it too since EPPlus can't evaluate
        WriteCell(_s.VarRow, bCol, effVar);
    }

    // ── Inventory recalc ─────────────────────────────────────────────────────
    //
    //  Inv[col] = Inv[col-1] + WIP[col-1] - Sales[col-1] + Plan[col - transit]
    //  WIP is 0 for all future weeks in this file.

    private void RecalcInventory(PartGroup part, int fromBCol)
    {
        string pn      = part.PartNo;
        int    transit = _s.TransitWk;

        for (int c = fromBCol; c <= _s.LastCol; c++)
        {
            double prevInv  = c == _s.WeekCol
                ? _opening[pn]                            // col before start = opening stock
                : _inv[pn][c - 1];
            double prevSale = c > _s.WeekCol ? _sales[pn][c - 1] : 0;
            int    planSrc  = c - transit;
            double planQty  = planSrc >= _s.WeekCol ? _plan[pn][planSrc] : 0;

            double newInv = prevInv - prevSale + planQty;
            _inv[pn][c]  = newInv;
            WriteCell(part.InvRow, c, newInv);
        }
    }

    // ── Shortage scan ─────────────────────────────────────────────────────────

    private (PartGroup? part, int col) FindNearestShortage()
    {
        for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            foreach (var p in _parts)
                if (_inv[p.PartNo][c] < 0)
                    return (p, c);
        return (null, 0);
    }

    // ── Main balance loop ─────────────────────────────────────────────────────

    public BalanceResult Run(IProgress<(int current, int total, string status)>? progress = null)
    {
        var result     = new BalanceResult();
        int totalWeeks = _s.LastCol - _s.WeekCol + 1;

        // Clear array formula ranges ONCE before any writes to the B-sheet
        ClearArrayFormulas();

        _log("=== Balance Start ===");
        _log($"Parts: {_parts.Count}  WeekCol: {_s.WeekCol}  LastCol: {_s.LastCol}");
        _log($"Transit: {_s.TransitWk} wks  TargetEff: {_s.TargetEff:G4}");

        // Write initial efficiency to B-sheet
        for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            WriteEfficiency(c);

        int buildCol = _s.WeekCol;

        while (buildCol <= _s.LastCol)
        {
            progress?.Report((buildCol - _s.WeekCol, totalWeeks, $"Week col {buildCol}…"));

            var (shortage, shortageCol) = FindNearestShortage();
            if (shortage == null) { _log("No shortages — done."); break; }

            if (_clockHrs[buildCol] == 0)
            {
                _log($"Col {buildCol}: no clock hours — skip.");
                buildCol++;
                continue;
            }

            var (_, _, effVar) = CalcEfficiency(buildCol);
            _log($"Col {buildCol}: EffVar={effVar:F6}  ClockHrs={_clockHrs[buildCol]}  Shortage→ {shortage.PartNo} col={shortageCol}");

            // EffVar = EffTarget - PlanEff
            // Positive EffVar = room to add more plan
            // EffVar < TargetEff threshold (-0.01) = over capacity
            if (effVar < _s.TargetEff)
            {
                _log($"  Over capacity — next week.");
                buildCol++;
                continue;
            }

            // Add one box
            int box = shortage.BoxSize;
            _plan[shortage.PartNo][buildCol] += box;
            result.TotalAdditions += box;

            // Recompute efficiency for this col
            var (_, _, effAfter) = CalcEfficiency(buildCol);
            _log($"  +{box} → EffVar={effAfter:F6}");

            if (effAfter < _s.TargetEff)
            {
                // Overshot — undo
                _plan[shortage.PartNo][buildCol] -= box;
                result.TotalAdditions -= box;
                _log($"  Overshot — undone. Next week.");
                buildCol++;
            }
            else
            {
                // Recalc inventory from the first col affected by this plan addition
                RecalcInventory(shortage, buildCol + _s.TransitWk);
                WriteEfficiency(buildCol);
            }

            result.WeeksProcessed = buildCol - _s.WeekCol;
        }

        // Final write: flush all plan values and efficiency to B-sheet
        foreach (var part in _parts)
            for (int c = _s.WeekCol; c <= _s.LastCol; c++)
                WriteCell(part.PlnRow, c, _plan[part.PartNo][c]);

        for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            WriteEfficiency(c);

        progress?.Report((totalWeeks, totalWeeks, "Complete!"));
        result.Success        = true;
        result.Message        = "Balance Finished Successfully";
        result.WeeksProcessed = _s.LastCol - _s.WeekCol + 1;
        _log($"=== Done. Total units added: {result.TotalAdditions} ===");
        return result;
    }
}
