using OfficeOpenXml;

namespace MpsBalancer;

public class BalanceResult
{
    public bool   Success        { get; set; }
    public string Message        { get; set; } = "";
    public int    TotalAdditions { get; set; }
    public int    WeeksProcessed { get; set; }
}

public class PartGroup
{
    public int    InvRow  { get; init; }
    public int    WipRow  { get; init; }
    public int    PlnRow  { get; init; }
    public int    SalRow  { get; init; }
    public double ST      { get; init; }   // std hours per unit
    public string PartNo  { get; init; } = "";
    public int    BoxSize { get; set;  }   // user-supplied batch qty
}

public class BalanceEngine
{
    private readonly ExcelWorksheet  _ws;
    private readonly SheetSettings   _s;
    private readonly Action<string>  _log;
    private readonly List<PartGroup> _parts = new();

    public IReadOnlyList<PartGroup> Parts => _parts;

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings, Action<string> log)
        : this(ws, settings, new Dictionary<string, int>(), log) { }

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings,
                         Dictionary<string, int> boxSizes, Action<string> log)
    {
        _ws  = ws;
        _s   = settings;
        _log = log;

        int r = settings.InvRow;
        while (r + 3 <= settings.LastRow)
        {
            string label  = ws.Cells[r, 3].Value?.ToString()?.Trim() ?? "";
            string partNo = ws.Cells[r, 1].Value?.ToString()?.Trim() ?? "";

            bool isRealPart = partNo.Length > 0
                           && !partNo.StartsWith("Sub", StringComparison.OrdinalIgnoreCase);

            if (isRealPart && label.IndexOf("Invt", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                _parts.Add(new PartGroup
                {
                    InvRow  = r,
                    WipRow  = r + 1,
                    PlnRow  = r + 2,
                    SalRow  = r + 3,
                    ST      = Num(r + 2, 2),
                    PartNo  = partNo,
                    BoxSize = boxSizes.TryGetValue(partNo, out int bs) && bs > 0 ? bs : 1
                });
            }
            r += 7;
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private double Num(int row, int col)
    {
        var v = _ws.Cells[row, col].Value;
        return v == null ? 0d : Convert.ToDouble(v);
    }

    private void Set(int row, int col, double value) =>
        _ws.Cells[row, col].Value = value;

    // ── Efficiency recalc ─────────────────────────────────────────────────────
    //
    //  Row81 (StdHrs)  = ROUND( SUM( Plan[part][col] * ST[part] ), 0 )
    //  Row69 (PlanEff) = ROUND( StdHrs / ClockHrs * 100, 1 ) / 100
    //  Row10 (EffVar)  = Row90 (EffTarget) - Row69  ← FORMULA IN SHEET, READ ONLY
    //
    //  We write Row81 and Row69 so the sheet formula for EffVar stays correct.
    //  We NEVER write to VarRow — we only READ it.

    private void RecalcEfficiency(int col)
    {
        double stdHrs = 0;
        foreach (var p in _parts)
            stdHrs += Num(p.PlnRow, col) * p.ST;

        double r81 = Math.Round(stdHrs, 0);
        Set(_s.Row81, col, r81);

        double clockHrs = Num(_s.WorkHrsRow, col);
        double r69 = clockHrs == 0
            ? 0d
            : Math.Round(Math.Round(r81 / clockHrs * 100d, 1) / 100d, 10);
        Set(_s.Row69, col, r69);
    }

    // ── Inventory recalc (manual — EPPlus does not evaluate formulas) ─────────
    //
    //  Formula in sheet:  Inv[col] = Inv[col-1] + WIP[col-1] - Sales[col-1] + Plan[col - transit]
    //
    //  After writing to Plan[planCol], we must recompute Inv for every column
    //  from (planCol + transit) to LastCol, replacing formula-cached values with
    //  live arithmetic so shortage detection works correctly.

    private void RecalcInventory(PartGroup part, int fromCol)
    {
        int transit = _s.TransitWk;

        for (int c = fromCol; c <= _s.LastCol; c++)
        {
            double prevInv  = Num(part.InvRow, c - 1);
            double prevWip  = Num(part.WipRow, c - 1);
            double prevSale = Num(part.SalRow, c - 1);
            int    planSrc  = c - transit;
            double planQty  = planSrc >= _s.WeekCol ? Num(part.PlnRow, planSrc) : 0d;

            Set(part.InvRow, c, prevInv + prevWip - prevSale + planQty);
        }
    }

    // ── Shortage scan ─────────────────────────────────────────────────────────

    private (PartGroup? part, int col) FindNearestShortage(int startCol)
    {
        for (int c = startCol; c <= _s.LastCol; c++)
            foreach (var p in _parts)
                if (Num(p.InvRow, c) < 0)
                    return (p, c);

        return (null, 0);
    }

    // ── Main balance loop ─────────────────────────────────────────────────────
    //
    //  EffVar = EffTarget - PlanEff
    //    Positive EffVar → plan efficiency is BELOW target → room to add more
    //    Negative EffVar → plan efficiency is ABOVE target → over-built
    //
    //  Allowed range: EffVar >= TargetEff (e.g. -0.01 means up to 1% over target)
    //
    //  Per week column:
    //    1. Find nearest shortage (earliest negative inventory across all parts).
    //    2. If none → done.
    //    3. Skip weeks with no clock hours.
    //    4. If EffVar < TargetEff → no capacity, move to next week.
    //    5. Add one box of the shortage part to Plan[buildCol].
    //    6. Recalc StdHrs + PlanEff for this column.
    //    7. Recompute inventory for this part from (buildCol + transit) forward.
    //    8. Check new EffVar:
    //       - If EffVar < TargetEff → overshot: undo, move to next week.
    //       - Else: re-scan from step 1 (shortage may now be covered).

    public BalanceResult Run(IProgress<(int current, int total, string status)>? progress = null)
    {
        var result     = new BalanceResult();
        int totalWeeks = _s.LastCol - _s.WeekCol + 1;

        _log("=== Balance Start ===");
        _log($"Parts: {_parts.Count}  WeekCol: {_s.WeekCol}  LastCol: {_s.LastCol}");
        _log($"Transit: {_s.TransitWk} wks  CoverWk: {_s.CoverWk}  TargetEff: {_s.TargetEff:G4}");
        _log($"Row81={_s.Row81}  Row69={_s.Row69}  Row90={_s.Row90}  VarRow={_s.VarRow}");
        foreach (var p in _parts)
            _log($"  Part {p.PartNo}: InvRow={p.InvRow} PlnRow={p.PlnRow} ST={p.ST} Box={p.BoxSize}");

        // Seed inventory from WeekCol forward using manual recalc
        // (replaces formula-cached values with live numbers from the start)
        foreach (var p in _parts)
            RecalcInventory(p, _s.WeekCol);

        // Seed efficiency
        for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            RecalcEfficiency(c);

        int buildCol = _s.WeekCol;

        while (buildCol <= _s.LastCol)
        {
            progress?.Report((buildCol - _s.WeekCol, totalWeeks, $"Week col {buildCol}…"));

            // 1. Nearest shortage across all weeks
            var (shortage, shortageCol) = FindNearestShortage(_s.WeekCol);
            if (shortage == null)
            {
                _log("No shortages remaining — done.");
                break;
            }

            // 2. Skip weeks with no clock hours
            if (Num(_s.WorkHrsRow, buildCol) == 0)
            {
                _log($"Col {buildCol}: no clock hours — skip.");
                buildCol++;
                continue;
            }

            // 3. Read EffVar (READ ONLY — this is a sheet formula cell)
            double effVar = Num(_s.VarRow, buildCol);
            _log($"Col {buildCol}: EffVar={effVar:F6}  Shortage→ {shortage.PartNo} col={shortageCol}");

            // EffVar < TargetEff means plan efficiency is too high (over capacity)
            if (effVar < _s.TargetEff)
            {
                _log($"  No capacity (EffVar {effVar:F4} < {_s.TargetEff:F4}) — next week.");
                buildCol++;
                continue;
            }

            // 4. Add one box
            int    box        = shortage.BoxSize;
            double planBefore = Num(shortage.PlnRow, buildCol);

            Set(shortage.PlnRow, buildCol, planBefore + box);
            RecalcEfficiency(buildCol);
            RecalcInventory(shortage, buildCol + _s.TransitWk);
            result.TotalAdditions += box;

            double effAfter = Num(_s.VarRow, buildCol);
            _log($"  +{box} → plan={planBefore + box:N0}  EffVar={effAfter:F6}");

            if (effAfter < _s.TargetEff)
            {
                // Overshot — undo
                Set(shortage.PlnRow, buildCol, planBefore);
                RecalcEfficiency(buildCol);
                RecalcInventory(shortage, buildCol + _s.TransitWk);
                result.TotalAdditions -= box;
                _log($"  Overshot — undone. Moving to next week.");
                buildCol++;
            }
            // else: stay on this buildCol, re-scan for nearest shortage
        }

        progress?.Report((totalWeeks, totalWeeks, "Complete!"));
        result.Success        = true;
        result.Message        = "Balance Finished Successfully";
        result.WeeksProcessed = _s.LastCol - _s.WeekCol + 1;
        _log($"=== Done. Total units added: {result.TotalAdditions} ===");
        return result;
    }
}
