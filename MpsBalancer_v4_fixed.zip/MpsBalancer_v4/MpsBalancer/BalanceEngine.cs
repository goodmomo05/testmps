using OfficeOpenXml;

namespace MpsBalancer;

public class BalanceResult
{
    public bool Success       { get; set; }
    public string Message     { get; set; } = "";
    public int TotalAdditions { get; set; }
    public int WeeksProcessed { get; set; }
}

/// <summary>
/// One 7-row part block in the B-sheet.
/// </summary>
public class PartGroup
{
    public int    InvRow { get; init; }   // Inventory row  (e.g. 14)
    public int    WipRow { get; init; }   // WIP row        (InvRow+1)
    public int    PlnRow { get; init; }   // Plan row       (InvRow+2)
    public int    SalRow { get; init; }   // Sales row      (InvRow+3)
    public double ST     { get; init; }   // Standard hours per unit (col B of PlnRow)
    public string PartNo { get; init; } = "";
}

public class BalanceEngine
{
    private readonly ExcelWorksheet _ws;
    private readonly SheetSettings  _s;
    private readonly Action<string> _log;

    private readonly List<PartGroup> _parts = new();

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings, Action<string> log)
    {
        _ws  = ws;
        _s   = settings;
        _log = log;

        // Build part list by scanning InvRow stepping +7, looking for "Invt Qty" label in col C
        int r = settings.InvRow;
        while (r + 3 <= settings.LastRow)
        {
            string label = ws.Cells[r, 3].Value?.ToString() ?? "";
            string partNo = ws.Cells[r, 1].Value?.ToString()?.Trim() ?? "";
            // Skip sub-total rows (col A starts with "Sub" or is empty)
            bool isRealPart = partNo.Length > 0
                           && !partNo.StartsWith("Sub", StringComparison.OrdinalIgnoreCase);
            if (isRealPart && label.IndexOf("Invt", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                _parts.Add(new PartGroup
                {
                    InvRow = r,
                    WipRow = r + 1,
                    PlnRow = r + 2,
                    SalRow = r + 3,
                    ST     = Num(r + 2, 2),   // col B of plan row
                    PartNo = partNo
                });
            }
            r += 7;
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private double Num(int row, int col)
    {
        var v = _ws.Cells[row, col].Value;
        return v == null ? 0d : Convert.ToDouble(v);
    }

    private void Set(int row, int col, double value) =>
        _ws.Cells[row, col].Value = value;

    // ── Formula simulations ──────────────────────────────────────────────────

    /// <summary>
    /// Recalculate efficiency for a single week column after plan changes.
    ///   Row81[col] = ROUND( SUM(Plan[part][col] * ST[part]), 0 )
    ///   Row69[col] = ROUND( Row81 / Row95 * 100, 1 ) / 100
    ///   Row10[col] = Row90[col] - Row69[col]
    /// </summary>
    private void RecalcEfficiency(int col)
    {
        double stdHrs = 0;
        foreach (var p in _parts)
            stdHrs += Num(p.PlnRow, col) * p.ST;

        double r81 = Math.Round(stdHrs, 0);
        Set(_s.Row81, col, r81);

        double clockHrs = Num(_s.WorkHrsRow, col);
        double r69 = clockHrs == 0 ? 0 : Math.Round(Math.Round(r81 / clockHrs * 100, 1) / 100, 10);
        Set(_s.Row69, col, r69);

        double r10 = Num(_s.Row90, col) - r69;
        Set(_s.VarRow, col, r10);
    }

    /// <summary>
    /// Propagate a plan delta (±units) through inventory for ONE part.
    ///
    /// Formula: Inv[col] = Inv[col-1] + WIP[col-1] - SAL[col-1] + Plan[col - transit]
    ///
    /// Adding `delta` to Plan[planCol] increases Inv at planCol+transit and ALL
    /// columns after that by the same delta (it flows through the chain unchanged
    /// because WIP and Sales are not affected).
    /// </summary>
    private void ApplyInvDelta(PartGroup part, int planCol, double delta)
    {
        int transit     = _s.CoverWk;           // 5 weeks
        int firstAffect = planCol + transit;     // first inv col that sees this plan

        for (int col = firstAffect; col <= _s.LastCol; col++)
            Set(part.InvRow, col, Num(part.InvRow, col) + delta);
    }

    // ── Shortage scan ────────────────────────────────────────────────────────

    /// <summary>
    /// Scan forward from currentWeek to find the first (part, week) with negative
    /// inventory (Invt Qty row).  Marks near-shortage plan cells red per VBA.
    /// Returns (null, 0) when no shortage found anywhere.
    /// </summary>
    private (PartGroup? part, int week) FindNearestShortage(int currentWeek)
    {
        for (int chkWeek = currentWeek; chkWeek <= _s.LastCol; chkWeek++)
        {
            foreach (var part in _parts)
            {
                if (Num(part.InvRow, chkWeek) < 0)
                {
                    // Near-shortage: highlight plan cell red (within CoverWk window)
                    if (chkWeek - currentWeek < _s.CoverWk)
                    {
                        try { _ws.Cells[part.PlnRow, currentWeek]
                                  .Style.Font.Color.SetColor(System.Drawing.Color.Red); }
                        catch { }
                    }
                    return (part, chkWeek);
                }
            }
        }
        return (null, 0);
    }

    // ── Main balance loop ────────────────────────────────────────────────────

    public BalanceResult Run(IProgress<(int current, int total, string status)>? progress = null)
    {
        var result     = new BalanceResult();
        int weekCol    = _s.WeekCol;
        int totalWeeks = _s.LastCol - weekCol + 1;

        _log($"=== Balance Start ===");
        _log($"Parts: {_parts.Count}  WeekCol: {weekCol}  LastCol: {_s.LastCol}");
        _log($"Transit(CoverWk): {_s.CoverWk}  TargetEff: {_s.TargetEff:G4}");
        _log($"Row81: {_s.Row81}  Row69: {_s.Row69}  Row90: {_s.Row90}  VarRow: {_s.VarRow}");
        foreach (var p in _parts)
            _log($"  Part {p.PartNo}: InvRow={p.InvRow} PlnRow={p.PlnRow} ST={p.ST}");

        // Initial efficiency seed for all future weeks
        for (int c = weekCol; c <= _s.LastCol; c++)
            RecalcEfficiency(c);

        while (weekCol <= _s.LastCol)
        {
            progress?.Report((weekCol - _s.WeekCol, totalWeeks, $"Week col {weekCol}…"));

            var (part, _) = FindNearestShortage(weekCol);
            if (part == null)
            {
                _log("No shortages remaining — done.");
                break;
            }

            // Skip weeks with zero clock hours
            if (Num(_s.WorkHrsRow, weekCol) == 0)
            {
                _log($"Col {weekCol}: no clock hours — skip.");
                weekCol++;
                continue;
            }

            double eff = Num(_s.VarRow, weekCol);
            _log($"Col {weekCol}: eff={eff:F6}  shortage → part={part.PartNo} InvRow={part.InvRow}");

            if (eff > _s.TargetEff)
            {
                // ── Add 40 units to the shortage part's plan this week ──
                double planBefore = Num(part.PlnRow, weekCol);
                Set(part.PlnRow, weekCol, planBefore + 40);
                result.TotalAdditions += 40;

                // Recalc efficiency (shared across all parts — whole row 81 changes)
                RecalcEfficiency(weekCol);

                // Propagate +40 through this part's inventory (transit offset)
                ApplyInvDelta(part, weekCol, +40);

                double effAfter = Num(_s.VarRow, weekCol);
                _log($"  +40 → plan={planBefore + 40:N0}  eff after={effAfter:F6}");

                if (effAfter < _s.TargetEff)
                {
                    // ── Overshot — undo ──
                    Set(part.PlnRow, weekCol, planBefore);
                    result.TotalAdditions -= 40;
                    RecalcEfficiency(weekCol);
                    ApplyInvDelta(part, weekCol, -40);   // undo the inventory delta too
                    _log($"  Overshot — undone.");

                    // Still a shortage this week?
                    double invNow = Num(part.InvRow, weekCol);
                    if (invNow < 0)
                    {
                        string msg =
                            $"STOPPED: Efficiency limit reached with shortage remaining.\n\n" +
                            $"Part:      {part.PartNo}\n" +
                            $"Week Col:  {weekCol}\n" +
                            $"Shortage:  {invNow:N0}";
                        _log($"*** {msg}");
                        result.Success  = false;
                        result.Message  = msg;
                        result.WeeksProcessed = weekCol - _s.WeekCol;
                        return result;
                    }

                    weekCol++;
                }
                // else: eff still above target → stay on same weekCol, keep adding
            }
            else
            {
                // Efficiency at or below target for this week — move on
                _log($"  Eff at/below target — next week.");
                weekCol++;
            }

            result.WeeksProcessed = weekCol - _s.WeekCol;
        }

        progress?.Report((totalWeeks, totalWeeks, "Complete!"));
        result.Success        = true;
        result.Message        = "Balance Finished Successfully";
        result.WeeksProcessed = _s.LastCol - _s.WeekCol + 1;
        _log($"=== Done. Total units added: {result.TotalAdditions} ===");
        return result;
    }
}
