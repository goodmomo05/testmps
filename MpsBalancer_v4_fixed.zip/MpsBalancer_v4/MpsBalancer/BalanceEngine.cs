using OfficeOpenXml;

namespace MpsBalancer;

public class BalanceResult
{
    public bool   Success       { get; set; }
    public string Message       { get; set; } = "";
    public int    TotalAdditions{ get; set; }
    public int    WeeksProcessed{ get; set; }
}

public class PartGroup
{
    public int    InvRow { get; init; }
    public int    PlnRow { get; init; }
    public double ST     { get; init; }   // std hours per unit (col B of PlnRow)
    public string PartNo { get; init; } = "";
    public int    BoxSize{ get; set;  }   // user-supplied batch qty
}

public class BalanceEngine
{
    private readonly ExcelWorksheet  _ws;
    private readonly SheetSettings   _s;
    private readonly Action<string>  _log;
    private readonly List<PartGroup> _parts = new();

    public IReadOnlyList<PartGroup> Parts => _parts;

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings, Action<string> log)
        : this(ws, settings, new Dictionary<string,int>(), log) { }

    public BalanceEngine(ExcelWorksheet ws, SheetSettings settings,
                         Dictionary<string,int> boxSizes, Action<string> log)
    {
        _ws  = ws;
        _s   = settings;
        _log = log;

        // Scan from InvRow downward in steps of 7 to collect real parts
        int r = settings.InvRow;
        while (r + 3 <= settings.LastRow)
        {
            string label  = ws.Cells[r, 3].Value?.ToString()?.Trim() ?? "";
            string partNo = ws.Cells[r, 1].Value?.ToString()?.Trim() ?? "";

            bool isRealPart = partNo.Length > 0
                           && !partNo.StartsWith("Sub", StringComparison.OrdinalIgnoreCase);

            if (isRealPart && label.IndexOf("Invt", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                _parts.Add(new PartGroup
                {
                    InvRow  = r,
                    PlnRow  = r + 2,
                    ST      = Num(r + 2, 2),   // col B of plan row
                    PartNo  = partNo,
                    BoxSize = boxSizes.TryGetValue(partNo, out int bs) && bs > 0 ? bs : 1
                });
            }
            r += 7;
        }
    }

    // ── Cell helpers ─────────────────────────────────────────────────────────

    private double Num(int row, int col)
    {
        var v = _ws.Cells[row, col].Value;
        return v == null ? 0d : Convert.ToDouble(v);
    }

    private void Set(int row, int col, double value) =>
        _ws.Cells[row, col].Value = value;

    // ── Efficiency recalc ────────────────────────────────────────────────────
    //
    //  StdHrs[col]   = ROUND( SUM( Plan[part][col] * ST[part] ), 0 )
    //  PlanEff[col]  = ROUND( StdHrs / ClockHrs * 100, 1 ) / 100
    //  EffVar[col]   = EffTarget[col] - PlanEff[col]           ← NEVER MODIFIED
    //
    // We write StdHrs and PlanEff so that Excel's fixed EffVar formula
    // (which references those two rows) automatically returns the right value.
    // We do NOT write to EffVar (VarRow) — we only READ it.

    private void RecalcEfficiency(int col)
    {
        // Std Hours
        double stdHrs = 0;
        foreach (var p in _parts)
            stdHrs += Num(p.PlnRow, col) * p.ST;
        double r81 = Math.Round(stdHrs, 0);
        Set(_s.Row81, col, r81);

        // Plan Efficiency
        double clockHrs = Num(_s.WorkHrsRow, col);
        double r69 = clockHrs == 0
            ? 0d
            : Math.Round(Math.Round(r81 / clockHrs * 100, 1) / 100, 10);
        Set(_s.Row69, col, r69);

        // EffVar (VarRow) is a FIXED FORMULA in the sheet — we do NOT write it.
        // Reading Num(_s.VarRow, col) after this will pick up the formula result.
    }

    // ── Inventory propagation ─────────────────────────────────────────────────
    //
    // Adding `delta` to Plan[planCol] ripples into Inv from planCol+transit onward.
    // (Sales and WIP are unchanged, so the delta carries forward unchanged.)

    private void ApplyInvDelta(PartGroup part, int planCol, double delta)
    {
        int firstAffect = planCol + _s.CoverWk;
        for (int c = firstAffect; c <= _s.LastCol; c++)
            Set(part.InvRow, c, Num(part.InvRow, c) + delta);
    }

    // ── Nearest shortage scan ─────────────────────────────────────────────────
    //
    // Returns the (part, week-col) of the first negative inventory found
    // scanning ALL columns from startCol forward across ALL parts.
    // Returns (null, 0) if no shortage exists anywhere.

    private (PartGroup? part, int col) FindNearestShortage(int startCol)
    {
        for (int c = startCol; c <= _s.LastCol; c++)
            foreach (var p in _parts)
                if (Num(p.InvRow, c) < 0)
                    return (p, c);

        return (null, 0);
    }

    // ── Main balance loop ─────────────────────────────────────────────────────
    //
    // Algorithm:
    //   buildCol  = current week we are trying to build in (walks forward)
    //   For each buildCol:
    //     1. Find nearest shortage anywhere in the horizon.
    //     2. If no shortage → done.
    //     3. If this week has no clock hours → skip.
    //     4. Read EffVar for this buildCol (from the sheet formula — DO NOT WRITE IT).
    //     5. If EffVar > TargetEff (i.e. there is still headroom):
    //          a. Add one box of the shortage part to Plan[buildCol].
    //          b. Recalc StdHrs + PlanEff for this col.
    //          c. Apply +boxSize delta to inventory.
    //          d. Read new EffVar.
    //          e. If new EffVar < TargetEff → overshot: undo, move to next week.
    //          f. Else → loop back to step 1 (re-scan for nearest shortage).
    //     6. If EffVar <= TargetEff → capacity used up for this week → next week.

    public BalanceResult Run(IProgress<(int current, int total, string status)>? progress = null)
    {
        var result     = new BalanceResult();
        int totalWeeks = _s.LastCol - _s.WeekCol + 1;

        _log("=== Balance Start ===");
        _log($"Parts: {_parts.Count}  WeekCol: {_s.WeekCol}  LastCol: {_s.LastCol}");
        _log($"Transit: {_s.CoverWk} wks  TargetEff: {_s.TargetEff:G4}");
        _log($"Row81={_s.Row81}  Row69={_s.Row69}  Row90={_s.Row90}  VarRow={_s.VarRow}");
        foreach (var p in _parts)
            _log($"  Part {p.PartNo}: InvRow={p.InvRow} PlnRow={p.PlnRow} ST={p.ST} BoxSize={p.BoxSize}");

        // Seed efficiency for all weeks based on existing plan
        for (int c = _s.WeekCol; c <= _s.LastCol; c++)
            RecalcEfficiency(c);

        int buildCol = _s.WeekCol;

        while (buildCol <= _s.LastCol)
        {
            progress?.Report((buildCol - _s.WeekCol, totalWeeks, $"Week col {buildCol}…"));

            // 1. Find nearest shortage across all weeks from current build col
            var (shortage, shortageCol) = FindNearestShortage(_s.WeekCol);
            if (shortage == null)
            {
                _log("No shortages remaining — done.");
                break;
            }

            // 2. Skip weeks with no clock hours
            if (Num(_s.WorkHrsRow, buildCol) == 0)
            {
                _log($"Col {buildCol}: no clock hours — skip.");
                buildCol++;
                continue;
            }

            // 3. Read current efficiency variance (from the sheet formula — READ ONLY)
            double effVar = Num(_s.VarRow, buildCol);
            _log($"Col {buildCol}: EffVar={effVar:F6}  Shortage→ part={shortage.PartNo} col={shortageCol}");

            if (effVar > _s.TargetEff)
            {
                // Headroom available — add one box to the shortage part
                int    box        = shortage.BoxSize;
                double planBefore = Num(shortage.PlnRow, buildCol);

                Set(shortage.PlnRow, buildCol, planBefore + box);
                RecalcEfficiency(buildCol);
                ApplyInvDelta(shortage, buildCol, box);
                result.TotalAdditions += box;

                double effAfter = Num(_s.VarRow, buildCol);
                _log($"  +{box} → plan={planBefore + box:N0}  EffVar after={effAfter:F6}");

                if (effAfter < _s.TargetEff)
                {
                    // Overshot — undo this box addition
                    Set(shortage.PlnRow, buildCol, planBefore);
                    RecalcEfficiency(buildCol);
                    ApplyInvDelta(shortage, buildCol, -box);
                    result.TotalAdditions -= box;
                    _log($"  Overshot — undone. Moving to next week.");
                    buildCol++;
                }
                // else: still have headroom → re-scan for nearest shortage, stay on this col
            }
            else
            {
                // No headroom left for this week — move forward
                _log($"  EffVar at/below target — next week.");
                buildCol++;
            }

            result.WeeksProcessed = buildCol - _s.WeekCol;
        }

        progress?.Report((totalWeeks, totalWeeks, "Complete!"));
        result.Success        = true;
        result.Message        = "Balance Finished Successfully";
        result.WeeksProcessed = _s.LastCol - _s.WeekCol + 1;
        _log($"=== Done. Total units added: {result.TotalAdditions} ===");
        return result;
    }
}
