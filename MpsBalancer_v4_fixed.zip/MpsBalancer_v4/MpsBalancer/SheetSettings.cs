namespace MpsBalancer;

public class SheetSettings
{
    public int WeekCol     { get; set; }   // First week column (1-based)
    public int VarRow      { get; set; }   // Efficiency variance row (read-only formula)
    public int WorkHrsRow  { get; set; }   // Clock hours row
    public int InvRow      { get; set; }   // First inventory row
    public int PlnRow      { get; set; }   // First plan row (= InvRow + 2)
    public int CoverWk     { get; set; }   // Safety cover weeks (lookahead for highlighting)
    public int TransitWk   { get; set; }   // Transit lead time weeks (plan→inventory offset)
    public double TargetEff { get; set; }  // Min allowed EffVar (e.g. -0.01 = allow 1% over)

    // Formula-derived rows (auto-detected by label scan)
    public int Row81 { get; set; }   // Std Hours row  = SUM(Plan * ST)
    public int Row69 { get; set; }   // Plan Efficiency row = StdHrs / ClockHrs
    public int Row90 { get; set; }   // Efficiency Target row (fixed schedule)

    public int LastCol { get; set; }
    public int LastRow { get; set; }
}
