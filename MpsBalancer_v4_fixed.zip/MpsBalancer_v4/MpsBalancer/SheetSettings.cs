namespace MpsBalancer;

public class SheetSettings
{
    // From column O (15) — mirrors VBA Cells(r, 15)
    public int WeekCol    { get; set; }   // R3 — starting week column (1-based)
    public int VarRow     { get; set; }   // R4 — efficiency variance row (row 10)
    public int WorkHrsRow { get; set; }   // R5 — clock hours row (row 95)
    public int InvRow     { get; set; }   // R6 — first inventory row (row 14)
    public int PlnRow     { get; set; }   // R7 — first plan row (row 16)
    public int CoverWk    { get; set; }   // R8 — weeks to cover / transit time
    public double TargetEff { get; set; } // R9 — eff variance threshold (e.g. -0.01)

    // Formula rows (discovered by scanning or hardcoded from known structure)
    public int Row81 { get; set; }   // Total std hours = SUM(Plan[i] * ST[i])
    public int Row69 { get; set; }   // Plan efficiency = ROUND(Row81/Row95*100,1)/100
    public int Row90 { get; set; }   // Efficiency target (fixed per week from schedule)

    public int LastCol { get; set; }
    public int LastRow { get; set; }
}
