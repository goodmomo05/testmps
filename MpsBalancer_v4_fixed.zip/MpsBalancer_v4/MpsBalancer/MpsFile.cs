using OfficeOpenXml;

namespace MpsBalancer;

public class MpsFile : IDisposable
{
    private ExcelPackage _package;
    private bool _disposed;

    public string FilePath  { get; }
    public List<string> BSheets   { get; } = new();
    public List<string> AllSheets { get; } = new();

    private MpsFile(string path, ExcelPackage pkg)
    {
        FilePath = path;
        _package = pkg;
        foreach (var ws in pkg.Workbook.Worksheets)
        {
            AllSheets.Add(ws.Name);
            if (ws.Name.StartsWith("B-", StringComparison.OrdinalIgnoreCase))
                BSheets.Add(ws.Name);
        }
    }

    public static MpsFile Open(string path)
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        var pkg = new ExcelPackage(new FileInfo(path));
        return new MpsFile(path, pkg);
    }

    public ExcelWorksheet GetSheet(string name)
    {
        if (string.IsNullOrEmpty(name)) return null!;
        return _package.Workbook.Worksheets[name]!;
    }

    public SheetSettings ReadSettings(string sheetName)
    {
        var ws = GetSheet(sheetName);

        int lastRow = ws.Dimension?.End.Row    ?? 120;
        int lastCol = ws.Dimension?.End.Column ?? 82;

        // Step 1: Try config cells in column O (older sheet format)
        int weekColCfg   = GetInt(ws, 3, 15);
        int varRowCfg    = GetInt(ws, 4, 15);
        int workHrsCfg   = GetInt(ws, 5, 15);
        int invRowCfg    = GetInt(ws, 6, 15);
        int plnRowCfg    = GetInt(ws, 7, 15);
        int coverWkCfg   = GetInt(ws, 8, 15);
        double targetEffCfg = GetDbl(ws, 9, 15);

        // Step 2: Auto-detect by scanning row labels in col C
        int varRow = 0, workHrsRow = 0, invRow = 0;
        int row81 = 0, row69 = 0, row90 = 0;
        int coverWk = 0;
        double targetEff = 0;

        for (int r = 1; r <= Math.Min(lastRow, 120); r++)
        {
            string label = ws.Cells[r, 3].Value?.ToString()?.Trim() ?? "";

            if (varRow == 0 && label.IndexOf("Var", StringComparison.OrdinalIgnoreCase) >= 0
                            && (label.IndexOf("Effic", StringComparison.OrdinalIgnoreCase) >= 0
                             || label.EndsWith("Var:", StringComparison.OrdinalIgnoreCase)))
                varRow = r;

            else if (workHrsRow == 0
                  && (label.Equals("Clock Hours", StringComparison.OrdinalIgnoreCase)
                   || label.Equals("Working Hours", StringComparison.OrdinalIgnoreCase)
                   || label.Equals("Worked Hours", StringComparison.OrdinalIgnoreCase)))
                workHrsRow = r;

            else if (row81 == 0
                  && (label.StartsWith("Total Std", StringComparison.OrdinalIgnoreCase)
                   || label.StartsWith("Assy Std", StringComparison.OrdinalIgnoreCase)))
                row81 = r;

            else if (row69 == 0
                  && label.IndexOf("Plan Effic", StringComparison.OrdinalIgnoreCase) >= 0)
                row69 = r;

            else if (row90 == 0
                  && label.IndexOf("Effic", StringComparison.OrdinalIgnoreCase) >= 0
                  && label.IndexOf("Target", StringComparison.OrdinalIgnoreCase) >= 0)
                row90 = r;

            else if (invRow == 0
                  && label.IndexOf("Invt", StringComparison.OrdinalIgnoreCase) >= 0
                  && label.IndexOf("Qty", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                string partCell = ws.Cells[r, 1].Value?.ToString()?.Trim() ?? "";
                if (partCell.Length > 0 && !partCell.StartsWith("Sub", StringComparison.OrdinalIgnoreCase))
                    invRow = r;
            }
        }

        // Step 3: Scan header rows for Safety Weeks, Transit Weeks, and Target Efficiency
        int transitWk = 0;
        for (int r = 1; r <= Math.Min(lastRow, 15); r++)
            for (int c = 1; c <= Math.Min(lastCol, 20); c++)
            {
                string cell = ws.Cells[r, c].Value?.ToString()?.Trim() ?? "";
                if (coverWk == 0 && cell.Equals("Safety Weeks", StringComparison.OrdinalIgnoreCase))
                {
                    int v = GetInt(ws, r, c + 2);
                    if (v > 0) coverWk = v;
                }
                if (transitWk == 0 && cell.Equals("Transit Weeks", StringComparison.OrdinalIgnoreCase))
                {
                    int v = GetInt(ws, r, c + 2);
                    if (v > 0) transitWk = v;
                }
                if (targetEff == 0 && cell.IndexOf("Target Effic", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    double v = GetDbl(ws, r, c + 2);
                    // Sheet stores e.g. 93% — TargetEff is minimum allowed EffVar = -(tolerance)
                    // EffVar = EffTarget - PlanEff; we allow up to -1% → TargetEff = -0.01
                    if (v != 0) targetEff = -0.01; // always use -1% tolerance
                }
            }

        // Step 4: Detect WeekCol - first numeric column on VarRow
        int weekCol = 0;
        if (varRow > 0)
            for (int c = 2; c <= lastCol; c++)
            {
                var cv = ws.Cells[varRow, c].Value;
                if (cv is double or int or long or float or decimal)
                { weekCol = c; break; }
            }

        // Step 5: Fallback to config-cell values where auto-detect missed
        if (weekCol   == 0 && weekColCfg  > 0) weekCol   = weekColCfg;
        if (varRow    == 0 && varRowCfg   > 0) varRow    = varRowCfg;
        if (workHrsRow== 0 && workHrsCfg  > 0) workHrsRow= workHrsCfg;
        if (invRow    == 0 && invRowCfg   > 0) invRow    = invRowCfg;
        if (coverWk   == 0 && coverWkCfg  > 0) coverWk   = coverWkCfg;
        if (targetEff == 0 && targetEffCfg!= 0) targetEff = targetEffCfg;
        if (transitWk == 0) transitWk = 3; // default transit if not found in header

        // Step 6: Derive plnRow from invRow
        int plnRow = invRow > 0 ? invRow + 2 : (plnRowCfg > 0 ? plnRowCfg : 0);

        // Step 7: Offset-based fallbacks - ONLY if workHrsRow is valid (fixes the crash)
        if (workHrsRow > 0)
        {
            if (row81 == 0) row81 = workHrsRow - 14;
            if (row69 == 0) row69 = workHrsRow - 26;
            if (row90 == 0) row90 = workHrsRow - 5;
        }

        // Step 8: Trim lastCol to actual data
        int headerRow = varRow > 1 ? varRow - 1 : 11;
        if (weekCol > 0)
            for (int c = lastCol; c >= weekCol; c--)
                if (ws.Cells[headerRow, c].Value != null) { lastCol = c; break; }

        if (coverWk  <= 0) coverWk  = 3;
        if (targetEff == 0) targetEff = -0.01;

        return new SheetSettings
        {
            WeekCol    = weekCol,
            VarRow     = varRow,
            WorkHrsRow = workHrsRow,
            InvRow     = invRow,
            PlnRow     = plnRow,
            CoverWk    = coverWk,
            TransitWk  = transitWk,
            TargetEff  = targetEff,
            Row81      = row81,
            Row69      = row69,
            Row90      = row90,
            LastCol    = lastCol,
            LastRow    = lastRow
        };
    }

    public void Save(string? outputPath = null)
    {
        if (outputPath != null) _package.SaveAs(new FileInfo(outputPath));
        else _package.Save();
    }

    private static int    GetInt(ExcelWorksheet ws, int r, int c) =>
        ws.Cells[r, c].Value is null ? 0 : Convert.ToInt32(ws.Cells[r, c].Value);
    private static double GetDbl(ExcelWorksheet ws, int r, int c) =>
        ws.Cells[r, c].Value is null ? 0d : Convert.ToDouble(ws.Cells[r, c].Value);

    public void Dispose()
    {
        if (!_disposed) { _package.Dispose(); _disposed = true; }
    }
}
