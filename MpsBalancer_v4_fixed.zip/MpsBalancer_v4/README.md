# MPS Balancer — Desktop App

Replaces the `FastBalance` VBA macro with a standalone Windows desktop application.

## What it does

Exactly replicates the VBA macro logic:

1. Reads settings from column O (col 15) of the selected B-sheet:
   - **Starting Week Column** (row 3)
   - **Var Row / Efficiency Row** (row 4) — row 10 in standard MPS
   - **Working Hours Row** (row 5) — row 95 in standard MPS
   - **Inv Row** (row 6) — row 14 in standard MPS
   - **Pln Row** (row 7) — row 16 in standard MPS
   - **Weeks to Cover** (row 8) — shortage lookahead window
   - **Target Efficiency** (row 9) — signed delta threshold

2. Scans week columns left to right:
   - **Skips** weeks with 0 working hours
   - **Finds the nearest shortage** (negative inventory) scanning forward
   - If efficiency > target: **adds 40 units** to the plan row of the shortage part
   - Recalculates inventory forward
   - If efficiency drops below target after adding: **undoes** the addition
   - If shortage still exists after undo: **stops and alerts** (same as macro `MsgBox`)
   - Near-shortage plan cells (within CoverWk range) are **highlighted red**

3. Saves the modified file (overwrite or new file)

## Build & Run

### Requirements
- .NET 8 SDK (Windows)
- Visual Studio 2022 or `dotnet` CLI

### Build
```
cd MpsBalancer
dotnet build
dotnet run
```

Or open `MpsBalancer.sln` in Visual Studio and press F5.

### Publish (standalone .exe)
```
dotnet publish MpsBalancer/MpsBalancer.csproj -c Release -r win-x64 --self-contained -o publish/
```
The `publish/` folder will contain `MpsBalancer.exe` — no .NET install required on the target machine.

## How to Use

1. **Open file** — click Browse and select your MPS `.xlsx` file
2. **Select B-sheet** — the list shows all sheets starting with `B-`
3. **Review settings** — auto-read from column O, editable before running
4. **Choose output** — overwrite original or save as new file
5. **Run Balance** — progress bar + log shows every step
6. **Result** — success message or stopped alert with part/week details

## Excel Formula Limitation

EPPlus (the C# Excel library) cannot execute Excel formulas like VBA's `ws.Calculate`. The app simulates the inventory recalculation:

```
Inventory[week] = Inventory[week-1] + Plan[week-1] - Sales[week-1]
```

If your sheet uses more complex formulas for inventory, the efficiency variance row (row 10) may not update correctly. In that case, after running the balancer, open the saved file in Excel and press Ctrl+Alt+F9 to force a full recalculation.

## Project Structure

```
MpsBalancer/
├── MpsBalancer.sln
└── MpsBalancer/
    ├── MpsBalancer.csproj   (EPPlus dependency)
    ├── Program.cs            (entry point)
    ├── MainForm.cs           (UI)
    ├── BalanceEngine.cs      (core logic — mirrors VBA)
    ├── MpsFile.cs            (Excel file reader/writer)
    └── SheetSettings.cs      (settings model)
```
