@echo off
echo Building MPS Balancer...
cd /d "%~dp0"
dotnet publish MpsBalancer\MpsBalancer.csproj ^
  -c Release ^
  -r win-x64 ^
  --self-contained ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -o publish\

if %ERRORLEVEL% EQU 0 (
    echo.
    echo BUILD SUCCESSFUL!
    echo Output: %~dp0publish\MpsBalancer.exe
    echo.
    start "" "%~dp0publish\"
) else (
    echo.
    echo BUILD FAILED. Check errors above.
)
pause
