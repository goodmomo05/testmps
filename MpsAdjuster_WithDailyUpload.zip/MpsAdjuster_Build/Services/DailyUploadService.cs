namespace MpsAdjuster.Services;

/// <summary>
/// Daily Upload feature — DENSO CZ build report processor.
///
/// RAW FILE LAYOUT (DailyBuild_Report_DENSO_CZ.xlsx):
///   Row 1 : header — col A = part label, cols B+ = date values (Excel serial numbers or DateTime).
///   Row 2+: data   — col A = part number string, cols B+ = qty doubles.
///
/// Week columns are assigned in ascending date order → indices 0-6:
///   0=Sat, 1=Sun, 2=Mon, 3=Tue, 4=Wed, 5=Thu, 6=Fri
///
/// Package modes:
///   1 Package  → sum all 7 days              → placed under Saturday date column in template
///   2 Packages → Pkg1 = Sat+Sun+Mon (0-2)   → placed under Saturday date column
///                Pkg2 = Tue+Wed+Thu+Fri (3-6)→ placed under Monday   date column
/// </summary>
public class DailyUploadService(ExcelService xl)
{
    // ── Public entry point ────────────────────────────────────────────────────

    public Task<int> RunAsync(
        string[]           rawPaths,
        string             templatePath,
        string             outputPath,
        PackageMode        mode,
        IProgress<string>? p = null)
        => Task.Run(() => Run(rawPaths, templatePath, outputPath, mode, p));

    // ── Pipeline ──────────────────────────────────────────────────────────────

    private int Run(
        string[]           rawPaths,
        string             templatePath,
        string             outputPath,
        PackageMode        mode,
        IProgress<string>? p)
    {
        p?.Report("Daily Upload: reading raw file(s)…");
        var rawRows = LoadAndMerge(rawPaths);
        if (rawRows.Count == 0)
            throw new InvalidDataException("No data rows found in the selected raw file(s).");

        p?.Report($"Daily Upload: aggregating {rawRows.Count} row(s)…");
        var aggregated = Aggregate(rawRows, mode);

        p?.Report("Daily Upload: reading template…");
        using var wbTpl = new XLWorkbook(templatePath);
        var wsTpl = wbTpl.Worksheets.First();
        var (satCol, monCol) = FindTemplateDateColumns(wsTpl);

        if (satCol == 0)
            throw new InvalidDataException(
                "No Saturday date column found in the template. " +
                "Ensure the header row contains date values (Saturday through Friday).");

        if (mode == PackageMode.TwoPackages && monCol == 0)
            throw new InvalidDataException(
                "2-Package mode requires a Monday date column in the template.");

        p?.Report("Daily Upload: writing output…");
        File.Copy(templatePath, outputPath, overwrite: true);
        using var wbOut = new XLWorkbook(outputPath);
        WriteResults(wbOut.Worksheets.First(), aggregated, satCol, monCol, mode);
        wbOut.Save();

        xl.LogLine("DailyUpload", "OK",
            $"{aggregated.Count} part(s) — mode={mode} — {Path.GetFileName(outputPath)}");

        return aggregated.Count;
    }

    // ── Step 1: Load & merge ──────────────────────────────────────────────────

    private record RawRow(string Part, double[] DayQtys); // DayQtys[0]=Sat…[6]=Fri

    private List<RawRow> LoadAndMerge(string[] paths)
    {
        var all = new List<RawRow>();
        foreach (var path in paths)
        {
            using var tmp = XlsConverter.Prepare(path);
            using var wb  = new XLWorkbook(tmp.Path);
            var rows = ReadRawSheet(wb.Worksheets.First());
            all.AddRange(rows);
            xl.LogLine("DailyUpload", "INFO",
                $"Loaded {Path.GetFileName(path)} — {rows.Count} row(s)");
        }
        return all;
    }

    private List<RawRow> ReadRawSheet(IXLWorksheet ws)
    {
        var list = new List<RawRow>();

        int hdrRow = DetectHeaderRow(ws);
        if (hdrRow == 0) return list;

        // Map column number → day index (0=Sat … 6=Fri), sorted by date ascending
        var dayColMap = BuildDayColumnMap(ws, hdrRow);
        if (dayColMap.Count == 0) return list;

        int lastRow = ws.LastRowUsed()?.RowNumber() ?? hdrRow;
        for (int r = hdrRow + 1; r <= lastRow; r++)
        {
            var part = xl.CleanStr(ws.Cell(r, 1).Value);
            if (string.IsNullOrWhiteSpace(part)) continue;

            var qtys = new double[7];
            foreach (var (col, dayIdx) in dayColMap)
            {
                var v = ws.Cell(r, col).Value;
                if (v.IsNumber)
                    qtys[dayIdx] += v.GetNumber();
                else if (double.TryParse(xl.CleanStr(v),
                    NumberStyles.Any, CultureInfo.InvariantCulture, out double d))
                    qtys[dayIdx] += d;
            }

            list.Add(new RawRow(part, qtys));
        }

        return list;
    }

    /// <summary>First row where any col B+ cell is recognisable as a date.</summary>
    private static int DetectHeaderRow(IXLWorksheet ws)
    {
        int scanLimit = Math.Min(ws.LastRowUsed()?.RowNumber() ?? 1, 20);
        for (int r = 1; r <= scanLimit; r++)
        {
            int lastCol = ws.Row(r).LastCellUsed()?.Address.ColumnNumber ?? 1;
            for (int c = 2; c <= lastCol; c++)
                if (TryGetDate(ws.Cell(r, c), out _)) return r;
        }
        return 0;
    }

    /// <summary>col# → day index 0-6, derived by sorting detected dates ascending.</summary>
    private static Dictionary<int, int> BuildDayColumnMap(IXLWorksheet ws, int hdrRow)
    {
        var map   = new Dictionary<int, int>();
        var dates = new List<(int col, DateTime date)>();
        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 1;

        for (int c = 2; c <= lastCol; c++)
            if (TryGetDate(ws.Cell(hdrRow, c), out DateTime dt))
                dates.Add((c, dt));

        if (dates.Count == 0) return map;
        dates.Sort((a, b) => a.date.CompareTo(b.date));
        int take = Math.Min(dates.Count, 7);
        for (int i = 0; i < take; i++)
            map[dates[i].col] = i;

        return map;
    }

    // ── Step 2: Aggregate ─────────────────────────────────────────────────────

    public record AggRow(string Part, double Pkg1, double Pkg2);

    private static List<AggRow> Aggregate(List<RawRow> rows, PackageMode mode)
        => rows
            .GroupBy(r => r.Part, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var sum = new double[7];
                foreach (var row in g)
                    for (int i = 0; i < 7; i++)
                        sum[i] += row.DayQtys[i];

                double pkg1, pkg2;
                if (mode == PackageMode.OnePackage)
                {
                    pkg1 = sum.Sum();
                    pkg2 = 0;
                }
                else
                {
                    pkg1 = sum[0] + sum[1] + sum[2];              // Sat + Sun + Mon
                    pkg2 = sum[3] + sum[4] + sum[5] + sum[6];    // Tue + Wed + Thu + Fri
                }

                return new AggRow(g.Key, pkg1, pkg2);
            })
            .OrderBy(r => r.Part)
            .ToList();

    // ── Step 3: Locate template date columns ──────────────────────────────────

    /// <summary>Returns (satColNumber, monColNumber) in the template header row.</summary>
    private static (int satCol, int monCol) FindTemplateDateColumns(IXLWorksheet ws)
    {
        int hdrRow = DetectHeaderRow(ws);
        if (hdrRow == 0) return (0, 0);

        int lastCol = ws.Row(hdrRow).LastCellUsed()?.Address.ColumnNumber ?? 1;
        int satCol = 0, monCol = 0;

        for (int c = 2; c <= lastCol; c++)
        {
            if (!TryGetDate(ws.Cell(hdrRow, c), out DateTime dt)) continue;
            if (dt.DayOfWeek == DayOfWeek.Saturday && satCol == 0) satCol = c;
            if (dt.DayOfWeek == DayOfWeek.Monday   && monCol == 0) monCol = c;
            if (satCol != 0 && monCol != 0) break;
        }

        return (satCol, monCol);
    }

    // ── Step 4: Write into output ─────────────────────────────────────────────

    private static void WriteResults(
        IXLWorksheet ws,
        List<AggRow> rows,
        int          satCol,
        int          monCol,
        PackageMode  mode)
    {
        int hdrRow   = DetectHeaderRow(ws);
        int dataStart = hdrRow > 0 ? hdrRow + 1 : 2;

        // Clear any existing data rows
        int lastExisting = ws.LastRowUsed()?.RowNumber() ?? (dataStart - 1);
        if (lastExisting >= dataStart)
            ws.Rows(dataStart, lastExisting).Delete();

        int row = dataStart;
        foreach (var agg in rows)
        {
            ws.Cell(row, 1).Value = agg.Part;

            if (agg.Pkg1 != 0)
                ws.Cell(row, satCol).Value = agg.Pkg1;

            if (mode == PackageMode.TwoPackages && monCol != 0 && agg.Pkg2 != 0)
                ws.Cell(row, monCol).Value = agg.Pkg2;

            row++;
        }
    }

    // ── Date helpers ──────────────────────────────────────────────────────────

    private static bool TryGetDate(IXLCell cell, out DateTime dt)
    {
        dt = default;
        var v = cell.Value;

        if (v.IsDateTime) { dt = v.GetDateTime(); return true; }

        // Excel serial numbers stored as plain numbers (e.g. 46151 = 2026-05-09)
        if (v.IsNumber)
        {
            double serial = v.GetNumber();
            if (serial >= 1 && serial <= 2958465)
            {
                try { dt = DateTime.FromOADate(serial); return true; }
                catch { /* not a valid date serial */ }
            }
        }

        // Text dates — ISO and yyyy/MM/dd
        if (v.IsText)
        {
            var s = v.GetText().Trim();
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture,
                                  DateTimeStyles.None, out dt)) return true;
            if (DateTime.TryParseExact(s, "yyyy/MM/dd",
                                       CultureInfo.InvariantCulture,
                                       DateTimeStyles.None, out dt)) return true;
        }

        return false;
    }
}

/// <summary>Package calculation mode for Daily Upload.</summary>
public enum PackageMode
{
    OnePackage  = 1,
    TwoPackages = 2
}
