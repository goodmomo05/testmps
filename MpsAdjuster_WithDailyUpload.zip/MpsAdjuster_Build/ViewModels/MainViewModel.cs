namespace MpsAdjuster.ViewModels;

public partial class MainViewModel : ObservableObject
{
    // ── Services ──────────────────────────────────────────────────────────────
    public  ExcelService       Xl           { get; } = new();
    private MpsCopyService     _copy;
    private OsImportService    _os;
    private EosImportService   _eos;
    private PlanImportService  _plan;
    private SalesImportService _sales;
    private FormulasService    _formulas;
    private GoldenSalesService _golden;
    private OpelSalesService   _opel;
    private VolvoSalesService  _volvo;
    private DailyUploadService _dailyUpload;

    // ── Observable state ──────────────────────────────────────────────────────
    [ObservableProperty] string oldMpsPath  = "";
    [ObservableProperty] string newMpsPath  = "";
    [ObservableProperty] bool   isBusy      = false;
    [ObservableProperty] string statusText  = "Ready — select your MPS files to begin.";
    [ObservableProperty] double progressVal = 0;
    [ObservableProperty] string activeTab   = "Copy";

    [ObservableProperty] bool stepOsDone    = false;
    [ObservableProperty] bool stepEosDone   = false;
    [ObservableProperty] bool stepPlanDone  = false;
    [ObservableProperty] bool stepSalesDone = false;
    [ObservableProperty] bool stepCopyDone  = false;
    [ObservableProperty] bool stepFormDone  = false;

    [ObservableProperty] bool isDarkMode = false;

    public ObservableCollection<LogEntry> LogEntries => Xl.Log;

    // ── Commands ──────────────────────────────────────────────────────────────
    public IRelayCommand      BrowseOldCommand       { get; }
    public IRelayCommand      BrowseNewCommand       { get; }
    public IRelayCommand      SetTabCommand          { get; }
    public IRelayCommand      ClearLogCommand        { get; }
    public IRelayCommand      ToggleDarkModeCommand  { get; }
    public IAsyncRelayCommand RunCopyCommand         { get; }
    public IAsyncRelayCommand RunAllCommand          { get; }
    public IAsyncRelayCommand ImportOsCommand        { get; }
    public IAsyncRelayCommand ImportEosCommand       { get; }
    public IAsyncRelayCommand ImportPlanCommand      { get; }
    public IAsyncRelayCommand ImportSalesCommand     { get; }
    public IAsyncRelayCommand InsertFormulasCommand  { get; }
    public IAsyncRelayCommand GoldeSalesCommand      { get; }
    public IAsyncRelayCommand OpelSalesCommand       { get; }
    public IAsyncRelayCommand VolvoSalesCommand      { get; }
    public IAsyncRelayCommand DailyUploadCommand     { get; }

    public MainViewModel()
    {
        _copy        = new MpsCopyService(Xl);
        _os          = new OsImportService(Xl);
        _eos         = new EosImportService(Xl);
        _plan        = new PlanImportService(Xl);
        _sales       = new SalesImportService(Xl);
        _formulas    = new FormulasService(Xl);
        _golden      = new GoldenSalesService(Xl);
        _opel        = new OpelSalesService(Xl);
        _volvo       = new VolvoSalesService(Xl);
        _dailyUpload = new DailyUploadService(Xl);

        BrowseOldCommand      = new RelayCommand(BrowseOld);
        BrowseNewCommand      = new RelayCommand(BrowseNew);
        SetTabCommand         = new RelayCommand<string>(tab => ActiveTab = tab ?? "Copy");
        ClearLogCommand       = new RelayCommand(() => Xl.Log.Clear());
        ToggleDarkModeCommand = new RelayCommand(() => IsDarkMode = !IsDarkMode);

        RunCopyCommand        = new AsyncRelayCommand(RunCopyAsync,        () => CanRunCopy);
        RunAllCommand         = new AsyncRelayCommand(RunAllAsync,         () => CanRunCopy);
        ImportOsCommand       = new AsyncRelayCommand(ImportOsAsync,       () => CanImport);
        ImportEosCommand      = new AsyncRelayCommand(ImportEosAsync,      () => CanImport);
        ImportPlanCommand     = new AsyncRelayCommand(ImportPlanAsync,     () => CanImport);
        ImportSalesCommand    = new AsyncRelayCommand(ImportSalesAsync,    () => CanImport);
        InsertFormulasCommand = new AsyncRelayCommand(InsertFormulasAsync, () => CanImport);
        GoldeSalesCommand     = new AsyncRelayCommand(GoldeSalesAsync);
        OpelSalesCommand      = new AsyncRelayCommand(OpelSalesAsync);
        VolvoSalesCommand     = new AsyncRelayCommand(VolvoSalesAsync);
        DailyUploadCommand    = new AsyncRelayCommand(DailyUploadAsync);
    }

    // ── CanExecute ────────────────────────────────────────────────────────────
    bool CanRunCopy => !IsBusy
        && !string.IsNullOrEmpty(OldMpsPath)
        && !string.IsNullOrEmpty(NewMpsPath);

    bool CanImport => !IsBusy && !string.IsNullOrEmpty(NewMpsPath);

    partial void OnIsBusyChanged(bool value)       => NotifyAll();
    partial void OnOldMpsPathChanged(string value) => NotifyAll();
    partial void OnNewMpsPathChanged(string value) => NotifyAll();

    // ── File browsers ─────────────────────────────────────────────────────────
    void BrowseOld()
    {
        var p = PickExcel("Select OLD MPS (source)");
        if (p is not null) OldMpsPath = p;
    }

    void BrowseNew()
    {
        var p = PickExcel("Select NEW MPS (to be updated)");
        if (p is not null) NewMpsPath = p;
    }

    // ── Async command implementations ─────────────────────────────────────────

    async Task RunCopyAsync()
    {
        if (!ValidateBoth() || !DoBackup()) return;
        await RunOp(async p =>
        {
            int n = await _copy.RunAsync(OldMpsPath, NewMpsPath, p);
            StepCopyDone = true;
            return $"MPS Copy complete — {n} T- sheet(s) updated.";
        });
    }

    async Task ImportOsAsync()
    {
        if (!ValidateNew()) return;
        var src = PickExcel("Select OS source file");
        if (src is null) return;
        await RunOp(async p =>
        {
            int n = await _os.ImportAsync(src, NewMpsPath, p);
            StepOsDone = true;
            return $"OS import complete — {n} parts.";
        });
    }

    async Task ImportEosAsync()
    {
        if (!ValidateNew()) return;
        var src = PickExcel("Select End-of-Stock (WIP) file");
        if (src is null) return;
        await RunOp(async p =>
        {
            int n = await _eos.ImportAsync(src, NewMpsPath, p);
            StepEosDone = true;
            return $"EOS/WIP import complete — {n} rows.";
        });
    }

    async Task ImportPlanAsync()
    {
        if (!ValidateNew()) return;
        var files = PickMultiExcel("Step 3/4 — Select Plan file(s)  [hold Ctrl for multiple]");
        if (files is null || files.Length == 0) return;
        await RunOp(async p =>
        {
            var (parts, weeks) = await _plan.ImportAsync(files, NewMpsPath, p);
            StepPlanDone = true;
            return $"Plan import complete — {parts} parts x {weeks} weeks.";
        });
    }

    async Task ImportSalesAsync()
    {
        if (!ValidateNew()) return;
        var src = PickExcel("Select Sales source file");
        if (src is null) return;
        await RunOp(async p =>
        {
            var (parts, weeks) = await _sales.ImportAsync(src, NewMpsPath, p);
            StepSalesDone = true;
            return $"Sales import complete — {parts} parts x {weeks} weeks.";
        });
    }

    async Task VolvoSalesAsync()
    {
        var src = PickExcelOrCsv("Volvo Sales — Select DELFOR source file (CSV or Excel)");
        if (src is null) return;

        var savePath = SaveAsXlsx("Volvo Sales — Save result as", "VolvoSales");
        if (savePath is null) return;

        IsBusy      = true;
        ProgressVal = 5;
        StatusText  = "Volvo Sales: processing...";
        try
        {
            var prog = new Progress<string>(msg => StatusText = msg);
            var (parts, weeks) = await _volvo.ImportAndExportAsync(src, savePath, prog);
            StatusText  = $"Volvo Sales complete — {parts} parts x {weeks} weeks exported.";
            ProgressVal = 100;
            Show($"Done!\n\n{parts} parts x {weeks} weeks\nSaved to:\n{savePath}",
                 "Volvo Sales", MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Volvo Sales error: {ex.Message}";
            Xl.LogLine("VolvoSales", "ERROR", ex.Message);
            Show(ex.Message, "Volvo Sales Error", MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    async Task OpelSalesAsync()
    {
        var src = PickExcelOrCsv("Opel Sales — Select DELFOR source file (CSV or Excel)");
        if (src is null) return;

        var lookup = PickExcel("Opel Sales — Select part number lookup file (Excel)");
        if (lookup is null) return;

        var savePath = SaveAsXlsx("Opel Sales — Save result as", "OpelSales");
        if (savePath is null) return;

        IsBusy      = true;
        ProgressVal = 5;
        StatusText  = "Opel Sales: processing...";
        try
        {
            var prog = new Progress<string>(msg => StatusText = msg);
            var (parts, weeks) = await _opel.ImportAndExportAsync(src, lookup, savePath, prog);
            StatusText  = $"Opel Sales complete — {parts} parts x {weeks} weeks exported.";
            ProgressVal = 100;
            Show($"Done!\n\n{parts} parts x {weeks} weeks\nSaved to:\n{savePath}",
                 "Opel Sales", MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Opel Sales error: {ex.Message}";
            Xl.LogLine("OpelSales", "ERROR", ex.Message);
            Show(ex.Message, "Opel Sales Error", MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    async Task GoldeSalesAsync()
    {
        var src = PickExcelOrCsv("Golde Sales — Select DELFOR source file (CSV or Excel)");
        if (src is null) return;

        var savePath = SaveAsXlsx("Golde Sales — Save result as", "GoldeSales");
        if (savePath is null) return;

        IsBusy      = true;
        ProgressVal = 5;
        StatusText  = "Golde Sales: processing…";
        try
        {
            var prog = new Progress<string>(msg => StatusText = msg);
            var (parts, weeks) = await _golden.ImportAndExportAsync(src, savePath, prog);
            StatusText  = $"Golde Sales complete — {parts} parts x {weeks} weeks exported.";
            ProgressVal = 100;
            Show($"Done!\n\n{parts} parts x {weeks} weeks\nSaved to:\n{savePath}",
                 "Golde Sales", MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Golde Sales error: {ex.Message}";
            Xl.LogLine("GoldeSales", "ERROR", ex.Message);
            Show(ex.Message, "Golde Sales Error", MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    // ── Daily Upload ──────────────────────────────────────────────────────────

    async Task DailyUploadAsync()
    {
        var rawFiles = PickMultiExcel(
            "Daily Upload — Step 1/3: Select raw build file(s)  [hold Ctrl for multiple]");
        if (rawFiles is null || rawFiles.Length == 0) return;

        var dlg = new MpsAdjuster.Views.PackageSelectDialog();
        if (dlg.ShowDialog() != true) return;
        var mode = dlg.SelectedMode;

        var templatePath = PickExcel(
            "Daily Upload — Step 3/3: Select MPS template file");
        if (templatePath is null) return;

        var savePath = SaveAsXlsx("Daily Upload — Save output as", "DailyUpload");
        if (savePath is null) return;

        IsBusy      = true;
        ProgressVal = 5;
        StatusText  = "Daily Upload: processing…";
        try
        {
            var prog  = new Progress<string>(msg => StatusText = msg);
            int parts = await _dailyUpload.RunAsync(rawFiles, templatePath, savePath, mode, prog);

            string modeLabel = mode == PackageMode.OnePackage
                ? "1 Package (full week → Saturday)"
                : "2 Packages (Sat–Mon → Saturday,  Tue–Fri → Monday)";

            StatusText  = $"Daily Upload complete — {parts} part(s) exported.";
            ProgressVal = 100;
            Show(
                $"Done!\n\nMode  : {modeLabel}\nFiles : {rawFiles.Length} raw file(s) merged\nParts : {parts}\n\nSaved to:\n{savePath}",
                "Daily Upload", MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Daily Upload error: {ex.Message}";
            Xl.LogLine("DailyUpload", "ERROR", ex.Message);
            Show(ex.Message, "Daily Upload Error", MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    // ── kept to avoid stale references ────────────────────────────────────────
    async Task ImportGoldenAsync() { }

    async Task InsertFormulasAsync()
    {
        if (!ValidateNew()) return;
        await RunOp(async p =>
        {
            int n = await _formulas.InsertAsync(NewMpsPath, p);
            StepFormDone = true;
            return $"Formulas inserted — {n} part(s) processed.";
        });
    }

    async Task RunAllAsync()
    {
        if (!ValidateBoth()) return;

        var osFile    = PickExcel("Step 1/4 — Select OS file");
        if (osFile is null) return;
        var eosFile   = PickExcel("Step 2/4 — Select EOS / WIP file");
        if (eosFile is null) return;
        var planFiles = PickMultiExcel("Step 3/4 — Select Plan file(s)  [hold Ctrl for multiple]");
        if (planFiles is null || planFiles.Length == 0) return;
        var salesFile = PickExcel("Step 4/4 — Select Sales file");
        if (salesFile is null) return;

        if (!DoBackup()) return;

        await RunOp(async p =>
        {
            p.Report("Importing OS…");
            await _os.ImportAsync(osFile, NewMpsPath, p);
            StepOsDone = true;

            p.Report("Importing EOS/WIP…");
            await _eos.ImportAsync(eosFile, NewMpsPath, p);
            StepEosDone = true;

            p.Report("Importing Plan…");
            await _plan.ImportAsync(planFiles, NewMpsPath, p);
            StepPlanDone = true;

            p.Report("Importing Sales…");
            await _sales.ImportAsync(salesFile, NewMpsPath, p);
            StepSalesDone = true;

            p.Report("Running MPS Copy & Link…");
            int copied = await _copy.RunAsync(OldMpsPath, NewMpsPath, p);
            StepCopyDone = true;

            p.Report("Inserting formulas…");
            await _formulas.InsertAsync(NewMpsPath, p);
            StepFormDone = true;

            return $"All steps complete! {copied} T- sheet(s) updated.";
        });
    }

    // ── Shared runner ─────────────────────────────────────────────────────────
    async Task RunOp(Func<IProgress<string>, Task<string>> action)
    {
        IsBusy      = true;
        ProgressVal = 5;
        try
        {
            var    prog = new Progress<string>(msg => StatusText = msg);
            string res  = await action(prog);
            StatusText  = res;
            ProgressVal = 100;
            Show(res, "Done", MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText = $"Error: {ex.Message}";
            Xl.LogLine("SYSTEM", "ERROR", ex.Message);
            Show(ex.Message, "Error", MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    // ── Guards ────────────────────────────────────────────────────────────────
    bool ValidateNew()
    {
        if (!string.IsNullOrEmpty(NewMpsPath)) return true;
        Show("Please select the NEW MPS first.", "Missing NEW MPS");
        return false;
    }

    bool ValidateBoth()
    {
        if (string.IsNullOrEmpty(OldMpsPath)) { Show("Please select the OLD MPS first.", "Missing"); return false; }
        if (string.IsNullOrEmpty(NewMpsPath)) { Show("Please select the NEW MPS first.", "Missing"); return false; }
        return true;
    }

    bool DoBackup()
    {
        if (!string.IsNullOrEmpty(Xl.BackupSmart(NewMpsPath))) return true;
        Show("Backup failed. Aborting.", "Backup Error", MessageBoxImage.Error);
        return false;
    }

    void NotifyAll()
    {
        RunCopyCommand.NotifyCanExecuteChanged();
        RunAllCommand.NotifyCanExecuteChanged();
        ImportOsCommand.NotifyCanExecuteChanged();
        ImportEosCommand.NotifyCanExecuteChanged();
        ImportPlanCommand.NotifyCanExecuteChanged();
        ImportSalesCommand.NotifyCanExecuteChanged();
        InsertFormulasCommand.NotifyCanExecuteChanged();
    }

    // ── Dialogs ───────────────────────────────────────────────────────────────
    static void Show(string msg, string title, MessageBoxImage icon = MessageBoxImage.Warning)
        => MessageBox.Show(msg, title, MessageBoxButton.OK, icon);

    static string? PickExcel(string title)
    {
        var d = new Microsoft.Win32.OpenFileDialog
        {
            Title  = title,
            Filter = "Excel Files|*.xlsx;*.xlsm;*.xlsb;*.xls"
        };
        return d.ShowDialog() == true ? d.FileName : null;
    }

    static string? PickExcelOrCsv(string title)
    {
        var d = new Microsoft.Win32.OpenFileDialog
        {
            Title  = title,
            Filter = "Excel & CSV Files|*.xlsx;*.xlsm;*.xlsb;*.xls;*.csv"
        };
        return d.ShowDialog() == true ? d.FileName : null;
    }

    static string? SaveAsXlsx(string title, string prefix = "Output")
    {
        var d = new Microsoft.Win32.SaveFileDialog
        {
            Title           = title,
            Filter          = "Excel Workbook|*.xlsx",
            DefaultExt      = ".xlsx",
            FileName        = $"{prefix}_{DateTime.Now:yyyyMMdd_HHmm}.xlsx",
            OverwritePrompt = true
        };
        return d.ShowDialog() == true ? d.FileName : null;
    }

    static string[]? PickMultiExcel(string title)
    {
        var d = new Microsoft.Win32.OpenFileDialog
        {
            Title       = title,
            Filter      = "Excel Files|*.xlsx;*.xlsm;*.xlsb;*.xls",
            Multiselect = true
        };
        return d.ShowDialog() == true ? d.FileNames : null;
    }
}
