namespace MpsAdjuster.Views;

/// <summary>
/// Modal dialog for choosing 1 Package or 2 Packages in the Daily Upload flow.
/// </summary>
public partial class PackageSelectDialog : Window
{
    public PackageMode SelectedMode { get; private set; } = PackageMode.OnePackage;

    public PackageSelectDialog()
    {
        InitializeComponent();
        Owner = Application.Current.MainWindow;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
    }

    private void Pkg1_Click(object sender, RoutedEventArgs e)
    {
        SelectedMode = PackageMode.OnePackage;
        DialogResult = true;
    }

    private void Pkg2_Click(object sender, RoutedEventArgs e)
    {
        SelectedMode = PackageMode.TwoPackages;
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
        => DialogResult = false;
}
